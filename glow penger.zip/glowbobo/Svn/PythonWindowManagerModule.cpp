// Add the following functions anywhere you want:
PyObject* wndMgrAppendHighLightImage(PyObject* poSelf, PyObject* poArgs)
{
	UI::CWindow* pWin;
	if (!PyTuple_GetWindow(poArgs, 0, &pWin))
		return Py_BuildException();

	int iIndex;
	if (!PyTuple_GetInteger(poArgs, 1, &iIndex))
		return Py_BuildException();

	char* szFileName;
	if (!PyTuple_GetString(poArgs, 2, &szFileName))
		return Py_BuildException();

	float fAlphaSpeed;
	if (!PyTuple_GetFloat(poArgs, 3, &fAlphaSpeed))
		return Py_BuildException();

	float fRotationSpeed;
	if (!PyTuple_GetFloat(poArgs, 4, &fRotationSpeed))
		return Py_BuildException();

	float fCurAlpha;
	if (!PyTuple_GetFloat(poArgs, 5, &fCurAlpha))
		return Py_BuildException();

	// Might be better to get the diffuse from tuple instead of int even if it works
	int iDiffuse;
	if (!PyTuple_GetInteger(poArgs, 6, &iDiffuse))
		return Py_BuildException();

	if (!pWin->IsType(UI::CSlotWindow::Type()))
	{
		TraceError("wndMgr.AppendHighLightImage : not a slot window");
		return Py_BuildException();
	}

	UI::CSlotWindow* pSlotWin = (UI::CSlotWindow*)pWin;
	pSlotWin->AppendHighLightImage(iIndex, szFileName, fAlphaSpeed, fRotationSpeed, fCurAlpha, iDiffuse);

	return Py_BuildNone();
}

PyObject* wndMgrEnableHighLightImage(PyObject* poSelf, PyObject* poArgs)
{
	UI::CWindow* pWindow;
	if (!PyTuple_GetWindow(poArgs, 0, &pWindow))
		return Py_BuildException();

	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 1, &iSlotIndex))
		return Py_BuildException();

	UI::CSlotWindow* pSlotWin = (UI::CSlotWindow*)pWindow;
	pSlotWin->EnableHighLightImage(iSlotIndex);

	return Py_BuildNone();
}

PyObject* wndMgrDisableHighLightImage(PyObject* poSelf, PyObject* poArgs)
{
	UI::CWindow* pWindow;
	if (!PyTuple_GetWindow(poArgs, 0, &pWindow))
		return Py_BuildException();

	int iSlotIndex;
	if (!PyTuple_GetInteger(poArgs, 1, &iSlotIndex))
		return Py_BuildException();

	UI::CSlotWindow* pSlotWin = (UI::CSlotWindow*)pWindow;
	pSlotWin->DisableHighLightImage(iSlotIndex);

	return Py_BuildNone();
}

// Bind them into the module
		{ "AppendHighLightImage",		wndMgrAppendHighLightImage,			METH_VARARGS },
		{ "EnableHighLightImage",		wndMgrEnableHighLightImage,			METH_VARARGS },
		{ "DisableHighLightImage",		wndMgrDisableHighLightImage,		METH_VARARGS },
