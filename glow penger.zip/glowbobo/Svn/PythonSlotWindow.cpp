// Add the following class above of the UI::CSlotWindow::CCoolTimeFinishEffect class:
class UI::CSlotWindow::CHighLightImage : public CExpandedImageBox
{
	public:
		CHighLightImage(CSlotWindow* pParent, DWORD dwSlotNumber) : CExpandedImageBox(NULL)
		{
			m_pParent = pParent;
			m_dwSlotNumber = dwSlotNumber;
			m_bAlphaGlow = false;
			m_fCurAlpha = 1.0f;
			m_fCurRot = 0.0f;
			m_fRotSpeed = 0.0f;
			m_fAlphaSpeed = 0.0f;
		}
		virtual ~CHighLightImage()
		{
		}
		void SetColor(DWORD dwColor, float fCurAlpha = 1.0f)
		{
			const float f = 1.0f / 255.0f;
			const float r = f * (FLOAT)(unsigned char)(dwColor >> 16);
			const float g = f * (FLOAT)(unsigned char)(dwColor >> 8);
			const float b = f * (FLOAT)(unsigned char)(dwColor >> 0);
			const float a = fCurAlpha;

			m_Color = D3DXCOLOR(r, g, b, a);
			SetDiffuseColor(m_Color);
		}
		void SetRotationSpeed(float fSpeed)
		{
			m_fRotSpeed = fSpeed;
		}
		void SetAlphaSpeed(float fSpeed, float fCurAlpha = 1.0f)
		{
			m_fCurAlpha = fCurAlpha;
			if (fSpeed > 0.0f && fSpeed < 1.0f)
			{
				m_bAlphaGlow = true;
				m_fAlphaSpeed = fSpeed;
			}
		}
		BOOL OnMouseLeftButtonDown()
		{
			m_pParent->OnMouseLeftButtonDown();
			return TRUE;
		}
		BOOL OnMouseLeftButtonUp()
		{
			m_pParent->OnMouseLeftButtonUp();
			return TRUE;
		}
		BOOL OnMouseRightButtonDown()
		{
			m_pParent->OnMouseRightButtonDown();
			return TRUE;
		}
		BOOL OnMouseLeftButtonDoubleClick()
		{
			m_pParent->OnMouseLeftButtonDoubleClick();
			return TRUE;
		}
		void OnMouseOverIn()
		{
			TSlot* pSlot;
			if (m_pParent->GetSlotPointer(m_dwSlotNumber, &pSlot))
			{
				if (pSlot->isItem)
					m_pParent->OnOverInItem(m_dwSlotNumber);
				else
					m_pParent->OnOverIn(m_dwSlotNumber);
			}
		}
		void OnMouseOverOut()
		{
			TSlot* pSlot;
			if (m_pParent->GetSlotPointer(m_dwSlotNumber, &pSlot))
			{
				if (pSlot->isItem)
					m_pParent->OnOverOutItem();
				else
					m_pParent->OnOverOut();
			}
		}
		virtual void OnUpdate()
		{
			if (IsShow())
			{
				if (m_bAlphaGlow && m_fAlphaSpeed != 0.0f)
				{
					if (m_fCurAlpha < 0.f || m_fCurAlpha >= 1.f)
						m_fAlphaSpeed = -m_fAlphaSpeed;

					m_fCurAlpha += m_fAlphaSpeed;
					SetDiffuseColor(m_Color.r, m_Color.g, m_Color.b, m_fCurAlpha);
				}

				if (m_fRotSpeed != 0.0f)
				{
					if (m_fCurRot == 360.0f)
						m_fCurRot = 0.0f;
					else
						m_fCurRot += m_fRotSpeed;

					SetRotation(m_fCurRot);
				}
			}
		}

	protected:
		CSlotWindow* m_pParent;
		DWORD m_dwSlotNumber;
		D3DXCOLOR m_Color;
		bool m_bAlphaGlow;
		float m_fCurAlpha;
		float m_fCurRot;
		float m_fRotSpeed;
		float m_fAlphaSpeed;
};

// In the function named by CSlotWindow::AppendSlot add the following below of the line "Slot.pSignImage = NULL;":
	Slot.pHighLightImage = NULL;

// Add the following functions anywhere you want:
void CSlotWindow::AppendHighLightImage(DWORD dwIndex, const char* c_sImageName, float fAlphaSpeed, float fRotationSpeed, float fCurAlpha, DWORD dwDiffuse)
{
	for (TSlotListIterator itor = m_SlotList.begin(); itor != m_SlotList.end(); ++itor)
	{
		TSlot& rSlot = *itor;
		CHighLightImage*& rpHighLightImage = rSlot.pHighLightImage;

		if (!rpHighLightImage)
		{
			rpHighLightImage = new CHighLightImage(this, rSlot.dwSlotNumber);
			CWindowManager::Instance().SetParent(rpHighLightImage, this);
		}

		rpHighLightImage->LoadImage(c_sImageName);
		rpHighLightImage->SetScale(m_v2Scale.x, m_v2Scale.y);
		rpHighLightImage->SetColor(dwDiffuse, fCurAlpha);
		rpHighLightImage->SetAlphaSpeed(fAlphaSpeed, fCurAlpha);
		rpHighLightImage->SetRotationSpeed(fRotationSpeed);
		rpHighLightImage->SetRenderingMode(CGraphicExpandedImageInstance::RENDERING_MODE_NORMAL);
		rpHighLightImage->Hide();
	}
}

void CSlotWindow::EnableHighLightImage(DWORD dwIndex)
{
	TSlot* pSlot;
	if (!GetSlotPointer(dwIndex, &pSlot))
		return;

	if (!pSlot->pHighLightImage)
		return;

	pSlot->bEnableHighLight = TRUE;
	pSlot->pHighLightImage->Show();
}

void CSlotWindow::DisableHighLightImage(DWORD dwIndex)
{
	TSlot* pSlot;
	if (!GetSlotPointer(dwIndex, &pSlot))
		return;

	if (!pSlot->pHighLightImage)
		return;

	pSlot->bEnableHighLight = FALSE;
	pSlot->pHighLightImage->Hide();
}

// Jump to this function "CSlotWindow::SetSlot" find this part:
	if (pSlot->isItem)
	{
		if (pSlot->dwItemIndex == dwVirtualNumber)
		{
// Add the following before the "return;"
			if (pSlot->pHighLightImage && pSlot->bEnableHighLight)
			{
				pSlot->pHighLightImage->Show();
			}
// Then add the same at the bottom of the function below of the "if (pSlot->pCoverButton) {...}" :
	if (pSlot->pHighLightImage && pSlot->bEnableHighLight)
	{
		pSlot->pHighLightImage->Show();
	}

// Add the followings to the bottom of the "CSlotWindow::ClearSlot" function:
	pSlot->bEnableHighLight = FALSE;
	if (pSlot->pHighLightImage)
		pSlot->pHighLightImage->Hide();

// Add the following into the "CSlotWindow::OnRender" function at the bottom:
		if (rSlot.pHighLightImage && rSlot.bEnableHighLight)
		{
			rSlot.pHighLightImage->SetPosition(
				rSlot.ixPosition + rSlot.byxPlacedItemSize * rSlot.ixCellSize / 2 - rSlot.pHighLightImage->GetWidth() / 2,
				rSlot.iyPosition + rSlot.iyCellSize / 2 - rSlot.pHighLightImage->GetHeight() / 2
			);
		}
//	}
//
//	RenderLockedSlot();
//}

// In the "CSlotWindow::Destroy" function add the following below of the "pSignImage" part:
		if (rSlot.pHighLightImage)
		{
			CWindowManager::Instance().DestroyWindow(rSlot.pHighLightImage);
		}
