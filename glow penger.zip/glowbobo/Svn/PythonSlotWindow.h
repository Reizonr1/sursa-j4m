// Find the following:
		public:
			class CSlotButton;
			class CCoverButton;
// Add below:
			class CHighLightImage;

// Into the TSlot struct add the following:
			typedef struct SSlot
			{
				//[...]
				BOOL bEnableHighLight;
				CHighLightImage* pHighLightImage;
			} TSlot;

// Declare the new funtions as public in the CSlotWindow class:
			void AppendHighLightImage(DWORD dwIndex, const char* c_sImageName, float fAlphaSpeed = 0.0f, float fRotationSpeed = 0.0f, float fCurAlpha = 1.0f, DWORD dwDiffuse = DWORD(-1));
			void EnableHighLightImage(DWORD dwIndex);
			void DisableHighLightImage(DWORD dwIndex);
