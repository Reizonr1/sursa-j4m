import ui
import grp
import item
import wndMgr

class SlotGlowTest(ui.ScriptWindow):
	closeEvent = None
	PENDANT_ITEM_DICT = {
		#index : [vnum, path, alphaspeed, rotationspeed, startalpha, color]
		0 : [9600,  "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(1.0, 0.0, 0.0, 1.0)],
		1 : [9830,  "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(0.0, 0.8235, 1.0, 1.0)],
		2 : [10060, "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(0.7647, 0.7647, 0.0, 1.0)],
		3 : [10290, "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(0.7451, 0.0, 1.0, 1.0)],
		4 : [10520, "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(0.0, 0.6863, 0.0, 1.0)],
		5 : [10750, "d:/ymir work/ui/game/glow/slot_glow.tga", 0.01, 0.0, 1.0, grp.GenerateColor(0.0, 0.0, 1.0, 1.0)],
	}

	def __init__(self):
		ui.ScriptWindow.__init__(self)

		item.LoadItemTable("locale/hu/item_proto")
		self.STATE = 0
		# wndMgr.SetOutlineFlag(1)
		self.__LoadBoard()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Destroy(self):
		self.Close()
		self.ClearDictionary()

	def __LoadBoard(self):
		self.Board = ui.BoardWithTitleBar()
		self.Board.titleBar.MinimizeButtonShow()
		self.Board.titleBar.SetMinimizeEvent(self.ChangeState)
		self.Board.AddFlag("movable")
		self.Board.AddFlag("float")
		self.Board.SetTitleName("SlotGlowTest")
		self.Board.SetSize(150, 115)
		self.Board.SetCenterPosition()
		self.Board.SetCloseEvent(self.Close)
		self.Board.Show()

		self.ItemSlot = ui.SlotWindow()
		self.ItemSlot.SetParent(self.Board)
		self.ItemSlot.SetSize(0, 0)
		self.ItemSlot.SetPosition(75 - 16, 50)
		self.ItemSlot.Show()
		wndMgr.AppendSlot(self.ItemSlot.hWnd, 0, 0, 0, 32, 32)
		wndMgr.SetSlotBaseImage(self.ItemSlot.hWnd, "d:/ymir work/ui/public/Slot_Base.sub", 1., 1., 1., 1.)
		self.RefreshSlot()

	def ChangeState(self):
		self.ItemSlot.DisableHighLightImage(0)
		if self.STATE == 5:
			self.STATE = 0
		else:
			self.STATE += 1

		self.RefreshSlot()

	def RefreshSlot(self):
		self.ItemSlot.SetItemSlot(0, self.PENDANT_ITEM_DICT[self.STATE][0], 0)
		self.ItemSlot.AppendHighLightImage(0, *self.PENDANT_ITEM_DICT[self.STATE][1:])
		self.ItemSlot.EnableHighLightImage(0)

	def SetCloseEvent(self, event):
		self.closeEvent = event

	def Show(self):
		ui.ScriptWindow.Show(self)

	def Close(self):
		self.Board.Hide()
		# wndMgr.SetOutlineFlag(0)
		if callable(self.closeEvent):
			self.closeEvent()

	def OnPressEscapeKey(self):
		self.Close()
		return 1

a=SlotGlowTest()
a.Show()
