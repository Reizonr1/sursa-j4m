#Find this class:
class SlotWindow(Window):

#Add the following functions into the class anywhere you want, I put every new functions always at the bottom of the classes:
	def AppendHighLightImage(self, index, fileName, alphaSpeed = 0.0, rotationSpeed = 0.0, curAlpha = 1.0, diffuse = 0xFFFFFFFF):
		wndMgr.AppendHighLightImage(self.hWnd, index, fileName, alphaSpeed, rotationSpeed, curAlpha, diffuse)

	def EnableHighLightImage(self, slotIndex):
		wndMgr.EnableHighLightImage(self.hWnd, slotIndex)

	def DisableHighLightImage(self, slotIndex):
		wndMgr.DisableHighLightImage(self.hWnd, slotIndex)

# In case if you don't have the minimizebutton on the titlebar change your class
class TitleBar(Window):

	BLOCK_WIDTH = 32
	BLOCK_HEIGHT = 23

	def __init__(self):
		Window.__init__(self)
		self.AddFlag("attach")

	def __del__(self):
		Window.__del__(self)

	def MakeTitleBar(self, width, color):

		## ���� Color�� ����ϰ� ���� ����

		width = max(64, width)

		imgLeft = ImageBox()
		imgCenter = ExpandedImageBox()
		imgRight = ImageBox()

		imgLeft.AddFlag("not_pick")
		imgCenter.AddFlag("not_pick")
		imgRight.AddFlag("not_pick")

		imgLeft.SetParent(self)
		imgCenter.SetParent(self)
		imgRight.SetParent(self)

		if localeInfo.IsARABIC():
			imgLeft.LoadImage("locale/ae/ui/pattern/titlebar_left.tga")
			imgCenter.LoadImage("locale/ae/ui/pattern/titlebar_center.tga")
			imgRight.LoadImage("locale/ae/ui/pattern/titlebar_right.tga")
		else:
			imgLeft.LoadImage("d:/ymir work/ui/pattern/titlebar_left.tga")
			imgCenter.LoadImage("d:/ymir work/ui/pattern/titlebar_center.tga")
			imgRight.LoadImage("d:/ymir work/ui/pattern/titlebar_right.tga")

		imgLeft.Show()
		imgCenter.Show()
		imgRight.Show()

		btnClose = Button()
		btnClose.SetParent(self)
		btnClose.SetUpVisual("d:/ymir work/ui/public/close_button_01.sub")
		btnClose.SetOverVisual("d:/ymir work/ui/public/close_button_02.sub")
		btnClose.SetDownVisual("d:/ymir work/ui/public/close_button_03.sub")
		btnClose.SetToolTipText(localeInfo.UI_CLOSE, 0, -23)
		btnClose.Show()

		#Minimize Baseframe
		btnMinimize = ImageBox()
		btnMinimize.AddFlag("not_pick")
		btnMinimize.SetParent(self)
		btnMinimize.LoadImage("d:/ymir work/ui/pattern/titlebar_minimize_baseframe.tga")
		btnMinimize.Hide()

		#Minimize Button
		btnMinimize.Button = Button()
		btnMinimize.Button.SetParent(btnMinimize)
		btnMinimize.Button.SetPosition(3, 3)
		btnMinimize.Button.SetUpVisual("d:/ymir work/ui/public/minimize_button_01.sub")
		btnMinimize.Button.SetOverVisual("d:/ymir work/ui/public/minimize_button_02.sub")
		btnMinimize.Button.SetDownVisual("d:/ymir work/ui/public/minimize_button_03.sub")
		btnMinimize.Button.SetToolTipText(localeInfo.UI_MINIMIZE, 0, -23)
		btnMinimize.Button.Show()

		self.imgLeft = imgLeft
		self.imgCenter = imgCenter
		self.imgRight = imgRight
		self.btnClose = btnClose
		self.btnMinimize = btnMinimize

		self.SetWidth(width)

	def AdjustButtonsPosition(self):
		if localeInfo.IsARABIC():
			self.btnClose.SetPosition(3, 3)
			if self.btnClose.IsShow():
				self.btnMinimize.SetPosition(3 + self.btnClose.GetWidth(), 3)
			else:
				self.btnMinimize.SetPosition(3, 3)
		else:
			self.btnClose.SetPosition(self.GetWidth() - self.btnClose.GetWidth() - 3, 3)
			if self.btnClose.IsShow():
				self.btnMinimize.SetPosition(self.GetWidth() - self.btnClose.GetWidth() - self.btnMinimize.GetWidth() - 6, 0)
			else:
				self.btnMinimize.SetPosition(self.GetWidth() - self.btnMinimize.GetWidth(), 0)

	def SetWidth(self, width):
		self.imgCenter.SetRenderingRect(0.0, 0.0, float((width - self.BLOCK_WIDTH*2) - self.BLOCK_WIDTH) / self.BLOCK_WIDTH, 0.0)
		self.imgCenter.SetPosition(self.BLOCK_WIDTH, 0)
		self.imgRight.SetPosition(width - self.BLOCK_WIDTH, 0)

		self.SetSize(width, self.BLOCK_HEIGHT)

		self.AdjustButtonsPosition()

	def SetCloseEvent(self, event, *args):
		self.btnClose.SetEvent(event, *args)

	def SetMinimizeEvent(self, event):
		self.btnMinimize.Button.SetEvent(event)

	def CloseButtonHide(self):
		self.imgRight.LoadImage("d:/ymir work/ui/pattern/titlebar_right_02.tga")
		self.btnClose.SetEvent(lambda *args,**kwargs:None)
		self.btnClose.Hide()

		self.AdjustButtonsPosition()

	def MinimizeButtonShow(self):
		if not self.btnClose.IsShow():
			self.imgRight.LoadImage("d:/ymir work/ui/pattern/titlebar_right.tga")

		self.btnMinimize.Show()

		self.AdjustButtonsPosition()
