//Find:
#ifdef ENABLE_COSTUME_SYSTEM
	PyModule_AddIntConstant(poModule, "ENABLE_COSTUME_SYSTEM",	1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_COSTUME_SYSTEM",	0);
#endif

//Add under:
#ifdef ENABLE_EXTENDED_SELL
	PyModule_AddIntConstant(poModule, "ENABLE_EXTENDED_SELL",	1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_EXTENDED_SELL",	0);
#endif

#ifdef ENABLE_SPECIAL_STORAGE
	PyModule_AddIntConstant(poModule, "ENABLE_SPECIAL_STORAGE", 1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_SPECIAL_STORAGE",	0);
#endif