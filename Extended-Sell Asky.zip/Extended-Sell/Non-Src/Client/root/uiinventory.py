[...]
if app.ENABLE_EXTENDED_SELL:
	import extended_sell

[...]
class InventoryWindow(ui.ScriptWindow):
	[...]
	
	#Modify (find for ENABLE_EXTENDED_SELL):
	def RefreshBagSlotWindow(self):
		[...]
			
	if app.ENABLE_EXTENDED_SELL:
		def OnUpdate(self):
			if self.wndItem:
				self.RefreshExtendedSellCover()
			
		def RefreshExtendedSellCover(self):
			for i in xrange(player.INVENTORY_PAGE_SIZE):
				slotNumber = self.__InventoryLocalSlotPosToGlobalSlotPos(i)
				self.wndItem.EnableCoverButton(i) 
				if extended_sell.IsItemAlreadyInList(slotNumber):
					self.wndItem.SetCoverButton(i, "d:/ymir work/ui/game/quest/slot_button_00.sub",\
																						 "d:/ymir work/ui/game/quest/slot_button_00.sub",\
																						"d:/ymir work/ui/game/quest/slot_button_00.sub",\
																						"d:/ymir work/ui/selected_icon.tga", FALSE, FALSE)
					self.wndItem.DisableCoverButton(i)

	[...]

	def __SellItem(self, itemSlotPos):
		if not player.IsEquipmentSlot(itemSlotPos):
			[...]

			itemPrice = item.GetISellItemPrice()

			if item.Is1GoldItem():
				itemPrice = itemCount / itemPrice / 5
			else:
				itemPrice = itemPrice * itemCount / 5
				
			if app.ENABLE_EXTENDED_SELL:
				if not extended_sell.IsItemAlreadyInList(itemSlotPos):
					extended_sell.TOTAL_SELL_VALUE += int(itemPrice)
					extended_sell.AddToSelectedItems(itemSlotPos)
				else:
					if extended_sell.ENABLE_SELECT_UNSELECT_FEATURE:
						extended_sell.TOTAL_SELL_VALUE -= int(itemPrice)
						extended_sell.RemoveFromSelectedItems(itemSlotPos)
					else:
						chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.EXTENDED_SELL_ALREADY_SELECTED)
				
			else:			
				item.GetItemName(itemIndex)
				itemName = item.GetItemName()

				self.questionDialog = uiCommon.QuestionDialog()
				self.questionDialog.SetText(localeInfo.DO_YOU_SELL_ITEM(itemName, itemCount, itemPrice))
				self.questionDialog.SetAcceptEvent(ui.__mem_func__(self.SellItem))
				self.questionDialog.SetCancelEvent(ui.__mem_func__(self.OnCloseQuestionDialog))
				self.questionDialog.Open()
				self.questionDialog.count = itemCount

				constInfo.SET_ITEM_QUESTION_DIALOG_STATUS(1)
			
	[...]