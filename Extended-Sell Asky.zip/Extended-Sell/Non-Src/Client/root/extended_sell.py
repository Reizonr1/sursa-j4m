import app
if app.ENABLE_EXTENDED_SELL:
	ENABLE_SELECT_UNSELECT_FEATURE = 1 #Enables selecting / unselecting in real-time.
	
	TAX_RATE = 1 #Set 0 to disable tax showing.
	TOTAL_SELL_VALUE = 0
	SELECTED_ITEMS = []
	
	def GetSelectedItemsLength():
		return len(SELECTED_ITEMS)
		
	def GetSelectedItemsValue(idx):
		return SELECTED_ITEMS[idx]
	
	def AddToSelectedItems(itemSlotPos):
		SELECTED_ITEMS.append(itemSlotPos)
		
	def RemoveFromSelectedItems(itemSlotPos):
		for i in range(len(SELECTED_ITEMS)):
			if SELECTED_ITEMS[i-1] == itemSlotPos:
				del SELECTED_ITEMS[i-1]
		
	def IsItemAlreadyInList(itemSlotPos):
		for i in range (len(SELECTED_ITEMS)):
			if SELECTED_ITEMS[i-1] == itemSlotPos:
				return True
		return False
		
	def ClearSelectedItems():
		del SELECTED_ITEMS[:]
		
	if app.ENABLE_SPECIAL_STORAGE:
		SELECTED_ITEMS_ST = []
		ST_CATEGORY = 0
		
		def GetSelectedItemsLengthST():
			return len(SELECTED_ITEMS_ST)
			
		def GetSelectedItemsValueST(idx):
			return SELECTED_ITEMS_ST[idx]
		
		def AddToSelectedItemsST(itemSlotPos):
			SELECTED_ITEMS_ST.append(itemSlotPos)
			
		def RemoveFromSelectedItemsST(itemSlotPos):
			for i in range(len(SELECTED_ITEMS_ST)):
				if SELECTED_ITEMS_ST[i-1] == itemSlotPos:
					del SELECTED_ITEMS_ST[i-1]
			
		def IsItemAlreadyInListST(itemSlotPos):
			for i in range (len(SELECTED_ITEMS_ST)):
				if SELECTED_ITEMS_ST[i-1] == itemSlotPos:
					return True
			return False
			
		def ClearSelectedItemsST():
			del SELECTED_ITEMS_ST[:]		
