//Find
	m_strMapName="";
	
///Add
#if defined(__LOADING_TIP__)
	l_WarpMapIndex = 0;
#endif