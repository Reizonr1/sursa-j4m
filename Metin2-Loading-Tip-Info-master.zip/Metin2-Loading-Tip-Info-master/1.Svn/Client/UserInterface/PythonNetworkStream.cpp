//Find
	Tracen("PythonNetworkMainStream Clear");
	
///Add
#if defined(__LOADING_TIP__)
	m_TipVnum.clear();
#endif