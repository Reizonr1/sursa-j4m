//Find in typedef struct packet_warp
	WORD			wPort;
	
///Add
#if defined(__LOADING_TIP__)
	long			l_MapIndex;
#endif