//Find
	__DirectEnterMode_Set(m_dwSelectedCharacterIndex);

///Add Above!
#if defined(__LOADING_TIP__)
	CPythonBackground::Instance().SetWarpMapInfo(kWarpPacket.l_MapIndex);
#endif
