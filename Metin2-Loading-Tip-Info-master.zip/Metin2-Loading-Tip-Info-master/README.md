# Metin2-Loading-Tip-Info
**Created by blackdragonx61**

* It's giving random informations about game at loading window. Edit LTipList.h for special map's infos.

* Group "Normal" has global informations. If you don't add any special map index at LTipList, you will see global infos.

* One thing you need to know, special informations not working at "First Login", because warpmapindex is 0 at login. So you will see global informations.

![](https://puu.sh/FJUYb/78471ba862.png)
