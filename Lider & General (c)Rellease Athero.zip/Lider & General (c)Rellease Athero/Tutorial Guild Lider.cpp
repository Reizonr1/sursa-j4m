##Sursa Binary

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
1. InstanceBaseEffect.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

CPythonTextTail::Instance().RegisterCharacterTextTail(m_dwGuildID, dwVID, s_kD3DXClrTextTail, fTextTailHeight);

//Modificam cu 

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	CPythonTextTail::Instance().RegisterCharacterTextTail(m_dwGuildID, m_dwNewIsGuildName, dwVID, s_kD3DXClrTextTail, fTextTailHeight);
#else
	CPythonTextTail::Instance().RegisterCharacterTextTail(m_dwGuildID, dwVID, s_kD3DXClrTextTail, fTextTailHeight);
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
2. InstanceBase.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam 

DWORD CInstanceBase::GetGuildID()
{
	return m_dwGuildID;
}

//Adaugam sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
BYTE CInstanceBase::GetNewIsGuildName()
{
	return m_dwNewIsGuildName;
}
#endif

//Cautam

	m_dwEmpireID = c_rkCreateData.m_dwEmpireID;
	
//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	m_dwNewIsGuildName = c_rkCreateData.m_dwNewIsGuildName;
#endif

//Cautam

void CInstanceBase::ChangeGuild(DWORD dwGuildID)

//Modificam toata functia cu

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
void CInstanceBase::ChangeGuild(DWORD dwGuildID, DWORD dwNewIsGuildName)
#else
void CInstanceBase::ChangeGuild(DWORD dwGuildID)
#endif
{
	m_dwGuildID = dwGuildID;
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	m_dwNewIsGuildName = dwNewIsGuildName;
#endif
	DetachTextTail();
	AttachTextTail();
	RefreshTextTail();
}

//Cautam

m_dwGuildID = 0;

//Adaugam sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	m_dwNewIsGuildName = 0;
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
3. InstanceBase.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

DWORD	m_dwMountVnum;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
			BYTE	m_dwNewIsGuildName;
#endif

//Cautam

void					ChangeGuild(DWORD dwGuildID);

//Inlocuim cu 

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		void					ChangeGuild(DWORD dwGuildID, DWORD dwNewIsGuildName);
#else
		void					ChangeGuild(DWORD dwGuildID);
#endif

//Cautam

DWORD					m_dwGuildID;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		BYTE					m_dwNewIsGuildName;
#endif

//Cautam

DWORD					GetGuildID();

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		BYTE					GetNewIsGuildName();
#endif	

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
4. PythonCaracterManager.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

pInstance->ChangeGuild(pInstance->GetGuildID();

//Inlocuim cu 

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		pInstance->ChangeGuild(pInstance->GetGuildID(), pInstance->GetNewIsGuildName());
#else
		pInstance->ChangeGuild(pInstance->GetGuildID();
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
5. PyhtonTextTail.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

std::string strGuildName;

if (!CPythonGuild::Instance().GetGuildName(dwGuildID, &strGuildName))
	strGuildName = "Noname";
	
//Inlocuim toata functia cu 

		std::string strGuildName;
		if (!CPythonGuild::Instance().GetGuildName(dwGuildID, &strGuildName))
			strGuildName = "Noname";
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		if (dwNewIsGuildName == 3)
			strGuildName.insert(0, ENABLE_SHOW_LIDER_AND_GENERAL_GUILD_VALUE1);
		else if (dwNewIsGuildName == 2)
			strGuildName.insert(0, ENABLE_SHOW_LIDER_AND_GENERAL_GUILD_VALUE2);
#endif

//Cautam

void CPythonTextTail::RegisterCharacterTextTail(DWORD dwGuildID, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight)

//Inclocuim cu 

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
void CPythonTextTail::RegisterCharacterTextTail(DWORD dwGuildID, BYTE dwNewIsGuildName, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight)
#else
void CPythonTextTail::RegisterCharacterTextTail(DWORD dwGuildID, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight)
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
6. PythonTextTail.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

void RegisterCharacterTextTail(DWORD dwGuildID, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight = 10.0f);

//Inlocuim cu

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		void RegisterCharacterTextTail(DWORD dwGuildID, BYTE m_dwNewIsGuildName, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight = 10.0f);
#else
		void RegisterCharacterTextTail(DWORD dwGuildID, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight = 10.0f);
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
7. PythonTextTailModule.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cuatam

PyObject * textTailRegisterCharacterTextTail(PyObject * poSelf, PyObject * poArgs)

//Inlocuim toata functia cu 

PyObject * textTailRegisterCharacterTextTail(PyObject * poSelf, PyObject * poArgs)
{
	int iGuildID;
	if (!PyTuple_GetInteger(poArgs, 0, &iGuildID))
		return Py_BuildException();
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	int iNewIsGuildName;
	if (!PyTuple_GetInteger(poArgs, 1, &iNewIsGuildName))
		return Py_BuildException();
	int iVirtualID;
	if (!PyTuple_GetInteger(poArgs, 2, &iVirtualID))
		return Py_BuildException();
#else
	int iVirtualID;
	if (!PyTuple_GetInteger(poArgs, 1, &iVirtualID))
		return Py_BuildException();
#endif

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	CPythonTextTail::Instance().RegisterCharacterTextTail(iGuildID, iVirtualID, iNewIsGuildName, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
#else
	CPythonTextTail::Instance().RegisterCharacterTextTail(iGuildID, iVirtualID, D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
#endif
	return Py_BuildNone();
}

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
8. NetworkActorManager.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

m_dwGuildID = src.m_dwGuildID;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	m_dwNewIsGuildName = src.m_dwNewIsGuildName;
#endif

//Cautam

kCreateData.m_dwMountVnum=rkNetActorData.m_dwMountVnum;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	kCreateData.m_dwNewIsGuildName = rkNetActorData.m_dwNewIsGuildName;
#endif

//Cautam

pkInstFind->ChangeGuild(c_rkNetUpdateActorData.m_dwGuildID);

//Inlocuim cu

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		pkInstFind->ChangeGuild(c_rkNetUpdateActorData.m_dwGuildID, c_rkNetUpdateActorData.m_dwNewIsGuildName);
#else
		pkInstFind->ChangeGuild(c_rkNetUpdateActorData.m_dwGuildID);
#endif

//Cautam

rkNetActorData.m_dwGuildID=c_rkNetUpdateActorData.m_dwGuildID;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	rkNetActorData.m_dwNewIsGuildName = c_rkNetUpdateActorData.m_dwNewIsGuildName;
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
9. NetworkActorManager.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

DWORD	m_dwGuildID;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE	m_dwNewIsGuildName;
#endif

//Cautam

DWORD m_dwMountVnum;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	DWORD m_dwNewIsGuildName;
#endif

//Cautam

m_dwMountVnum=0;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		m_dwNewIsGuildName = 0;
#endif	

//Cautam

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
10. PythonNetworkStreamPhaseGameActor.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

kNetActorData.m_dwMountVnum=0;

//Adaugam sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	kNetActorData.m_dwNewIsGuildName = 0;
#endif


//Cautam

kNetActorData.m_dwMountVnum=chrInfoPacket.dwMountVnum;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		kNetActorData.m_dwNewIsGuildName = chrInfoPacket.dwNewIsGuildName;
#endif

//Cautam

kNetUpdateActorData.m_dwMountVnum=chrUpdatePacket.dwMountVnum;

//Adaugam sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	kNetUpdateActorData.m_dwNewIsGuildName = chrUpdatePacket.dwNewIsGuildName;
#endif

--------!!ATENTIE !! Exista de 2 ori , in ambele locuri adaugam.---------

//Cautam

kNetActorData.m_dwMountVnum=chrAddPacket.dwMountVnum;

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	kNetActorData.m_dwNewIsGuildName = chrAddPacket.dwNewIsGuildName;
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
11. Packet.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam 

TPacketGCCharacterAdditionalInfo

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE	dwNewIsGuildName;
#endif

//Cautam

TPacketGCCharacterAdd2

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE		dwNewIsGuildName;
#endif

//Cautam

TPacketGCCharacterUpdate

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE		dwNewIsGuildName;
#endif

//Cautam

TPacketGCCharacterUpdate2

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE		dwNewIsGuildName;
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
12. Locale_inc.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Adaugam 

#ifndef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
#define ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
#define ENABLE_SHOW_LIDER_AND_GENERAL_GUILD_VALUE1 "[Lider] - "
#define ENABLE_SHOW_LIDER_AND_GENERAL_GUILD_VALUE2 "[General] - "
#endif



##Am terminat cu parte de binary si ne ducem in sursa game

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
1. Char.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

if (GetGuild() != NULL)

// Modificam pana la if (iDur) cu

			if (GetGuild() != NULL)
			{	
				addPacket.dwGuildID = GetGuild()->GetID();
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
				CGuild* pGuild = this->GetGuild();
				if (pGuild->GetMasterPID() == GetPlayerID())
					addPacket.dwNewIsGuildName = 3;

				else if (pGuild->NewIsGuildGeneral(GetPlayerID()) == true)
					addPacket.dwNewIsGuildName = 2;

				else
					addPacket.dwNewIsGuildName = 1;
#endif
			}
			else
			{
				addPacket.dwGuildID = 0;
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
				addPacket.dwNewIsGuildName = 0;
#endif
			}

			addPacket.sAlignment = m_iAlignment / 10;
		}

		d->Packet(&addPacket, sizeof(TPacketGCCharacterAdditionalInfo));
	}
	

//Cautam

pack.dwMountVnum	= GetMountVnum();

//Modificam functia de deasupra CGuild* pGuild = this->GetGuild(); cu 

	if (GetGuild())
		pack.dwGuildID = GetGuild()->GetID();
#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	CGuild* pGuild = this->GetGuild();
	if (pGuild)
	{
		if (pGuild->GetMasterPID() == GetPlayerID())
			pack.dwNewIsGuildName = 3;
		else if (pGuild->NewIsGuildGeneral(GetPlayerID()) == true)
			pack.dwNewIsGuildName = 2;
		else
			pack.dwNewIsGuildName = 1;
	}
	else
	{
		pack.dwNewIsGuildName = 0;
	}
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
2. Packet.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

TPacketGCCharacterAdditionalInfo

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE	dwNewIsGuildName;
#endif	

//Cautam 

TPacketGCCharacterUpdate

//Adaugam Deasupra

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
	BYTE	dwNewIsGuildName;
#endif	

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
3. guild.cpp
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

DWORD CGuild::GetMemberPID(const std::string& strName)

//Sub toata functia adaugam 

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
BYTE CGuild::NewIsGuildGeneral(DWORD pid)
{
	for ( TGuildMemberContainer::iterator iter = m_member.begin(); iter != m_member.end(); iter++ )
	{
		if ( iter->first == pid )
			return iter->second.is_general;
	}
	return 0;
}
#endif

-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------
4. guild.h
-----------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------

//Cautam

DWORD			GetMemberPID(const std::string& strName);

//Adaugam Sub

#ifdef ENABLE_SHOW_LIDER_AND_GENERAL_GUILD
		BYTE			NewIsGuildGeneral(DWORD pid);
#endif




Acuma mergem in common / service.h si adaugam 

#define ENABLE_SHOW_LIDER_AND_GENERAL_GUILD





















