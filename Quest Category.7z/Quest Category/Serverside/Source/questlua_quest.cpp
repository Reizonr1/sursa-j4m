	int quest_get_current_quest_name(lua_State* L)
	{
		CQuestManager& q = CQuestManager::instance();
		PC* pPC = q.GetCurrentPC();
	
		lua_pushstring(L, pPC->GetCurrentQuestName().c_str());
		return 1;
	}

	void RegisterQuestFunctionTable()
	{
		luaL_reg quest_functions[] = 
		{
			{ "getcurrentquestname",	quest_get_current_quest_name},
			{ NULL,						NULL						}
		};

		CQuestManager::instance().AddLuaFunctionTable("q", quest_functions);
	}