## Procurar por
self.BINARY_RecvQuest(index, name, "file", localeInfo.GetLetterImageName())


## Substituir pelo seguinte
self.wndCharacter.questCategory.RecvQuest(self.BINARY_RecvQuest, index, name)