## Comentar ou eliminar tudo o que for relacionado
## com as seguintes variáveis.
self.questShowingStartIndex
self.questScrollBar
self.questSlot
self.questNameList
self.questLastTimeList
self.questLastCountList

## Procurar por
self.soloEmotionSlot = self.GetChild("SoloEmotionSlot")
self.dualEmotionSlot = self.GetChild("DualEmotionSlot")
self.__SetEmotionSlot()

## Adicionar por baixo
import uiQuestCategory
self.questCategory = uiQuestCategory.QuestCategoryWindow(self.pageDict["QUEST"])

## Procurar por
	def OnUpdate(self):
		self.__UpdateQuestClock()

## Substituir com
	def OnUpdate(self):
		self.questCategory.OnUpdate()