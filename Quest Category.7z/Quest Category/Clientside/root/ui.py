## Adicionar na class Button()
def SetTextAlignLeft(self, text, height = 4):

	if not self.ButtonText:
		textLine = TextLine()
		textLine.SetParent(self)
		textLine.SetPosition(27, self.GetHeight()/2)
		textLine.SetVerticalAlignCenter()
		textLine.SetHorizontalAlignLeft()
		textLine.Show()
		self.ButtonText = textLine

	#Äù½ºÆ® ¸®½ºÆ® UI¿¡ ¸ÂÃç À§Ä¡ ÀâÀ½
	self.ButtonText.SetText(text)
	self.ButtonText.SetPosition(27, self.GetHeight()/2)
	self.ButtonText.SetVerticalAlignCenter()
	self.ButtonText.SetHorizontalAlignLeft()