# Metin2-IntroLogo
You have a video example on that I made. You need to make the encoding match. You can use Bandi Video Converter.

[![IntroLogo Client](http://img.youtube.com/vi/mrob6gt8YSI/0.jpg)](http://www.youtube.com/watch?v=mrob6gt8YSI "IntroLogo Client")
