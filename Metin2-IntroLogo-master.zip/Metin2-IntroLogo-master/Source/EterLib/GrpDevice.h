//Search for:
EDeviceState	GetDeviceState();

//Add after:
	LPDIRECT3D8		GetDirectx8();
	LPDIRECT3DDEVICE8 GetDevice();