#Search for:
	#mainStream.SetLoadingPhase()

#Add after:
	mainStream.SetLogoPhase() #Remove this until we have a proper client logo 	