import uiScriptLocale

window = {
	"name" : "ShopDialog",

	"x" : SCREEN_WIDTH - 400,
	"y" : 10,

	"style" : ("movable", "float",),

	"width" : 184,
	"height" : 328,

	"children" :
	(
		{
			"name" : "board",
			"type" : "board",
			"style" : ("attach",),

			"x" : 0,
			"y" : 0,

			"width" : 184,
			"height" : 328,

			"children" :
			(
				## Title
				{
					"name" : "TitleBar",
					"type" : "titlebar",
					"style" : ("attach",),

					"x" : 8,
					"y" : 8,

					"width" : 169,
					"color" : "gray",

					"children" :
					(
						{ "name":"TitleName", "type":"text", "x":132, "y":4, "text":uiScriptLocale.SHOP_TITLE, "text_horizontal_align":"center" },
					),
				},

				## Item Slot
				{
					"name" : "ItemSlot_40", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 5, "y_count" : 9, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name" : "ItemSlot_50", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 5, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name" : "ItemSlot_60", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 6, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},				
				{
					"name" : "ItemSlot_70", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 7, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name" : "ItemSlot_80", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 8, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name" : "ItemSlot_90", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 9, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name" : "ItemSlot_100", "type" : "grid_table", "x" : 12, "y" : 34,	"start_index" : 0,
					"x_count" : 10, "y_count" : 10, "x_step" : 32, "y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
					
				
				
				## Buy
				{
					"name" : "BuyButton",
					"type" : "toggle_button",

					"x" : 21,
					"y" : 295,

					"width" : 61,
					"height" : 21,

					"text" : uiScriptLocale.SHOP_BUY,

					"default_image" : "d:/ymir work/ui/public/middle_button_01.tga",
					"over_image" : "d:/ymir work/ui/public/middle_button_02.tga",
					"down_image" : "d:/ymir work/ui/public/middle_button_03.tga",
				},

				## Sell
				{
					"name" : "SellButton",
					"type" : "toggle_button",

					"x" : 104,
					"y" : 295,

					"width" : 61,
					"height" : 21,

					"text" : uiScriptLocale.SHOP_SELL,

					"default_image" : "d:/ymir work/ui/public/middle_button_01.tga",
					"over_image" : "d:/ymir work/ui/public/middle_button_02.tga",
					"down_image" : "d:/ymir work/ui/public/middle_button_03.tga",
				},

				## Close
				{
					"name" : "CloseButton",
					"type" : "button",

					"x" : 0,
					"y" : 295,

					"horizontal_align" : "center",

					"text" : uiScriptLocale.PRIVATE_SHOP_CLOSE_BUTTON,

					"default_image" : "d:/ymir work/ui/public/large_button_01.tga",
					"over_image" : "d:/ymir work/ui/public/large_button_02.tga",
					"down_image" : "d:/ymir work/ui/public/large_button_03.tga",
				},
			),
		},
	),
}