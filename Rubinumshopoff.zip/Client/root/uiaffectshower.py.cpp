Arat:
	if app.ENABLE_DRAGON_SOUL_SYSTEM:
		# ��ȥ�� õ, �� ��.
		AFFECT_DATA_DICT[chr.NEW_AFFECT_DRAGON_SOUL_DECK1] = (localeInfo.TOOLTIP_DRAGON_SOUL_DECK1, "d:/ymir work/ui/dragonsoul/buff_ds_sky1.tga")
		AFFECT_DATA_DICT[chr.NEW_AFFECT_DRAGON_SOUL_DECK2] = (localeInfo.TOOLTIP_DRAGON_SOUL_DECK2, "d:/ymir work/ui/dragonsoul/buff_ds_land1.tga")

Alt�na ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		AFFECT_DATA_DICT[chr.NEW_AFFECT_SHOP_DOUBLE_UP]	= (localeInfo.TOOLTIP_SHOP_DOUBLE_UP, "d:/ymir work/ui/skill/common/affect/shop_bonus.tga")

Arat:
				if affect == chr.NEW_AFFECT_DRAGON_SOUL_DECK1 or affect == chr.NEW_AFFECT_DRAGON_SOUL_DECK2:
					image.SetScale(1, 1)

Alt�na ekle:

				elif app.ENABLE_OFFLINE_SHOP_SYSTEM and affect == chr.NEW_AFFECT_SHOP_DOUBLE_UP:
					image.SetScale(1, 1)
