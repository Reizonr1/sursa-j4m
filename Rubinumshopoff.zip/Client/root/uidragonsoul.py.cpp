Arat:
			elif player.SLOT_TYPE_SHOP == attachedSlotType:
				net.SendShopBuyPacket(attachedSlotPos)

Alt�na ekle (var ise d�zenle):

			elif app.ENABLE_OFFLINE_SHOP_SYSTEM and player.SLOT_TYPE_MYSHOP == attachedSlotType:
				mouseModule.mouseController.RunCallBack("INVENTORY", player.SLOT_TYPE_DRAGON_SOUL_INVENTORY, selectedSlotPos)
				print "ds debug4"