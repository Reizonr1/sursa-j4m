Arat:
				if not self.AttachedIconHandle:
					self.AttachedIconHandle = 0
					self.DeattachObject()
					return

Alt�na ekle:

			elif app.ENABLE_OFFLINE_SHOP_SYSTEM and Type == player.SLOT_TYPE_MYSHOP:

Bu kod var ise (Type == player.SLOT_TYPE_MYSHOP:) d�zenleyin