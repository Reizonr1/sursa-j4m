﻿import math

import ui
import snd
import shop
import mouseModule
import player
import chr
import net
import uiCommon
import localeInfo
import chat
import item
import systemSetting #±èÁØÈ£
import constInfo
import wndMgr
import uiScriptLocale
import background
import grp
import uiPickMoney
import app


class PrivateShopEditor(ui.ScriptWindow):
	dlgPickMoney = None

	def __init__(self):
		ui.ScriptWindow.__init__(self)

		self.offlineInfo = None
		self.__LoadWindow()

		self.tooltipItem = None
		self.priceInputBoard = None
		self.title = ""
		self.itemView = True
		self.previousName = ""
		self.interface = None

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def __LoadWindow(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "UIScript/PrivateShopEditor.py")
		except:
			import exception
			exception.Abort("PrivateShopBuilderWindow.LoadWindow.LoadObject")

		try:
			GetObject = self.GetChild
			self.board = GetObject("board")
			self.titleName = GetObject("TitleName")
			self.nameLine = GetObject("NameLine")
			self.nameSlot = GetObject("NameSlot")
			self.itemSlot = GetObject("ItemSlot")
			self.titleBar = GetObject("TitleBar")
			self.offlineInfo = GetObject("OfflineTime")
			self.goldStashWrapper = GetObject("GoldStashWrapper")
			self.goldStashValue = GetObject("GoldStashValue")
			self.offlineWrapper = GetObject("OfflineWrapper")
			self.closeButton = GetObject("CloseButton")
			self.locationValue = GetObject("LocationValue")
			self.wndMoneySlot = GetObject("GoldStash_Slot")
			self.closeShopText = GetObject("CloseShopText")
			#self.openShopButton = GetObject("OpenShopButton")
			#self.openShopSearchButton = GetObject("ShopSearchButton")
			#self.openShopText = GetObject("OpenShopText")
		except:
			import exception
			exception.Abort("PrivateShopBuilderWindow.LoadWindow.BindObject")

		self.titleBar.SetCloseEvent(ui.__mem_func__(self.OnClose))

		self.itemSlot.SetSelectEmptySlotEvent(ui.__mem_func__(self.OnSelectEmptySlot))
		self.itemSlot.SetSelectItemSlotEvent(ui.__mem_func__(self.OnSelectItemSlot))
		self.itemSlot.SetOverInItemEvent(ui.__mem_func__(self.OnOverInItem))
		self.itemSlot.SetOverOutItemEvent(ui.__mem_func__(self.OnOverOutItem))
		self.itemSlot.SetUnselectItemSlotEvent(ui.__mem_func__(self.RemoveFromShop))
		self.itemSlot.SetUseSlotEvent(ui.__mem_func__(self.RemoveFromShop))
		self.wndMoneySlot.SetEvent(ui.__mem_func__(self.OpenPickMoneyDialog))

		#self.openShopButton.SetEvent(ui.__mem_func__(self.OnOpenShopButton))
		#self.openShopSearchButton.SetEvent(ui.__mem_func__(self.OnOpenShopSearchButton))
		self.closeButton.SetEvent(ui.__mem_func__(self.OnCloseButton))
		self.nameLine.SetReturnEvent(ui.__mem_func__(self.AcceptNameChange))
		self.nameLine.SetEscapeEvent(ui.__mem_func__(self.OnPressEscapeKey))

		## PickMoneyDialog
		dlgPickMoney = uiPickMoney.PickMoneyDialog()
		dlgPickMoney.LoadDialog()
		dlgPickMoney.Hide()
		
		self.dlgPickMoney = dlgPickMoney

	def BindInterfaceClass(self, interface):
		self.interface = interface

	def Destroy(self):
		self.ClearDictionary()
		self.dlgPickMoney.Destroy()
		self.board = None
		self.titleName = None
		self.nameSlot = None
		self.nameLine = None
		self.itemSlot = None
		self.titleBar = None
		self.priceInputBoard = None
		self.offlineInfo = None
		self.goldStashValue = None
		self.goldStashWrapper = None
		self.offlineWrapper = None
		self.closeButton = None
		#self.openShopButton = None
		self.locationValue = None
		self.previousName = None
		self.dlgPickMoney = None

	def Open(self):
		shop.Open(True, True)
		self.SetCenterPosition()
		self.Refresh()
		self.Show()

	def Close(self):
		if self.dlgPickMoney:
			self.dlgPickMoney.Close()
		shop.Close()
		self.title = ""
		self.Hide()

	def SetItemToolTip(self, tooltipItem):
		self.tooltipItem = tooltipItem

	def SetItemView(self, newState):
		self.itemView = newState

	def IsItemView(self):
		return self.itemView
		
	def IsPriceDialogOpen(self):
		return self.priceInputBoard

	def Refresh(self):
		# Refresh item set
		getItemID=shop.GetItemID
		getItemCount=shop.GetItemCount
		setItemSlot=self.itemSlot.SetItemSlot
		
		self.title = shop.GetMyShopName()

		print "shopEditor: title is %s" % self.title
		
		if len(self.title) > 25:
			self.title = self.title[:22] + "..."

		self.nameLine.SetText(self.title)
		self.previousName = self.title

		hasItems = False
		for i in xrange(shop.SHOP_SLOT_COUNT):
			itemCount = long(getItemCount(i))
			if itemCount > 0:
				hasItems = True

			if itemCount <= 1:
				itemCount = 0

			setItemSlot(i, getItemID(i), itemCount)

		wndMgr.RefreshSlot(self.itemSlot.GetWindowHandle())

		self.closeButton.Hide()
		self.closeShopText.Hide()
		#self.openShopButton.Hide()
		#self.openShopText.Hide()

			#kapali dukkan
		# No item view but it has items - Switch to full
		if not self.IsItemView() and hasItems:
			self.itemSlot.Show()
			self.nameSlot.Show()
			self.titleName.SetText(uiScriptLocale.PRIVATE_SHOP_EDIT_TITLE)
			self.board.SetSize(self.board.GetWidth(), 328 + 26 + 26 + 32 + 48 + 15 + 110) ## aktif pazar yuksekligi
			self.SetSize(self.GetWidth(), 328 + 26 + 26 + 32 + 48 + 15 + 110)
			self.offlineWrapper.SetPosition(15, 25 + 9 + 390) ## aktif pazar ayarlari
			self.offlineWrapper.SetSize(self.offlineWrapper.GetWidth(), 108)
			self.goldStashWrapper.SetPosition(27, 295 + 26 + 32 + 32 + 20 + 15 + 11 + 100) ## aktif yang yeri
			self.closeButton.Show()
			self.closeShopText.Show()
			self.locationValue.Show()
			#self.openShopButton.Hide()
			#self.openShopText.Hide()

			self.SetItemView(True)

		# In full view but has no items - Switch to no item view
		elif self.IsItemView() and not hasItems:
			self.itemSlot.Hide()
			self.nameSlot.Hide()
			self.titleName.SetText(uiScriptLocale.PRIVATE_SHOP_EMPTY)
			self.board.SetSize(self.board.GetWidth(), 150)
			self.SetSize(self.GetWidth(), 150)
			self.offlineWrapper.SetPosition(12, 33) ##pasif pazar ayarları
			self.goldStashWrapper.SetPosition(0, 40 + 65)
			self.closeButton.Hide()
			self.locationValue.Hide()
			self.closeShopText.Hide()
			#self.openShopButton.Show()
			#self.openShopText.Show()
			
			#acik dukkan
			self.SetItemView(False)
		elif self.IsItemView() and hasItems:
			self.itemSlot.Show()
			self.nameSlot.Show()
			self.titleName.SetText(uiScriptLocale.PRIVATE_SHOP_EDIT_TITLE)
			self.board.SetSize(self.board.GetWidth(), 328 + 26 + 26 + 32 + 48 + 15 + 110) ## aktif pazar yuksekligi
			self.SetSize(self.GetWidth(), 328 + 26 + 26 + 32 + 48 + 15 + 110)
			self.offlineWrapper.SetPosition(15, 25 + 9 + 390) ## aktif pazar ayarlari
			self.offlineWrapper.SetSize(self.offlineWrapper.GetWidth(), 108)
			self.goldStashWrapper.SetPosition(27, 295 + 26 + 32 + 32 + 20 + 15 + 11 + 100) ## aktif yang yeri
			self.closeButton.Show()
			self.closeShopText.Show()
			self.locationValue.Show()
			#self.openShopButton.Hide()
			#self.openShopText.Hide()

		elif not self.IsItemView() and not hasItems:
			self.itemSlot.Hide()
			self.nameSlot.Hide()
			self.titleName.SetText(uiScriptLocale.PRIVATE_SHOP_EMPTY)
			self.board.SetSize(self.board.GetWidth(), 150)
			self.SetSize(self.GetWidth(), 150)
			self.offlineWrapper.SetPosition(12, 33) ##pasif pazar ayarları
			self.goldStashWrapper.SetPosition(0, 40 + 65)
			self.closeButton.Hide()
			self.locationValue.Hide()
			self.closeShopText.Hide()
			#self.openShopButton.Show()
			#self.openShopText.Show()

		# Refresh offline info

		## Offline minutes
		offlineMinutes = shop.GetOfflineMinutes() + shop.GetPremiumMinutes()
		offlinehours = math.floor(offlineMinutes/60)
		offlineMinutes -= offlinehours*60

		minuteStr = str(int(offlineMinutes))
		if offlineMinutes < 10:
			minuteStr = "0" + minuteStr
			
		prettyTimeOffline = str(int(offlinehours))+"h "+minuteStr+"m"
		self.offlineInfo.SetText(prettyTimeOffline)

		## Gold stash
		goldStash = long(shop.GetStashValue())
		
		prettyStash = localeInfo.NumberToMoneyString(goldStash)
		self.goldStashValue.SetText(prettyStash)

		## Location:
		locationText = ""
		(channel, xPos, yPos) = shop.GetLocation()
		(mapName, xBase, yBase) = background.GlobalPositionToMapInfo(xPos, yPos)
		
		localeMapName = localeInfo.MINIMAP_ZONE_NAME_DICT.get(mapName, "")
		if localeMapName != "":						
			locationText += localeInfo.TOOLTIP_MEMORIZED_POSITION % (localeMapName, int(xPos-xBase)/100, int(yPos-yBase)/100)

		locationText += " " + "CH" + str(channel)
		self.locationValue.SetText(locationText)

	def OpenPickMoneyDialog(self):

		if mouseModule.mouseController.isAttached():
			mouseModule.mouseController.DeattachObject()
		else:
			curMoney = long(shop.GetStashValue())

			if curMoney <= 0:
				return

			self.dlgPickMoney.SetTitleName(localeInfo.PICK_MONEY_TITLE)
			self.dlgPickMoney.SetAcceptEvent(ui.__mem_func__(self.OnClickWithdraw))
			self.dlgPickMoney.Open(curMoney)
			self.dlgPickMoney.SetMax(13) # ÀÎº¥Åä¸® 990000 Á¦ÇÑ ¹ö±× ¼öÁ¤

	def OnSelectEmptySlot(self, selectedSlotPos):

		isAttached = mouseModule.mouseController.isAttached()
		if isAttached:
			attachedSlotType = mouseModule.mouseController.GetAttachedType()
			attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
			mouseModule.mouseController.DeattachObject()

			if app.ENABLE_SPECIAL_STORAGE:
				if player.SLOT_TYPE_INVENTORY != attachedSlotType and player.SLOT_TYPE_DRAGON_SOUL_INVENTORY != attachedSlotType and player.SLOT_TYPE_UPGRADE_INVENTORY != attachedSlotType and player.SLOT_TYPE_BOOK_INVENTORY != attachedSlotType and player.SLOT_TYPE_STONE_INVENTORY != attachedSlotType:
					return
			else:
				if player.SLOT_TYPE_INVENTORY != attachedSlotType and player.SLOT_TYPE_DRAGON_SOUL_INVENTORY != attachedSlotType:
					return

			attachedInvenType = player.SlotTypeToInvenType(attachedSlotType)
				
			itemVNum = player.GetItemIndex(attachedInvenType, attachedSlotPos)
			item.SelectItem(itemVNum)

			if item.IsAntiFlag(item.ANTIFLAG_GIVE) or item.IsAntiFlag(item.ANTIFLAG_MYSHOP):
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.PRIVATE_SHOP_CANNOT_SELL_ITEM)
				return

			priceInputBoard = uiCommon.MoneyInputDialog()
			priceInputBoard.SetTitle(localeInfo.PRIVATE_SHOP_INPUT_PRICE_DIALOG_TITLE)
			priceInputBoard.SetAcceptEvent(ui.__mem_func__(self.AcceptInputPrice))
			priceInputBoard.SetCancelEvent(ui.__mem_func__(self.CancelInputPrice))
			priceInputBoard.Open()

			# itemPrice=GetPrivateShopItemPrice(itemVNum)

			#if itemPrice>0:
			#	priceInputBoard.SetValue(itemPrice)
			
			self.priceInputBoard = priceInputBoard
			self.priceInputBoard.itemVNum = itemVNum
			self.priceInputBoard.sourceWindowType = attachedInvenType
			self.priceInputBoard.sourceSlotPos = attachedSlotPos
			self.priceInputBoard.targetSlotPos = selectedSlotPos

	def OnSelectItemSlot(self, selectedSlotPos):
		if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS() == 1:
			return

		isAttached = mouseModule.mouseController.isAttached()
		if isAttached:
			return

		selectedItemID = shop.GetItemID(selectedSlotPos)
		itemCount = shop.GetItemCount(selectedSlotPos)

		mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_MYSHOP, selectedSlotPos, selectedItemID, itemCount)
		mouseModule.mouseController.SetCallBack("INVENTORY", ui.__mem_func__(self.DropToWindow))
		snd.PlaySound("sound/ui/pick.wav")

	def AcceptInputPrice(self):

		if not self.priceInputBoard:
			return True

		text = self.priceInputBoard.GetText()

		if not text:
			return True

		if not text.isdigit():
			return True

		if long(text) <= 0:
			return True

		attachedInvenType = self.priceInputBoard.sourceWindowType
		sourceSlotPos = self.priceInputBoard.sourceSlotPos
		targetSlotPos = self.priceInputBoard.targetSlotPos
		price = long(self.priceInputBoard.GetText())

		# Should we?

		#if IsPrivateShopItemPriceList():
		#	SetPrivateShopItemPrice(self.priceInputBoard.itemVNum, price)

		net.SendAddItemToMyShop(attachedInvenType, sourceSlotPos, targetSlotPos, long(price))
		snd.PlaySound("sound/ui/drop.wav")

		self.Refresh()

		#####

		self.priceInputBoard = None
		return True

	def CancelInputPrice(self):
		self.priceInputBoard = None
		return True

	def OnClose(self):
		self.Close()

	def OnPressEscapeKey(self):
		self.Close()
		return True

	def OnOverInItem(self, slotIndex):
		if self.tooltipItem:
			self.tooltipItem.SetShopItem(slotIndex)

	def OnOverOutItem(self):
		if self.tooltipItem:
			self.tooltipItem.HideToolTip()

	def OnClickWithdraw(self, money):
		import dbg
		dbg.TraceError("Trying to withdraw %d gold" % long(money))
		net.SendWithdrawMyShopGold(long(money))

	def OnCloseButton(self):
		net.SendCloseMyShop();

	#def OnOpenShopButton(self):
		#net.SendOpenMyShop();

	#def OnOpenShopSearchButton(self):
		#net.SendOpenMyShopSearch();

	def AcceptNameChange(self):
		newName = self.nameLine.GetText()
		if self.previousName != newName:
			self.previousName = newName
			net.SendRenameMyShop(newName)
		
	def DropToWindow(self, windowType, target):
		if not mouseModule.mouseController.isAttached():
			print "DropToWindow: Not attached!"
			return

		attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
		self.AskRemoveItem(attachedSlotPos, player.SlotTypeToInvenType(windowType), target)

	def RemoveFromShop(self, slotIndex):
		itemVnum = shop.GetItemID(slotIndex)
		item.SelectItem(itemVnum)
		itemType = item.GetItemType()

		if itemType != item.ITEM_TYPE_DS:
			inventory = player.SLOT_TYPE_INVENTORY
		else:
			inventory = player.SLOT_TYPE_DRAGON_SOUL_INVENTORY

		self.AskRemoveItem(slotIndex, player.SlotTypeToInvenType(inventory), 0)

	def AskRemoveItem(self, slotPos, targetWindow, targetPos):		
		itemIndex = shop.GetItemID(slotPos)
		itemPrice = shop.GetItemPrice(slotPos)
		itemCount = shop.GetItemCount(slotPos)

		item.SelectItem(itemIndex)
		itemName = item.GetItemName()

		removeQuestion = uiCommon.QuestionDialog()
		removeQuestion.SetText(localeInfo.DO_YOU_REMOVE_ITEM_FROM_SHOP % itemName)
		removeQuestion.SetAcceptEvent(lambda arg=True: self.AnswerRemoveItem(arg))
		removeQuestion.SetCancelEvent(lambda arg=False: self.AnswerRemoveItem(arg))
		removeQuestion.Open()
		removeQuestion.pos = slotPos
		removeQuestion.targetPos = targetPos
		removeQuestion.targetWindow = targetWindow
		
		self.removeQuestion = removeQuestion
		
		constInfo.SET_ITEM_QUESTION_DIALOG_STATUS(1)

	def AnswerRemoveItem(self, arg):
		if arg:
			slotPos = self.removeQuestion.pos
			targetPos = self.removeQuestion.targetPos
			targetWindow = self.removeQuestion.targetWindow
			
			print "Requesting removal of "+str(slotPos)+" (Over to "+str(targetPos)+" at "+str(targetWindow)+")"
			net.SendRemoveItemFromMyShop(slotPos, targetWindow, targetPos)

		self.removeQuestion.Close()
		self.removeQuestion = None

		constInfo.SET_ITEM_QUESTION_DIALOG_STATUS(0)
	
	# def OnUpdate(self):
		# if self.nameLine:
			# if self.nameLine.GetText() == shop.GetMyShopName():
				# self.nameLine.SetTextColor(grp.GenerateColor(1.0, 1.0, 1.0, 0.8))
			# else:
				# self.nameLine.SetTextColor(grp.GenerateColor(1.0, 0.54902, 0.0, 1.0))
