Arat:
		if isPrivateShop:
			self.__HideMiddleTabs()
			self.__HideSmallTabs()

Alt�na ekle:

			if app.ENABLE_OFFLINE_SHOP_SYSTEM:
				titleDict = self.interface.privateShopAdvertisementBoardDict
				if vid in titleDict:
					title = titleDict[vid].title
					if len(title) > 20:
						title = title[:17] + "..."
					self.titleName.SetText(title)
				else:
					self.titleName.SetText(uiScriptLocale.SHOP_TITLE)
				# Mark this shop as recently visited
				if vid in titleDict:
					titleDict[vid].MarkSeen()
