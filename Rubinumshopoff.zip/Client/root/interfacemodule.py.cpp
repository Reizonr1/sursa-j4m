M�sait bir yere ekle:

if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	import uiPrivateShopEditor

Arat:
		self.guildScoreBoardDict = {}
		self.equipmentDialogDict = {}

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.privateShopEditor = None
			self.queuedShopEditor = False

Arat:
		wndMiniMap = uiMiniMap.MiniMap()
		wndMiniMap.BindInterface(self)
		wndSafebox = uiSafebox.SafeboxWindow()

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			wndPrivateShopEditor = uiPrivateShopEditor.PrivateShopEditor()
			wndPrivateShopEditor.BindInterfaceClass(self)

Arat:
		self.wndCharacter = wndCharacter
		self.wndInventory = wndInventory

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.privateShopEditor = wndPrivateShopEditor
			self.privateShopEditor.Hide()	

Arat:
		if app.ENABLE_DRAGON_SOUL_SYSTEM:
			self.wndDragonSoul.SetItemToolTip(self.tooltipItem)
			self.wndDragonSoulRefine.SetItemToolTip(self.tooltipItem)

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.privateShopEditor.SetItemToolTip(self.tooltipItem)

Arat:
		if self.privateShopBuilder:
			self.privateShopBuilder.Destroy()

Alt�na ekle:
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if self.privateShopEditor:
				self.privateShopEditor.Destroy()

Arat:
		del self.privateShopBuilder

Alt�na ekle:
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			del self.privateShopEditor

Arat:
	def OpenShopDialog(self, vid):

Alt�na ekle:
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if self.privateShopEditor.IsShow():
				self.privateShopEditor.Close()

Arat:
	def CloseShopDialog(self):
		self.dlgShop.Close()

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if self.queuedShopEditor:
				self.privateShopEditor.Open()
				self.privateShopEditor.SetTop()
				self.queuedShopEditor = False

Arat:
	def AppearPrivateShop(self, vid, text):

De�i�tir:

	def AppearPrivateShop(self, vid, text):
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if self.privateShopAdvertisementBoardDict.has_key(vid):
				# Board is already created, no need to create a new one. Simply update title (just in case it changed)
				self.privateShopAdvertisementBoardDict[vid].UpdateTitle(text)
				return
		board = uiPrivateShopBuilder.PrivateShopAdvertisementBoard()
		board.Open(vid, text)
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			board.Hide() # Hidden by default!

			print "Appear shop: "+str(vid)+"\n"
		self.privateShopAdvertisementBoardDict[vid] = board



