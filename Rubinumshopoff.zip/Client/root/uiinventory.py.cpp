�mportlara ekle:
if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	import uiPrivateShopEditor

Arat:
	def OpenPickMoneyDialog(self):

�st�ne ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def ClickShopButton(self):
			# If there's a shop open, close it and queue the editor
			if shop.IsOpen():
				net.SendShopEndPacket()
				self.interface.queuedShopEditor = True
				return

			shopView = self.interface.privateShopEditor
			shopView.Open()
			shopView.SetTop()

Arat:
			elif player.SLOT_TYPE_MALL == attachedSlotType:
				net.SendMallCheckoutPacket(attachedSlotPos, selectedSlotPos)

Ekleyece�imiz �ey var ise d�zenleyin yoksa alt�na ekleyin:

			elif app.ENABLE_OFFLINE_SHOP_SYSTEM and player.SLOT_TYPE_MYSHOP == attachedSlotType:
				mouseModule.mouseController.RunCallBack("INVENTORY", player.SLOT_TYPE_INVENTORY, selectedSlotPos)

Arat:
	def __SendUseItemToItemPacket(self, srcSlotPos, dstSlotPos):

Tamamen de�i�tir:

	def __SendUseItemToItemPacket(self, srcSlotPos, dstSlotPos):
		# ���λ��� ���� �ִ� ���� ������ ��� ����
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if uiPrivateShopBuilder.IsBuildingPrivateShop() or self.interface.privateShopEditor.IsPriceDialogOpen():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.USE_ITEM_FAILURE_PRIVATE_SHOP)
				return
		else:
			if uiPrivateShopBuilder.IsBuildingPrivateShop():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.USE_ITEM_FAILURE_PRIVATE_SHOP)
				return

		net.SendItemUseToItemPacket(srcSlotPos, dstSlotPos)

Arat:
	def __SendUseItemPacket(self, slotPos):

Tamamen de�i�tir:

	def __SendUseItemPacket(self, slotPos):
		# ���λ��� ���� �ִ� ���� ������ ��� ����
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if uiPrivateShopBuilder.IsBuildingPrivateShop() or self.interface.privateShopEditor.IsPriceDialogOpen():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.USE_ITEM_FAILURE_PRIVATE_SHOP)
				return
		else:
			if uiPrivateShopBuilder.IsBuildingPrivateShop():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.USE_ITEM_FAILURE_PRIVATE_SHOP)
				return

		net.SendItemUsePacket(slotPos)

Arat:
	def __SendMoveItemPacket(self, srcSlotPos, dstSlotPos, srcItemCount):

De�i�tir:

	def __SendMoveItemPacket(self, srcSlotPos, dstSlotPos, srcItemCount):
		# ���λ��� ���� �ִ� ���� ������ ��� ����
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			if uiPrivateShopBuilder.IsBuildingPrivateShop() or self.interface.privateShopEditor.IsPriceDialogOpen():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.MOVE_ITEM_FAILURE_PRIVATE_SHOP)
				return
		else:
			if uiPrivateShopBuilder.IsBuildingPrivateShop():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.MOVE_ITEM_FAILURE_PRIVATE_SHOP)
				return

		net.SendItemMovePacket(srcSlotPos, dstSlotPos, srcItemCount)
