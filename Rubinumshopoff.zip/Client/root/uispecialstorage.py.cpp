Arat:
			elif player.SLOT_TYPE_MALL == attachedSlotType:
				net.SendMallCheckoutPacket(attachedSlotPos, self.SLOT_WINDOW_TYPE[self.categoryPageIndex]["window"], selectedSlotPos)

Alt�na ekle (var ise d�zenleyin):
			elif app.ENABLE_OFFLINE_SHOP_SYSTEM and player.SLOT_TYPE_MYSHOP == attachedSlotType:
				mouseModule.mouseController.RunCallBack("INVENTORY", self.SLOT_WINDOW_TYPE[self.categoryPageIndex]["slot"], selectedSlotPos)
