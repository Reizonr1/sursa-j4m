M�sait bir yere ekle:

if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	ALREADY_SALE_LIST = []
