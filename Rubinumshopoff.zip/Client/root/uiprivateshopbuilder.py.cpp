importlar�n alt�na ekle:

if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	g_privateShopAdvertisementLastViewed = {}
	g_displayedBoardVIDList = []

Arat:
def DeleteADBoard(vid):
	if not g_privateShopAdvertisementBoardDict.has_key(vid):
		return

�st�ne ekle:

if not app.ENABLE_OFFLINE_SHOP_SYSTEM:
	def UpdateADBoard():
		for key in g_privateShopAdvertisementBoardDict.keys():
			g_privateShopAdvertisementBoardDict[key].Show()

Arat:
def DeleteADBoard(vid):

Tamemen de�i�tir:

def DeleteADBoard(vid):
	if not g_privateShopAdvertisementBoardDict.has_key(vid):
		return

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		global g_privateShopAdvertisementLastViewed
		board = g_privateShopAdvertisementBoardDict[vid]
		# If we had offline time, and it should persist, save it so that it does
		if board.lastSeen > 0 and board.lastSeen + PrivateShopAdvertisementBoard.viewedPersistMinutes*60 > app.GetTime():
			g_privateShopAdvertisementLastViewed[vid] = board.lastSeen

	del g_privateShopAdvertisementBoardDict[vid]

if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	def RefreshShopBoards():
		global g_displayedBoardVIDList

		# Initialization
		showSalesText = systemSetting.IsShowSalesText()
		allBoardVIDList = g_privateShopAdvertisementBoardDict.keys()
		dictKeys = []

		# Limit the display of shops to those around us if we've chosen to display all
		if showSalesText: 
			boardsDist = {}
			for vid in allBoardVIDList:
				dist = player.GetCharacterDistance(vid)
				if dist > 3000: # Too far!
					continue

				boardsDist[vid] = dist

			# This will get us a new keys tuple with the keys sorted
			dictKeys = sorted(boardsDist, key=boardsDist.get)

			# And then we'll pick the first few (i.e those closest to us)
			# ...as well as the board we are hovering / selected
			dictKeys = dictKeys[0:systemSetting.GetNearbyShopsDisplayed()]

		# We'll always display the selected target and the hovered target's names.
		dictKeys = [player.GetTargetVID(), chr.Pick()] + dictKeys

		for vid in dictKeys:
			if not vid in allBoardVIDList:
				continue

			board = g_privateShopAdvertisementBoardDict[vid]
			board.Show()
			x, y = chr.GetProjectPosition(vid, 220)
			board.SetPosition(x - board.GetWidth()/2, y - board.GetHeight()/2)

			# Return back to the color if it's required
			if board.bg == "purple" and board.lastSeen + board.viewedPersistMinutes * 60 < app.GetTime():
				board.MarkUnseen()
	
		# Hide the ones that were visible before but are not now
		for vid in g_displayedBoardVIDList:
			if vid not in dictKeys and vid in allBoardVIDList:
				g_privateShopAdvertisementBoardDict[vid].Hide()

		# Update the visible board tuple
		g_displayedBoardVIDList = dictKeys

Arat:
class PrivateShopAdvertisementBoard(ui.ThinBoard):

Alt�na ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
# D�kkan�n farkl� "g�r�nt�lenen" rengini g�r�nt�leyece�i dakikalar.
		viewedPersistMinutes = 30

Arat:
	def __init__(self):
		ui.ThinBoard.__init__(self, "UI_BOTTOM")
		self.vid = None

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.title = ""
			self.bg = "new"
			self.lastSeen = 0

Arat:
	def Open(self, vid, text):

De�i�tir ( kendinize g�re d�zenleyiniz)

	def Open(self, vid, text):
		self.vid = vid
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.title = text
		self.shopPreview = PrivateShopPreview()
		self.textLine.SetText(text)
		self.textLine.UpdateRect()
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.SetSize(len(text)*6 + 10*2, 10)
		else:
			self.SetSize(len(text)*6 + 10*2, 20)
			self.Show()

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			# Load the last viewed time from our cache (if it exists)
			if vid in g_privateShopAdvertisementLastViewed:
				self.lastSeen = g_privateShopAdvertisementLastViewed[vid]
				self.UpdatePattern("purple")

		g_privateShopAdvertisementBoardDict[vid] = self

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def UpdateTitle(self, text):
			self.title = text

Arat:
	def OnMouseLeftButtonUp(self):
		if not self.vid:
			return
		net.SendOnClickPacket(self.vid)

		return True

Alt�na ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def UpdatePattern(self, name):
			if self.bg == name:
				return

			self.bg = name
			self.SetPattern(name)
			self.SetSize(len(self.title)*6 + 10*2, 10) # This is required because load image screws up the resulting image	

		def MarkUnseen(self):
			self.UpdatePattern("new")

		def MarkSeen(self):
			self.lastSeen = app.GetTime()
			self.UpdatePattern("purple")

		def Destroy(self):
			DeleteADBoard(self.vid)
			
		def OnUpdate(self):
			if app.ENABLE_SHOP_ITEM_PREVIEW:
				if self.IsInPosition():
					if self.shopPreview:
						self.shopPreview.Open(self.vid, self.itemList)
				else:
					if self.shopPreview:
						self.shopPreview.Close()
	else:
		def OnUpdate(self):
			if not self.vid:
				return

			if systemSetting.IsShowSalesText():
				self.Show()
				x, y = chr.GetProjectPosition(self.vid, 220)
				self.SetPosition(x - self.GetWidth()/2, y - self.GetHeight()/2)

			else:
				for key in g_privateShopAdvertisementBoardDict.keys():
					if  player.GetMainCharacterIndex() == key:  #����ǳ���� �Ⱥ��̰� ���ߴ� ��쿡��, �÷��̾� �ڽ��� ���� ǳ���� ���̵��� ��. by ����ȣ
						g_privateShopAdvertisementBoardDict[key].Show()
						x, y = chr.GetProjectPosition(player.GetMainCharacterIndex(), 220)
						g_privateShopAdvertisementBoardDict[key].SetPosition(x - self.GetWidth()/2, y - self.GetHeight()/2)
					else:
						g_privateShopAdvertisementBoardDict[key].Hide()



