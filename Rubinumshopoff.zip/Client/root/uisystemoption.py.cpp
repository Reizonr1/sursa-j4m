Arat:
		self.cameraModeButtonList = []
		self.fogModeButtonList = []
		self.tilingModeButtonList = []
		self.ctrlShadowQuality = 0


Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.ctrlDisplayedShops = 0
			self.shopDisplayedAmount = 0
			self.shopDisplayedInfoLabel = 0

Arat:
			self.fogModeButtonList.append(GetObject("fog_level2"))
			self.tilingModeButtonList.append(GetObject("tiling_cpu"))
			self.tilingModeButtonList.append(GetObject("tiling_gpu"))
			self.tilingApplyButton=GetObject("tiling_apply")
			self.ctrlShadowQuality = GetObject("shadow_bar")

Alt�na ekle:

			if app.ENABLE_OFFLINE_SHOP_SYSTEM:
				self.shopDisplayedInfoLabel = GetObject("displayed_shop_info")
				self.ctrlDisplayedShops = GetObject("displayed_shops_controller")
				self.shopDisplayedAmount = GetObject("displayed_shops_amount")

Arat:
		self.__ClickRadioButton(self.fogModeButtonList, constInfo.GET_FOG_LEVEL_INDEX())
		self.__ClickRadioButton(self.cameraModeButtonList, constInfo.GET_CAMERA_MAX_DISTANCE_INDEX())
		if app.ENABLE_ENVIRONMENT_EFFECT_OPTION:
			self.__ClickRadioButton(self.snowModeButton, not systemSetting.IsEnableSnowFall())

		if musicInfo.fieldMusic==musicInfo.METIN2THEMA:
			self.selectMusicFile.SetText(uiSelectMusic.DEFAULT_THEMA)
		else:
			self.selectMusicFile.SetText(musicInfo.fieldMusic[:MUSIC_FILENAME_MAX_LEN])

Alt�na ekle:
		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			self.shopDisplayedAmount.SetText(str(systemSetting.GetNearbyShopsDisplayed()))
			self.ctrlDisplayedShops.SetSliderPos((math.ceil(float(systemSetting.GetNearbyShopsDisplayed())/5) - 1)*0.15)
			self.ctrlDisplayedShops.SetEvent(ui.__mem_func__(self.OnChangeDisplayedShops))

Arat:

	def OnChangeShadowQuality(self):
		pos = self.ctrlShadowQuality.GetSliderPos()
		systemSetting.SetShadowLevel(int(pos / 0.2))

Alt�na ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def OnChangeDisplayedShops(self):
			#MaviAy44 fix
			newValue = int(5*(math.floor(self.ctrlDisplayedShops.GetSliderPos() / 0.15 + 0.5) + 1))
			systemSetting.SetNearbyShopsDisplayed(newValue)
			self.shopDisplayedAmount.SetText(str(newValue))
