importlara ekle:
if app.ENABLE_OFFLINE_SHOP_SYSTEM:
	from uiPrivateShopEditor import PrivateShopEditor


Arat:
	def SetShopSellingPrice(self, Price):
		pass

Alt�na ekle:
	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def OpenShopEditor(self):
			""" 
				Open our shop editor directly. This will be triggered
				when the player clicks their own shop board.
			"""

			if self.interface.dlgShop.IsShow():
				self.interface.queuedShopEditor = True
				net.SendShopEndPacket()
				return
			
			self.interface.privateShopEditor.Open()
			self.interface.privateShopEditor.SetTop()


Arat:
	def OnRender(self):
		app.RenderGame()

		if self.console.Console.collision:
			background.RenderCollision()
			chr.RenderCollision()

		(x, y) = app.GetCursorPosition()

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			uiPrivateShopBuilder.RefreshShopBoards()

Arat:
			# WEDDING
			"lover_login"			: self.__LoginLover,
			"lover_logout"			: self.__LogoutLover,
			"lover_near"			: self.__LoverNear,
			"lover_far"				: self.__LoverFar,
			"lover_divorce"			: self.__LoverDivorce,
			"PlayMusic"				: self.__PlayMusic,
			# END_OF_WEDDING

			# PRIVATE_SHOP_PRICE_LIST
			"MyShopPriceList"		: self.__PrivateShop_PriceList,
			# END_OF_PRIVATE_SHOP_PRICE_LIST
		}

Alt�na ekle:

		if app.ENABLE_OFFLINE_SHOP_SYSTEM:
			serverCommandList["ShopSaleResult"] = self.PrivateShopSaleResult

Arat:
	def BINARY_PrivateShop_Disappear(self, vid):
		self.interface.DisappearPrivateShop(vid)

Alt�na ekle:

	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def RefreshShopInfo(self):
			if self.interface:
				if self.interface.privateShopEditor:
					self.interface.privateShopEditor.Refresh()

En alta m�sait bir yere ekle:
	if app.ENABLE_OFFLINE_SHOP_SYSTEM:
		def PrivateShopSaleResult(self, itemCount, itemName, gold, pos):
			if not pos in constInfo.ALREADY_SALE_LIST:
				self.newPopup = uiCommon.NewPopup()
				self.newPopup.SetUserName(localeInfo.SHOP_SALE_RESULT % (itemCount, itemName, localeInfo.PrettyNumber(int(gold))), "d:/ymir work/ui/game/windows/money_icon.sub")
				self.newPopup.SlideIn()

				constInfo.ALREADY_SALE_LIST.append(pos)
