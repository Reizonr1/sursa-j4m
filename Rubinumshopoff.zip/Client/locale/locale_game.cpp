DO_YOU_REMOVE_ITEM_FROM_SHOP	%s isimli nesneyi d�kkan�ndan kald�rmak istiyor musun?
TOOLTIP_SHOP_DOUBLE_UP	D�kkan s�ren 2 kat h�zl� dolacak	SNA
