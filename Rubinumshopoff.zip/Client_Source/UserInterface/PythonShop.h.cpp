Arat:
class CPythonShop : public CSingleton<CPythonShop>
{
	public:
		CPythonShop(void);
		virtual ~CPythonShop(void);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		struct ShopPosition
		{
			ShopPosition() : channel(0), x(0), y(0) {};
			int channel,x, y;
		};
#endif

Arat:
		void Clear();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		void ClearMyShopInfo();
#endif

Arat:
		const char* GetTabName(BYTE tabIdx);

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		void SetMyShopItemData(DWORD dwIndex, const TShopItemData & c_rShopItemData);
		void SetMyShopName(std::string name) { m_myShopName = name; };
		std::string GetMyShopName() const { return m_myShopName; }
#endif

Arat:
		void BuildPrivateShop(const char * c_szName);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		void SetOfflineMinutes(int minutes)	{ m_offlineMinutes = minutes; }
		int GetOfflineMinutes() { return m_offlineMinutes; }
		void SetPremiumMinutes(int minutes) { m_premiumMinutes = minutes; }
		int GetPremiumMinutes() { return m_premiumMinutes; }

		void SetStashValue(unsigned long long value) { m_stashValue = value; }
		unsigned long long GetStashValue() const
		{ return m_stashValue; }


		void SetLocation(int channel, int x, int y) { m_shopPosition.channel = channel; m_shopPosition.x = x; m_shopPosition.y = y; }
		const ShopPosition& GetLocation() { return m_shopPosition; }
#endif


Arat:
	protected:
		BOOL				m_isShoping;
		BOOL				m_isPrivateShop;
		BOOL				m_isMainPlayerPrivateShop;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		ShopPosition m_shopPosition;

		int m_offlineMinutes;
		int m_premiumMinutes;
		unsigned long long m_stashValue;
#endif


Arat:
		typedef std::map<TItemPos, TShopItemTable> TPrivateShopItemStock;
		TPrivateShopItemStock	m_PrivateShopItemStock;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		std::string m_myShopName;
		ShopTab m_aMyShop;
#endif