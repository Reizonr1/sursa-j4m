En altta } �st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	PyModule_AddIntConstant(poModule, "SLOT_TYPE_MYSHOP", SLOT_TYPE_MYSHOP);
#endif