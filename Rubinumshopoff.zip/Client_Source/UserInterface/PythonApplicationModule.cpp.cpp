M�sait bir yere ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	PyModule_AddIntConstant(poModule, "ENABLE_OFFLINE_SHOP_SYSTEM", 1);
#else
	PyModule_AddIntConstant(poModule, "ENABLE_OFFLINE_SHOP_SYSTEM", 0);
#endif
