Arat:
			NEW_AFFECT_GOLD_BONUS			= 506,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			NEW_AFFECT_SHOP_DOUBLE_UP		= 507,
#endif

Arat:
			NAMECOLOR_MOB,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			NAMECOLOR_SHOP,
#endif

Arat:
		BOOL					IsObject();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		BOOL					IsShop();
#endif