Arat:
	if(kNetActorData.m_bType != CActorInstance::TYPE_PC && kNetActorData.m_bType != CActorInstance::TYPE_NPC)

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if(kNetActorData.m_bType != CActorInstance::TYPE_PC && 	kNetActorData.m_bType != CActorInstance::TYPE_NPC && kNetActorData.m_bType != CActorInstance::TYPE_SHOP)
#else
	if(kNetActorData.m_bType != CActorInstance::TYPE_PC && kNetActorData.m_bType != CActorInstance::TYPE_NPC)
#endif