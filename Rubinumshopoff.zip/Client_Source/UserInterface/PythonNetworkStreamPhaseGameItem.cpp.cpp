En alta ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
bool CPythonNetworkStream::RecvShopItemData()
{
	TPacketPlayerShopSet shop_item_set;

	if (!Recv(sizeof(TPacketPlayerShopSet), &shop_item_set))
		return false;

	TShopItemData kShopItemData;
	kShopItemData.vnum = shop_item_set.vnum;
	kShopItemData.count = shop_item_set.count;
	kShopItemData.price = shop_item_set.price;
#ifdef ENABLE_BUY_WITH_ITEM
	kShopItemData.witemVnum = 0;
#endif
	for (int i = 0; i < ITEM_SOCKET_SLOT_MAX_NUM; ++i)
		kShopItemData.alSockets[i] = shop_item_set.alSockets[i];
	for (int j = 0; j < ITEM_ATTRIBUTE_SLOT_MAX_NUM; ++j)
		kShopItemData.aAttr[j] = shop_item_set.aAttr[j];

	CPythonShop& rkShop = CPythonShop::Instance();
	rkShop.SetMyShopItemData(shop_item_set.pos, kShopItemData);
	__RefreshShopInfoWindow();

	return true;
}
#endif
