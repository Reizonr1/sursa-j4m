Arat:
	if (!pkInstTarget->IsPC() && !pkInstTarget->IsBuilding())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!pkInstTarget->IsPC() && !pkInstTarget->IsBuilding() && !pkInstTarget->IsShop())
#else
	if (!pkInstTarget->IsPC() && !pkInstTarget->IsBuilding())
#endif

Arat:
	PyCallClassMemberFunc(m_ppyGameWindow, "SetPCTargetBoard", Py_BuildValue("(is)", pkInstTarget->GetVirtualID(), pkInstTarget->GetNameString()));

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	DWORD vid = pkInstTarget->GetVirtualID();
	if (pkInstTarget->IsShop())
		vid = 0;

	PyCallClassMemberFunc(m_ppyGameWindow, "SetPCTargetBoard", Py_BuildValue("(is)", vid, pkInstTarget->GetNameString()));
#else
	PyCallClassMemberFunc(m_ppyGameWindow, "SetPCTargetBoard", Py_BuildValue("(is)", pkInstTarget->GetVirtualID(), pkInstTarget->GetNameString()));
#endif