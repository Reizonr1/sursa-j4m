Arat:
			TYPE_TARGET,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			TYPE_SHOP,
#endif

Arat:
		void ClearAtlasMarkInfo();
Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		void ClearAtlasShopInfo();
#endif

Arat:
		TAtlasMarkInfoVector					m_AtlasNPCInfoVector;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		TAtlasMarkInfoVector					m_AtlasShopInfoVector;
#endif