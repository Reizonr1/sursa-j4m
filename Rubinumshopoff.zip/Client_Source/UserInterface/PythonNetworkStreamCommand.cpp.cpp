Arat:

			case SHOP_SUBHEADER_GC_INVALID_POS:
				PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "OnShopError", Py_BuildValue("(s)", "INVALID_POS"));
				break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			case SHOP_SUBHEADER_GC_OPEN_SHOP_EDITOR:
				PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "OpenShopEditor", Py_BuildValue("()"));
				break;
#endif