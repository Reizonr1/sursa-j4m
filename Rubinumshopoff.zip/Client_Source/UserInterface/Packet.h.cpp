Arat:
	HEADER_CG_LOGIN4							= 115,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_CG_MYSHOP_REMOVE_ITEM 				= 117,
	HEADER_CG_MYSHOP_ADD_ITEM 					= 118,
	HEADER_CG_MYSHOP_CLOSE 						= 119,
	HEADER_CG_MYSHOP_WITHDRAW 					= 120,
	HEADER_CG_MYSHOP_RENAME 					= 121,
	HEADER_CG_MYSHOP_OPEN 						= 122,
	HEADER_CG_MYSHOP_OPEN_SEARCH 				= 123,
#endif

Arat:
	HEADER_GC_LOVER_INFO						= 131,
Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_GC_PLAYER_SHOP_SET 					= 155,
	HEADER_GC_MY_SHOP_SIGN 						= 156, 
	HEADER_GC_SYNC_SHOP_STASH 					= 157,
	HEADER_GC_SYNC_SHOP_OFFTIME 				= 158,
	HEADER_GC_SYNC_SHOP_PREMTIME 				= 159,
	HEADER_GC_SYNC_SHOP_POSITION 				= 160,
	HEADER_GC_SHOP_POSITION 					= 161,
#endif

Arat:
	SHOP_SUBHEADER_GC_NOT_ENOUGH_MONEY_EX,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SHOP_SUBHEADER_GC_OPEN_SHOP_EDITOR,
#endif

Arat:
} TPacketGCNPCPosition;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
} TPacketGCNPCPosition, TPacketGCShopPosition;
#else
} TPacketGCNPCPosition;
#endif

Arat:
struct TNPCPosition
{
	BYTE bType;
	char name[CHARACTER_NAME_MAX_LEN+1];
	long x;
	long y;
};

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct TNPCPosition
{
	BYTE bType;
	char name[CHARACTER_NAME_MAX_LEN + 1];
	long x;
	long y;
} TShopPosition;
#else
struct TNPCPosition
{
    BYTE bType;
    char name[CHARACTER_NAME_MAX_LEN+1];
    long x;
    long y;
};
#endif

En alta ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct packet_shop_set
{
	BYTE		header;
	BYTE		pos;
	DWORD		vnum;
#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
	WORD		count;
#else
	BYTE		count;
#endif
	unsigned long long		price;
	long		alSockets[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
} TPacketPlayerShopSet;

typedef struct packet_shop_sign
{
	BYTE	header;
	char	sign[SHOP_SIGN_MAX_LEN + 1];
} TPacketMyShopSign;

typedef struct myshop_remove
{
	BYTE header;
	int slot;
	TItemPos target;
} TPacketMyShopRemoveItem;

typedef struct myshop_add
{
	BYTE header;
	TItemPos from;
	int targetPos;
	unsigned long long price;
} TPacketMyShopAddItem;

typedef struct shopStashSync
{
	BYTE	bHeader;
	unsigned long long	value;
} TPacketGCShopStashSync;

typedef struct shopOfflineTimeSync
{
	BYTE	bHeader;
	DWORD	value;
} TPacketGCShopOffTimeSync;

typedef struct shopPremiumTimeSync
{
	BYTE	bHeader;
	int	value;
} TPacketGCShopPremiumTimeSync;

typedef struct shopSyncPos
{
	BYTE	bHeader;
	int channel;
	int	xGlobal;
	int yGlobal;
} TPacketGCShopSyncPos;

typedef struct shopRename
{
	BYTE bHeader;
	char sign[SHOP_SIGN_MAX_LEN + 1];
} TPacketGCShopRename;

typedef struct shopWithdraw
{
	uint8_t bHeader;
	uint64_t amount;
} TPacketCGShopWithdraw;
#endif