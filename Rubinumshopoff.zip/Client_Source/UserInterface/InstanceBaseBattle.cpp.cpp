Arat:
		if( bUsingSkill && !rkActorEach.IsDoor() )
			continue;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (rkActorEach.IsShop())
			continue;
#endif
