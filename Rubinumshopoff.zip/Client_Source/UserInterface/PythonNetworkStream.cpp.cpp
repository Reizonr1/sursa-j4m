Arat:
			Set(HEADER_GC_UNK_213,			CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCUnk213), STATIC_SIZE_PACKET)); // @fixme007

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			Set(HEADER_GC_PLAYER_SHOP_SET, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketPlayerShopSet), STATIC_SIZE_PACKET));
			Set(HEADER_GC_MY_SHOP_SIGN, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketMyShopSign), STATIC_SIZE_PACKET));
			Set(HEADER_GC_SYNC_SHOP_STASH, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCShopStashSync), STATIC_SIZE_PACKET));
			Set(HEADER_GC_SYNC_SHOP_OFFTIME, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCShopOffTimeSync), STATIC_SIZE_PACKET));
			Set(HEADER_GC_SYNC_SHOP_PREMTIME, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCShopPremiumTimeSync), STATIC_SIZE_PACKET));
			Set(HEADER_GC_SYNC_SHOP_POSITION, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCShopSyncPos), STATIC_SIZE_PACKET));
			Set(HEADER_GC_SHOP_POSITION, CNetworkPacketHeaderMap::TPacketType(sizeof(TPacketGCNPCPosition), DYNAMIC_SIZE_PACKET));
#endif