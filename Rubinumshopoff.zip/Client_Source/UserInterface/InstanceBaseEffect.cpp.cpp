Arat:
const D3DXCOLOR& CInstanceBase::GetIndexedNameColor(UINT eNameColor)
{

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (eNameColor == NAMECOLOR_SHOP)
	{
		static D3DXCOLOR shopColor(D3DCOLOR_XRGB(255, 102, 0));
		return shopColor;
	}
#endif

Arat:
UINT CInstanceBase::GetNameColorIndex()
{

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
		return NAMECOLOR_SHOP;
#endif