Arat:
		void __RefreshInventoryWindow();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		void __RefreshShopInfoWindow();
#endif

Arat:
		bool RecvExchangePacket();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		bool RecvShopItemData();
		bool RecvMyShopSignPacket();
		bool RecvShopStashSync();
		bool RecvShopOfflineTimeSync();
		bool RecvShopPremiumTimeSync();
		bool RecvShopPositionSync();
		bool RecvSHOPList();
#endif

Arat:
		// @fixme007
		bool RecvUnk213();

	protected:
		// �̸�Ƽ��
		bool ParseEmoticon(const char * pChatMsg, DWORD * pdwEmoticon);

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	public:
		bool SendRemoveFromMyShop(int slot, TItemPos target);
		bool SendAddToMyShop(TItemPos from, int target, unsigned long long price);
		bool CloseMyShop();
		bool OpenMyShop();
		bool OpenMyShopSearch();
		bool WithdrawMyShopGold( uint64_t amount );
		bool RenameMyShop(char * newName);
	protected:
#endif

Arat:
		bool m_isRefreshGuildWndGradePage;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		bool m_isRefreshShopInfoWnd;
#endif
