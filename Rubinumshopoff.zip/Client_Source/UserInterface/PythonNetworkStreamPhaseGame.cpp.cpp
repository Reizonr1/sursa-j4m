Arat:
void CPythonNetworkStream::__RefreshEquipmentWindow()
{
	m_isRefreshEquipmentWnd=true;
}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CPythonNetworkStream::__RefreshShopInfoWindow()
{
	m_isRefreshShopInfoWnd = true;
}
#endif

Arat:
			case HEADER_GC_SPECIFIC_EFFECT:
				ret = RecvSpecificEffect();
				break;

			case HEADER_GC_DRAGON_SOUL_REFINE:
				ret = RecvDragonSoulRefine();
				break;
			case HEADER_GC_UNK_213: // @fixme007
				ret = RecvUnk213();
				break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			case HEADER_GC_PLAYER_SHOP_SET:
				ret = RecvShopItemData();
				break;

			case HEADER_GC_MY_SHOP_SIGN:
				ret = RecvMyShopSignPacket();
				break;

			case HEADER_GC_SYNC_SHOP_STASH:
				ret = RecvShopStashSync();
				break;

			case HEADER_GC_SYNC_SHOP_OFFTIME:
				ret = RecvShopOfflineTimeSync();
				break;
				
			case HEADER_GC_SYNC_SHOP_PREMTIME:
				ret = RecvShopPremiumTimeSync();
				break;

			case HEADER_GC_SYNC_SHOP_POSITION:
				ret = RecvShopPositionSync();
				break;

			case HEADER_GC_SHOP_POSITION:
				ret = RecvSHOPList();
				break;
#endif

Arat:
	if (m_isRefreshGuildWndGradePage)
	{
		m_isRefreshGuildWndGradePage=false;
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "RefreshGuildGradePage", Py_BuildValue("()"));
		s_nextRefreshTime = curTime + 300;
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (m_isRefreshShopInfoWnd)
	{
		m_isRefreshShopInfoWnd = false;
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "RefreshShopInfo", Py_BuildValue("()"));
		s_nextRefreshTime = curTime + 300;
	}
#endif

Arat:
	m_isRefreshGuildWndGradePage=false;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_isRefreshShopInfoWnd = false;
#endif

Arat:
		case SHOP_SUBHEADER_GC_INVALID_POS:
			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "OnShopError", Py_BuildValue("(s)", "INVALID_POS"));
			break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case SHOP_SUBHEADER_GC_OPEN_SHOP_EDITOR:
			PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "OpenShopEditor", Py_BuildValue("()"));
			break;
#endif

Arat:
bool CPythonNetworkStream::RecvTargetPacket()

Kendinize g�re d�zenleyin:

bool CPythonNetworkStream::RecvTargetPacket()
{
	TPacketGCTarget TargetPacket;

	if (!Recv(sizeof(TPacketGCTarget), &TargetPacket))
	{
		Tracen("Recv Target Packet Error");
		return false;
	}

	CInstanceBase * pInstPlayer = CPythonCharacterManager::Instance().GetMainInstancePtr();
	CInstanceBase * pInstTarget = CPythonCharacterManager::Instance().GetInstancePtr(TargetPacket.dwVID);
	if (pInstPlayer && pInstTarget)
	{
		if (!pInstTarget->IsDead())
		{
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			if (!pInstTarget->IsShop())
			{
#endif
				if (pInstTarget->IsPC() || pInstTarget->IsBuilding())
					PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "CloseTargetBoardIfDifferent", Py_BuildValue("(i)", TargetPacket.dwVID));
				else if (pInstPlayer->CanViewTargetHP(*pInstTarget))
					PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "SetHPTargetBoard", Py_BuildValue("(ii)", TargetPacket.dwVID, TargetPacket.bHPPercent));
				else
					PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "CloseTargetBoard", Py_BuildValue("()"));
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			}
#endif
			m_pInstTarget = pInstTarget;
		}
	}
	else
	{
		PyCallClassMemberFunc(m_apoPhaseWnd[PHASE_WINDOW_GAME], "CloseTargetBoard", Py_BuildValue("()"));
	}

	return true;
}

En alta ekle:


#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
bool CPythonNetworkStream::SendRemoveFromMyShop(int slot, TItemPos target)
{
	TPacketMyShopRemoveItem p;
	p.header = HEADER_CG_MYSHOP_REMOVE_ITEM;
	p.slot = slot;
	p.target = target;

	if (!Send(sizeof(TPacketMyShopRemoveItem), &p))
	{
		Tracen("Send remove from my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::SendAddToMyShop(TItemPos from, int target, unsigned long long price)
{
	TPacketMyShopAddItem p;
	p.header = HEADER_CG_MYSHOP_ADD_ITEM;
	p.from = from;
	p.targetPos = target;
	p.price = price;

	if (!Send(sizeof(TPacketMyShopAddItem), &p))
	{
		Tracen("Send add to my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::CloseMyShop()
{
	BYTE header = HEADER_CG_MYSHOP_CLOSE;
	if (!Send(sizeof(BYTE), &header))
	{
		Tracen("Send close my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::OpenMyShop()
{
	BYTE header = HEADER_CG_MYSHOP_OPEN;
	if (!Send(sizeof(BYTE), &header))
	{
		Tracen("Send close my shop error.");
		return false;
	}

	return true;
}
bool CPythonNetworkStream::OpenMyShopSearch()
{
	BYTE header = HEADER_CG_MYSHOP_OPEN_SEARCH;
	if (!Send(sizeof(BYTE), &header))
	{
		Tracen("Send close my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::WithdrawMyShopGold( uint64_t amount )
{
	TPacketCGShopWithdraw pack;
	pack.bHeader = HEADER_CG_MYSHOP_WITHDRAW;
	pack.amount = amount;

	if (!Send(sizeof(TPacketCGShopWithdraw), &pack))
	{
		Tracen("Send withdraw my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::RenameMyShop(char* newName)
{
	CPythonShop& shopInstance = CPythonShop::instance();

	TPacketGCShopRename p;
	p.bHeader = HEADER_CG_MYSHOP_RENAME;
	strncpy_s(p.sign, newName, SHOP_SIGN_MAX_LEN);

	if (!Send(sizeof(TPacketGCShopRename),&p))
	{
		Tracen("Send rename my shop error.");
		return false;
	}

	return true;
}

bool CPythonNetworkStream::RecvMyShopSignPacket()
{
	TPacketMyShopSign p;
	if (!Recv(sizeof(TPacketMyShopSign), &p))
		return false;

	CPythonShop& rkShop = CPythonShop::Instance();
	if (p.sign == "") {
		rkShop.ClearMyShopInfo();
	}
	else {
		rkShop.SetMyShopName(p.sign);
	}

	__RefreshShopInfoWindow();
	return true;
}

bool CPythonNetworkStream::RecvSHOPList()
{
	TPacketGCShopPosition kShopPosition;
	if (!Recv(sizeof(kShopPosition), &kShopPosition))
		return false;

	assert(int(kShopPosition.size) - sizeof(kShopPosition) == kShopPosition.count*sizeof(TShopPosition) && "HEADER_GC_SHOP_POSITION");

	CPythonMiniMap::Instance().ClearAtlasShopInfo(); // Clear existing shops

	for (int i = 0; i < kShopPosition.count; ++i)
	{
		TShopPosition SHOPPosition;
		if (!Recv(sizeof(TShopPosition), &SHOPPosition))
			return false;

		CPythonMiniMap::Instance().RegisterAtlasMark(CActorInstance::TYPE_SHOP, SHOPPosition.name, SHOPPosition.x, SHOPPosition.y);
	}

	return true;
}

bool CPythonNetworkStream::RecvShopStashSync()
{
	TPacketGCShopStashSync p;
	if (!Recv(sizeof(TPacketGCShopStashSync), &p))
		return false;

	CPythonShop& rkShop = CPythonShop::Instance();
	rkShop.SetStashValue(p.value);

	__RefreshShopInfoWindow();


	return true;
}

bool CPythonNetworkStream::RecvShopOfflineTimeSync()
{
	TPacketGCShopOffTimeSync p;
	if (!Recv(sizeof(TPacketGCShopOffTimeSync), &p))
		return false;

	CPythonShop& rkShop = CPythonShop::Instance();
	rkShop.SetOfflineMinutes(p.value);

	__RefreshShopInfoWindow();
	return true;
}

bool CPythonNetworkStream::RecvShopPremiumTimeSync()
{
	TPacketGCShopPremiumTimeSync p;
	if (!Recv(sizeof(TPacketGCShopPremiumTimeSync), &p))
		return false;

	CPythonShop& rkShop = CPythonShop::Instance();
	rkShop.SetPremiumMinutes(p.value);

	__RefreshShopInfoWindow();
	return true;
}

bool CPythonNetworkStream::RecvShopPositionSync()
{
	TPacketGCShopSyncPos p;
	if (!Recv(sizeof(TPacketGCShopSyncPos), &p))
		return false;

	CPythonShop& rkShop = CPythonShop::Instance();
	rkShop.SetLocation(p.channel, p.xGlobal, p.yGlobal);

	__RefreshShopInfoWindow();

	return true;
}
#endif

