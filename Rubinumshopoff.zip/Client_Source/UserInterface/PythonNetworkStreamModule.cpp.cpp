Arat:
PyObject* netRegisterErrorLog(PyObject* poSelf, PyObject* poArgs)
{
	char * szLog;
	if (!PyTuple_GetString(poArgs, 0, &szLog))
		return Py_BuildException();

	return Py_BuildNone();
}

Alt�na ekle:


#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
PyObject* netSendRemoveItemFromMyShop(PyObject* poSelf, PyObject* poArgs)
{
	int slot;
	if (!PyTuple_GetInteger(poArgs, 0, &slot))
		return Py_BuildException();

	BYTE window;
	if (!PyTuple_GetByte(poArgs, 1, &window))
		return Py_BuildException();

	int target;
	if (!PyTuple_GetInteger(poArgs, 2, &target))
		return Py_BuildException();

	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.SendRemoveFromMyShop(slot, TItemPos(window, target));

	return Py_BuildNone();
}

PyObject* netSendAddItemToMyShop(PyObject* poSelf, PyObject* poArgs)
{
	BYTE window;
	if (!PyTuple_GetByte(poArgs, 0, &window))
		return Py_BuildException();

	int slot;
	if (!PyTuple_GetInteger(poArgs, 1, &slot))
		return Py_BuildException();

	int targetPos;
	if (!PyTuple_GetInteger(poArgs, 2, &targetPos))
		return Py_BuildException();

	unsigned long long price;
	if (!PyTuple_GetUnsignedLongLong(poArgs, 3, &price))
		return Py_BuildException();

	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.SendAddToMyShop(TItemPos(window, slot), targetPos, price);

	return Py_BuildNone();
}

PyObject* netSendCloseMyShop(PyObject* poSelf, PyObject* poArgs)
{
	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.CloseMyShop();

	return Py_BuildNone();
}
PyObject* netSendOpenMyShop(PyObject* poSelf, PyObject* poArgs)
{
	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.OpenMyShop();

	return Py_BuildNone();
}
PyObject* netSendOpenMyShopSearch(PyObject* poSelf, PyObject* poArgs)
{
	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.OpenMyShopSearch();

	return Py_BuildNone();
}

PyObject* netSendWithdrawMyShopGold(PyObject* poSelf, PyObject* poArgs)
{

	uint64_t amount;
	if (!PyTuple_GetUnsignedLongLong(poArgs, 0, &amount))
		return Py_BuildException();

	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.WithdrawMyShopGold(amount);

	return Py_BuildNone();
}


PyObject* netSendRenameMyShop(PyObject* poSelf, PyObject* poArgs)
{
	char * newName;
	if (!PyTuple_GetString(poArgs, 0, &newName))
		return Py_BuildException();

	CPythonNetworkStream& rns = CPythonNetworkStream::Instance();
	rns.RenameMyShop(newName);

	return Py_BuildNone();
}
#endif

Arat:
		{ "RegisterErrorLog",						netRegisterErrorLog,						METH_VARARGS },

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		{ "SendRemoveItemFromMyShop",				netSendRemoveItemFromMyShop,				METH_VARARGS },
		{ "SendAddItemToMyShop",					netSendAddItemToMyShop,						METH_VARARGS },
		{ "SendCloseMyShop",						netSendCloseMyShop,							METH_VARARGS },
		{ "SendOpenMyShop",							netSendOpenMyShop,							METH_VARARGS },
		{ "SendWithdrawMyShopGold",					netSendWithdrawMyShopGold,					METH_VARARGS },
		{ "SendRenameMyShop",						netSendRenameMyShop,						METH_VARARGS },
#endif