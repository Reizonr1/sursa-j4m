Arat:
			aMarkPosition.m_bType = CActorInstance::TYPE_NPC;
			aMarkPosition.m_fX = ( m_fWidth - (float)m_WhiteMark.GetWidth() ) / 2.0f + fDistanceFromCenterX + m_fScreenX;
			aMarkPosition.m_fY = ( m_fHeight - (float)m_WhiteMark.GetHeight() ) / 2.0f + fDistanceFromCenterY + m_fScreenY;

			m_MinimapPosVector.push_back(aMarkPosition);
		}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		else if (pkInstEach->IsShop())
		{
			aMarkPosition.m_bType = CActorInstance::TYPE_SHOP;
			aMarkPosition.m_fX = (m_fWidth - (float)m_WhiteMark.GetWidth()) / 2.0f + fDistanceFromCenterX + m_fScreenX;
			aMarkPosition.m_fY = (m_fHeight - (float)m_WhiteMark.GetHeight()) / 2.0f + fDistanceFromCenterY + m_fScreenY;
			m_MinimapPosVector.push_back(aMarkPosition);
		}
#endif

Arat:
		m_WhiteMark.SetPosition(i.m_fX, i.m_fY);
		m_WhiteMark.Render();
	}

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		else if (stage != 5 && i.m_bType == CActorInstance::TYPE_SHOP)
		{
			STATEMANAGER.SetRenderState(D3DRS_TEXTUREFACTOR, CInstanceBase::GetIndexedNameColor(CInstanceBase::NAMECOLOR_NORMAL_PC));
			stage = 5;
		}
#endif

Arat:
void CPythonMiniMap::RegisterAtlasMark(BYTE byType, const char * c_szName, long lx, long ly)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CPythonMiniMap::ClearAtlasShopInfo()
{
	m_AtlasShopInfoVector.clear();
}
#endif

Arat:
		case CActorInstance::TYPE_WARP:
			aAtlasMarkInfo.m_byType = TYPE_WARP;
			m_AtlasWarpInfoVector.push_back(aAtlasMarkInfo);
			break;

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case CActorInstance::TYPE_SHOP:
			aAtlasMarkInfo.m_byType = CActorInstance::TYPE_SHOP;
			aAtlasMarkInfo.m_strText.append("'s D�kkan� ");
			m_AtlasShopInfoVector.push_back(aAtlasMarkInfo);
			break;
#endif

Arat:
	STATEMANAGER.SaveTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (m_bAtlasRenderShops)
	{
		STATEMANAGER.SetRenderState(D3DRS_TEXTUREFACTOR, CInstanceBase::GetIndexedNameColor(CInstanceBase::NAMECOLOR_SHOP));
		for (auto &rAtlasMarkInfo : m_AtlasShopInfoVector)
		{
			m_WhiteMark.SetPosition(rAtlasMarkInfo.m_fScreenX, rAtlasMarkInfo.m_fScreenY);
			m_WhiteMark.Render();
		}
	}
#endif

Arat:
	if (pkInst)
	{
		TPixelPosition kInstPos;
		pkInst->NEW_GetPixelPosition(&kInstPos);

		if (kInstPos.x-fCheckWidth<fRealX && kInstPos.x+fCheckWidth>fRealX &&
			kInstPos.y-fCheckHeight<fRealY && kInstPos.y+fCheckHeight>fRealY)
		{
			rReturnString = pkInst->GetNameString();
			*pReturnPosX = kInstPos.x;
			*pReturnPosY = kInstPos.y;
			*pdwTextColor = pkInst->GetNameColor();
			return true;
		}
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (m_bAtlasRenderShops)
	{
		for (auto &rAtlasMarkInfo : m_AtlasShopInfoVector)
		{
			if (rAtlasMarkInfo.m_fScreenX > 0.0f)
				if (rAtlasMarkInfo.m_fScreenY > 0.0f)
					if (rAtlasMarkInfo.m_fX - fCheckWidth / 2 < fRealX && rAtlasMarkInfo.m_fX + fCheckWidth > fRealX &&
						rAtlasMarkInfo.m_fY - fCheckWidth / 2 < fRealY && rAtlasMarkInfo.m_fY + fCheckHeight > fRealY)
					{
						rReturnString = rAtlasMarkInfo.m_strText;
						*pReturnPosX = rAtlasMarkInfo.m_fX;
						*pReturnPosY = rAtlasMarkInfo.m_fY;
						*pdwTextColor = CInstanceBase::GetIndexedNameColor(CInstanceBase::NAMECOLOR_SHOP);
						return true;
					}
		}
	}
#endif

Arat:
		case CPythonMiniMap::TYPE_NPC:
			return m_bAtlasRenderNpc = !m_bAtlasRenderNpc;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case CPythonMiniMap::TYPE_SHOP:
			return m_bAtlasRenderShops = !m_bAtlasRenderShops;
#endif

Arat:
	m_bShowAtlas = false;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_bAtlasRenderShops = true;
#endif