Arat:
	if (IsWarp())
	{
		__Create_SetWarpName(c_rkCreateData);
		return;
	}


Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
	{
		std::string newName = c_rkCreateData.m_stName;
		SetNameString(newName.c_str(), newName.length());
		return;
	}
#endif

Arat:
BOOL CInstanceBase::IsObject()
{
	return m_GraphicThingInstance.IsObject();
}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
BOOL CInstanceBase::IsShop()
{
	return m_GraphicThingInstance.IsShop();
}
#endif