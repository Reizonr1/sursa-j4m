Arat:
void CPythonTextTail::RegisterCharacterTextTail(DWORD dwGuildID, DWORD dwVirtualID, const D3DXCOLOR & c_rColor, float fAddHeight)
{
	CInstanceBase * pCharacterInstance = CPythonCharacterManager::Instance().GetInstancePtr(dwVirtualID);

	if (!pCharacterInstance)
		return;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	std::string name = pCharacterInstance->GetNameString();
	if (pCharacterInstance->IsShop()) 
	{
		CInstanceBase * pMainCharacterInstance = CPythonCharacterManager::Instance().GetMainInstancePtr();
		//Do not display shop names for those shops that aren't ours
		if (!pMainCharacterInstance || pMainCharacterInstance->GetNameString() != name)
			return;
		
		//Override the display shop name
		name = "D�kkan�n";
	}
#endif

Arat:
											 pCharacterInstance->GetNameString(),

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
											 name.c_str(),
#else
											 pCharacterInstance->GetNameString(),
#endif
