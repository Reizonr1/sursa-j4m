Arat:
BOOL CPythonShop::GetItemData(DWORD dwIndex, const TShopItemData ** c_ppItemData)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CPythonShop::SetMyShopItemData(DWORD dwIndex, const TShopItemData & c_rShopItemData)
{
	if (dwIndex >= SHOP_HOST_ITEM_MAX_NUM) {
		TraceError("Out of index item on my shop (idx: %lu)", dwIndex);
		return;
	}

	m_aMyShop.items[dwIndex] = c_rShopItemData;
	if (IsOpen() && IsMainPlayerPrivateShop()) {
		m_aShoptabs[0].items[dwIndex] = c_rShopItemData;
	}

	Tracef("Added shop item on %lu.", dwIndex);
}
#endif

Arat:
void CPythonShop::Open(BOOL isPrivateShop, BOOL isMainPrivateShop)
{
	m_isShoping = TRUE;
	m_isPrivateShop = isPrivateShop;
	m_isMainPlayerPrivateShop = isMainPrivateShop;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (isMainPrivateShop)
		m_aShoptabs[0] = m_aMyShop;
#endif

Arat:
void CPythonShop::Clear()

Kod blo�unun alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CPythonShop::ClearMyShopInfo()
{
	memset(m_aMyShop.items, 0, sizeof(TShopItemData) * SHOP_HOST_ITEM_MAX_NUM);
	m_myShopName.clear();
}
#endif

Arat:
CPythonShop::CPythonShop(void)

De�i�tir:

CPythonShop::CPythonShop(void)
{
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_stashValue = 0;
	m_offlineMinutes = 0;
	m_premiumMinutes = 0;
#endif

	Clear();
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	ClearMyShopInfo();
#endif
}


Arat:
PyObject * shopGetTabCoinType(PyObject * poSelf, PyObject * poArgs)
{
	BYTE bTabIdx;
	if (!PyTuple_GetInteger(poArgs, 0, &bTabIdx))
		return Py_BuildException();

	return Py_BuildValue("i", CPythonShop::instance().GetTabCoinType(bTabIdx));
}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
PyObject * shopGetMyName(PyObject * poSelf, PyObject * poArgs)
{
	return Py_BuildValue("s", CPythonShop::instance().GetMyShopName().c_str());
}

PyObject * shopClear(PyObject * poSelf, PyObject * poArgs)
{
	CPythonShop::instance().Clear();
	CPythonShop::instance().ClearMyShopInfo();
	CPythonShop::instance().SetOfflineMinutes(0);
	CPythonShop::instance().SetStashValue(0);
	CPythonShop::instance().SetLocation(0, 0, 0);
	return Py_BuildNone();
}

PyObject * shopIsMyShopOpen(PyObject * poSelf, PyObject * poArgs)
{
	if (CPythonShop::instance().GetMyShopName().compare("") != 0)
		Py_RETURN_TRUE;
	else
		Py_RETURN_FALSE;
}

PyObject * shopGetOfflineMinutes(PyObject * poSelf, PyObject * poArgs)
{
	return Py_BuildValue("i", CPythonShop::instance().GetOfflineMinutes());
}

PyObject * shopGetPremiumMinutes(PyObject * poSelf, PyObject * poArgs)
{
	return Py_BuildValue("i", CPythonShop::instance().GetPremiumMinutes());
}

PyObject * shopGetGoldStash(PyObject * poSelf, PyObject * poArgs)
{
	return Py_BuildValue("K", CPythonShop::instance().GetStashValue());
}

PyObject * shopGetLocation(PyObject * poSelf, PyObject * poArgs)
{
	const CPythonShop::ShopPosition& pos = CPythonShop::instance().GetLocation();
	return Py_BuildValue("(iii)", pos.channel, pos.x, pos.y);
}
#endif

Arat:
		// Private Shop
		{ "ClearPrivateShopStock",		shopClearPrivateShopStock,		METH_VARARGS },
		{ "AddPrivateShopItemStock",	shopAddPrivateShopItemStock,	METH_VARARGS },
		{ "DelPrivateShopItemStock",	shopDelPrivateShopItemStock,	METH_VARARGS },
		{ "GetPrivateShopItemStock",	shopGetPrivateShopItemStock,	METH_VARARGS },
		{ "GetPrivateShopItemPrice",	shopGetPrivateShopItemPrice,	METH_VARARGS },
		{ "BuildPrivateShop",			shopBuildPrivateShop,			METH_VARARGS },

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		{ "GetMyShopName",				shopGetMyName,					METH_VARARGS },
		{ "IsMyShopOpen",				shopIsMyShopOpen,				METH_VARARGS },
		{ "GetOfflineMinutes",			shopGetOfflineMinutes,			METH_VARARGS },
		{ "GetPremiumMinutes",			shopGetPremiumMinutes,			METH_VARARGS },
		{ "GetStashValue" ,				shopGetGoldStash,				METH_VARARGS },
		{ "GetLocation",				shopGetLocation,				METH_VARARGS },
		{ "Clear",						shopClear,						METH_VARARGS },
#endif