Arat:
void CActorInstance::DestroySystem()
{
}
�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
bool CActorInstance::IsShop()
{
	return (m_eActorType == TYPE_SHOP);
}
#endif
