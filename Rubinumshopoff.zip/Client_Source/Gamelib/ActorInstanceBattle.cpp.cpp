Arat:
	if (rkActorDst.IsNPC())
		return false;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (rkActorDst.IsShop())
		return false;
#endif
