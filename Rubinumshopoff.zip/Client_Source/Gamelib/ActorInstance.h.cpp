Arat:
			TYPE_HORSE,
Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			TYPE_SHOP,
#endif

Arat:
		bool IsObject();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		bool IsShop();
#endif