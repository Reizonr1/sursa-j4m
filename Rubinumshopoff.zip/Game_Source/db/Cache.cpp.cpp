Arat:
// MYSHOP_PRICE_LIST
extern int g_iItemPriceListTableCacheFlushSeconds;
// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
extern int g_iShopCacheFlushSeconds;
#endif


Arat:
CItemPriceListTableCache::~CItemPriceListTableCache()
{
}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
CShopCache::CShopCache()
{
	m_expireTime = MIN(360, g_iShopCacheFlushSeconds);
}

CShopCache::~CShopCache()
{
}

void CShopCache::OnFlush()
{
	if (g_test_server)
		sys_log(0, "ShopCache::Flush: %u", m_data.pid);

	char shopNameEscaped[SHOP_SIGN_MAX_LEN * 2 + 1];
	CDBManager::instance().EscapeString(shopNameEscaped, m_data.shopName, strlen(m_data.shopName));
	
	//Save the main shop info
	char szQuery[QUERY_MAX_LEN];
	snprintf(szQuery, sizeof(szQuery),
		"INSERT INTO private_shop (pid, x, y, mapindex, channel, sign, open_time, is_closed, offline_left, premium_left, gold_stash) "
		"VALUES (%u, %ld, %ld, %ld, %d, '%s', FROM_UNIXTIME(%u), %d, %d, %d, %lld)"
		"ON DUPLICATE KEY UPDATE x = VALUES(x), y = VALUES(y), channel = VALUES(channel), mapindex = VALUES(mapindex), "
		"open_time = VALUES(open_time), sign = VALUES(sign), is_closed = VALUES(is_closed), offline_left = VALUES(offline_left), "
		"premium_left = VALUES(premium_left), gold_stash = VALUES(gold_stash)",
		m_data.pid,
		m_data.x,
		m_data.y,
		m_data.mapIndex,
		m_data.channel,
		shopNameEscaped,
		m_data.openTime,
		m_data.closed ? 1 : 0,
		m_data.offlineMinutesLeft,
		m_data.premiumMinutesLeft,
		m_data.goldStash);
	
	CDBManager::instance().AsyncQuery(szQuery);

	//Delete old items
	snprintf(szQuery, sizeof(szQuery),
		"DELETE FROM private_shop_items WHERE pid = %d", m_data.pid);

	CDBManager::instance().AsyncQuery(szQuery);
	
	size_t len = snprintf(szQuery, sizeof(szQuery),
		"INSERT INTO private_shop_items (pid, pos, price) VALUES ");

	bool cancel = true;
	for (const TShopItemTable sitem : m_data.items)
	{
		if (sitem.vnum == 0)
			continue;

		if (cancel)
			cancel = false;

		len += snprintf(szQuery + len, sizeof(szQuery) - len,
			"(%u, %d, %lld),",
			m_data.pid,
			sitem.display_pos,
			sitem.price);
	}

	if (cancel) 
		return;

	szQuery[len-1] = '\0'; //Remove the last comma
	CDBManager::instance().AsyncQuery(szQuery);
}
#endif