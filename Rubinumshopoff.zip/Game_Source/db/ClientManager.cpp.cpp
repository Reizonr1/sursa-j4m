Ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
#include "Shop.h"
#endif

Arat:
CClientManager::CClientManager() :

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
std::map<DWORD, spShop> shopMap;
#endif

Arat:
void CClientManager::Destroy()

De�i�tir:

void CClientManager::Destroy()
{
	m_mChannelStatus.clear();
	for (itertype(m_peerList) i = m_peerList.begin(); i != m_peerList.end(); ++i)
		(*i)->Destroy();

	m_peerList.clear();

	if (m_fdAccept > 0)
	{
		socket_close(m_fdAccept);
		m_fdAccept = -1;
	}

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	shopMap.clear();
#endif
}


Arat:
	m_mapItemPriceListCache.clear();
	// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	for (const auto it : m_map_shopCache)
	{
		CShopCache* pCache = it.second;
		pCache->Flush();
		delete pCache;
	}

	m_map_shopCache.clear();
#endif

Arat:
	marriage::CManager::instance().OnSetup(peer);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SendShops(peer);
#endif

Arat:

void CClientManager::QUERY_ITEM_SAVE(CPeer* pkPeer, const char* c_pData)

��eri�ini kendinizdeki sistemlere g�re d�zenleyin:

void CClientManager::QUERY_ITEM_SAVE(CPeer* pkPeer, const char* c_pData)
{
	TPlayerItem* p = (TPlayerItem*)c_pData;

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	bool intoCache = true;
#endif
	if (p->window == SAFEBOX || p->window == MALL
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		|| p->window == SHOP
#endif
	)
	{
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (p->window != SHOP)
		{
			intoCache = false;
			CItemCache * c = GetItemCache(p->id);

			if (c)
			{
				TItemCacheSetPtrMap::iterator it = m_map_pkItemCacheSetPtr.find(c->Get()->owner);

				if (it != m_map_pkItemCacheSetPtr.end())
				{
					if (g_test_server)
						sys_log(0, "ITEM_CACHE: window %d owner %u id %u", p->window, c->Get()->owner, c->Get()->id);

					it->second->erase(c);
				}

				m_map_itemCache.erase(p->id);

				delete c;
			}
		}
#else
		CItemCache* c = GetItemCache(p->id);

		if (c)
		{
			TItemCacheSetPtrMap::iterator it = m_map_pkItemCacheSetPtr.find(c->Get()->owner);

			if (it != m_map_pkItemCacheSetPtr.end())
			{
				if (g_test_server)
					sys_log(0, "ITEM_CACHE: safebox owner %u id %u", c->Get()->owner, c->Get()->id);

				it->second->erase(c);
			}

			m_map_itemCache.erase(p->id);

			delete c;
		}
#endif

Arat:
		CDBManager::instance().ReturnQuery(szQuery, QID_ITEM_SAVE, pkPeer->GetHandle(), NULL);
	}

Atl�na ekle:

#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
	else
	{
		if (g_test_server)
			sys_log(0, "QUERY_ITEM_SAVE => PutItemCache() owner %d id %d vnum %d ", p->owner, p->id, p->vnum);

		PutItemCache(p);
	}
#else
	if (intoCache)
	{
		if (g_test_server)
			sys_log(0, "QUERY_ITEM_SAVE => PutItemCache() owner %d id %d vnum %d ", p->owner, p->id, p->vnum);

		PutItemCache(p);
	}
#endif

Arat:
		case HEADER_GD_ADD_MONARCH_MONEY:

De�i�tir:

		case HEADER_GD_ADD_MONARCH_MONEY:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			AddMonarchMoney(data);
#else
			AddMonarchMoney(peer, dwHandle, data);
#endif
			break;

Arat:

		case HEADER_GD_PLAYER_LOGOUT:
			PlayerLogoutEvent(*(DWORD*)data);
			break;


�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case HEADER_GD_SHOP:
			ProcessShopPacket(peer, dwHandle, data);
			break;

		case HEADER_GD_SAVE_SHOP:
			SaveShop(peer, (TPlayerShopTable*)data);
			break;

		case HEADER_GD_WITHDRAW_SHOP_GOLD:
			WithdrawShopGold(peer, dwHandle, data);
			break;
#endif

Arat:
		// MYSHOP_PRICE_LIST
	case QID_ITEMPRICE_LOAD_FOR_UPDATE:
		RESULT_PRICELIST_LOAD_FOR_UPDATE(msg);
		break;
		// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case QID_LOAD_PLAYER_SHOPS:
		RESULT_LOAD_SHOPS(msg);
		break;

	case QID_LOAD_PLAYER_SHOP_ITEMS:
		RESULT_LOAD_PLAYER_SHOP_ITEMS(msg);
		break;
#endif

Arat:
			// MYSHOP_PRICE_LIST
			UpdateItemPriceListCache();
			// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			UpdateShopCache();
#endif


Arat:
void CClientManager::Candidacy(CPeer* peer, DWORD dwHandle, const char* data)

Blo�un alt�na ekle varsa de�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CClientManager::AddMonarchMoney(const char * data)
{
	int Empire = *(int *) data;
	data += sizeof(int);

	unsigned long long Money = *(unsigned long long *)data;
	data += sizeof(unsigned long long);

	if (g_test_server)
		sys_log(0, "[MONARCH] Add money Empire(%d) Money(%llu)", Empire, Money);

	CMonarch::instance().AddMoney(Empire, Money);
	
	for (itertype(m_peerList) it = m_peerList.begin(); it != m_peerList.end(); ++it)
	{
		CPeer * p = *it;

		if (p->IsAuth() || !p->IsValid())
			continue;

		p->EncodeHeader(HEADER_DG_ADD_MONARCH_MONEY, 0, sizeof(int) + sizeof(unsigned long long));
		p->Encode(&Empire, sizeof(int));
		p->Encode(&Money, sizeof(unsigned long long));

	}
}
#else
void CClientManager::AddMonarchMoney(CPeer* peer, DWORD dwHandle, const char* data)
{
	int Empire = *(int*)data;
	data += sizeof(int);

	int Money = *(int*)data;
	data += sizeof(int);

	if (g_test_server)
		sys_log(0, "[MONARCH] Add money Empire(%d) Money(%d)", Empire, Money);

	CMonarch::instance().AddMoney(Empire, Money);

	for (itertype(m_peerList) it = m_peerList.begin(); it != m_peerList.end(); ++it)
	{
		CPeer* p = *it;

		if (!p->GetChannel())
			continue;

		if (p == peer)
		{
			p->EncodeHeader(HEADER_DG_ADD_MONARCH_MONEY, dwHandle, sizeof(int) + sizeof(int));
			p->Encode(&Empire, sizeof(int));
			p->Encode(&Money, sizeof(int));
		}
		else
		{
			p->EncodeHeader(HEADER_DG_ADD_MONARCH_MONEY, 0, sizeof(int) + sizeof(int));
			p->Encode(&Empire, sizeof(int));
			p->Encode(&Money, sizeof(int));
		}
	}
}
#endif

