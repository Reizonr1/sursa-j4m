Ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
extern std::map<DWORD, spShop> shopMap;
#endif

Arat:
			if (dwCount)
				peer->Encode(&s_items[0], sizeof(TPlayerItem) * dwCount);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			SendMyShopInfo(peer, dwHandle, pTab->id);
#endif

Arat:
}
void CClientManager::ItemAward(CPeer* peer, char* login)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	PlayerLoginEvent(packet->player_id);
#endif

Arat:
void CClientManager::RESULT_ITEM_LOAD(CPeer* peer, MYSQL_RES* pRes, DWORD dwHandle, DWORD dwPID)
{
	static std::vector<TPlayerItem> s_items;

	CreateItemTableFromRes(pRes, &s_items, dwPID);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	DWORD dwShopCount = 0;
	for (auto it = s_items.begin(); it != s_items.end();)
	{
		TPlayerItem item = *it;
		if (item.window == SHOP)
		{
			CItemCache * c = GetItemCache(item.id);
			if (c && c->Get() && c->Get()->owner != dwPID) { //Shop items that we've sold are not loaded
				it = s_items.erase(it);
				continue;
			}

			++dwShopCount;
		}

		++it;
	}
#endif


Arat:
	peer->EncodeHeader(HEADER_DG_ITEM_LOAD, dwHandle, sizeof(DWORD) + sizeof(TPlayerItem) * dwCount);
	peer->EncodeDWORD(dwCount);

	CreateItemCacheSet(dwPID);

Alt�na ekle:

	// ITEM_LOAD_LOG_ATTACH_PID
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	sys_log(0, "ITEM_LOAD: count %u, shop %u, pid %u", dwCount, dwShopCount, dwPID);
#else
	sys_log(0, "ITEM_LOAD: count %u pid %u", dwCount, dwPID);
#endif
	// END_OF_ITEM_LOAD_LOG_ATTACH_PID

Hemen alt�nda bul:
	if (dwCount)
	{
		peer->Encode(&s_items[0], sizeof(TPlayerItem) * dwCount);

		for (DWORD i = 0; i < dwCount; ++i)
			PutItemCache(&s_items[i], true);
	}
Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SendMyShopInfo(peer, dwHandle, dwPID);
#endif

Arat:
		snprintf(queryStr, sizeof(queryStr), "DELETE FROM messenger_list%s WHERE account='%s' OR companion='%s'", GetTablePostfix(), szName, szName);
		CDBManager::instance().AsyncQuery(queryStr);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		spShop shop = GetShop(pi->player_id);
		if (shop)
		{
			RequestCloseShop(shop, true);
			shopMap.erase(pi->player_id);

			snprintf(queryStr, sizeof(queryStr), "DELETE FROM private_shop WHERE pid=%u", pi->player_id);
			CDBManager::instance().AsyncQuery(queryStr);

			snprintf(queryStr, sizeof(queryStr), "DELETE FROM private_shop_items WHERE pid=%u", pi->player_id);
			CDBManager::instance().AsyncQuery(queryStr);
		}
#endif

En alta ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CClientManager::PlayerLogoutEvent(DWORD pid)
{
	NotifyShopLogout(pid);
}

void CClientManager::PlayerLoginEvent(DWORD pid)
{
	SendSingleShop(pid);
	CancelOpenShopOffline(pid);
}
#endif