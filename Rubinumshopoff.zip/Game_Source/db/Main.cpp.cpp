Ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void PollShops();
#endif

Arat:
int g_iItemCacheFlushSeconds = 60 * 5;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
int g_iShopCacheFlushSeconds = 360;
#endif

Arat:
	if (!CClientManager::instance().Initialize())
	{
		sys_log(0, "   failed");
		return false;
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	sys_log(0, "Starting async shop polling");
	PollShops();
#endif

En alta ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void PollShops()
{
	char szQuery[1024];
	snprintf(szQuery, sizeof(szQuery),
		"SELECT s.pid, s.x, s.y, s.channel, s.mapindex, UNIX_TIMESTAMP(s.open_time), s.offline_left, s.premium_left, s.sign, p.name, s.gold_stash, s.is_closed "
		"FROM private_shop as s INNER JOIN player as p ON p.id = s.pid");

	CDBManager::instance().ReturnQuery(szQuery, QID_LOAD_PLAYER_SHOPS, 0, nullptr);
}
#endif
