Ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
#include "Shop.h"
#endif

Arat:
class CPlayerTableCache;

Atl�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
class CShopCache;
#endif

Arat:
	typedef std::list<CPeer*>			TPeerList;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	typedef boost::unordered_map<DWORD, CShopCache *> TShopCacheMap;
#endif

Arat:

	int	GetPlayerDeleteLevelLimit() { return m_iPlayerDeleteLevelLimit; }

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	CShopCache * GetShopCache(DWORD pid);
	void	PutShopCache(TPlayerShopTableCache pNew);
#endif

Arat:
	// MYSHOP_PRICE_LIST

	CItemPriceListTableCache* GetItemPriceListCache(DWORD dwID);

	void			PutItemPriceListCache(const TItemPriceListTable* pItemPriceList);

	void			UpdateItemPriceListCache(void);
	// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void			UpdateShopCache();
#endif

Arat:
	// MYSHOP_PRICE_LIST

	void		RESULT_PRICELIST_LOAD(CPeer* peer, SQLMsg* pMsg);

	void		RESULT_PRICELIST_LOAD_FOR_UPDATE(SQLMsg* pMsg);
	// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void 		RESULT_LOAD_PLAYER_SHOP_ITEMS(SQLMsg* pMsg);
#endif

Arat:
	void		LoadEventFlag();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		SendShops(CPeer* peer);
	void		SendSingleShop(DWORD pid);
	void		PlayerLoginEvent(DWORD pid);
#endif

Arat:
	// Building
	void		CreateObject(TPacketGDCreateObject* p);
	void		DeleteObject(DWORD dwID);
	void		UpdateLand(DWORD* pdw);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		ShopSaleResult(const char * data);
	void		ShopRemove(const char * data);
#endif

Arat:
	// MYSHOP_PRICE_LIST

	TItemPriceListCacheMap m_mapItemPriceListCache;
	// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	TShopCacheMap			m_map_shopCache;
#endif

Arat:
	// MYSHOP_PRICE_LIST

	TItemPriceListCacheMap m_mapItemPriceListCache;
	// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	TShopCacheMap			m_map_shopCache;
#endif

Arat:
	//delete gift notify icon
	void DeleteAwardId(TPacketDeleteAwardID* data);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void RESULT_LOAD_SHOPS(SQLMsg * msg);
	void ProcessShopPacket(CPeer* peer, DWORD dwHandle, const char * data);

	void SaveShop(CPeer* peer, TPlayerShopTable* data);
	spShop GetShop(DWORD pid);
	void CancelOpenShopOffline(DWORD pid);

	void LoadPlayerShop(CPeer* peer, TPlayerShopTable* p);

	void WithdrawShopGold(CPeer* peer, DWORD playerHandle, const char * data);
	void RollbackWithdrawShopGold(CPeer* peer, DWORD playerHandle, const char * data);

	void SendMyShopInfo(CPeer* peer, DWORD dwHandle, DWORD pid);
	void NotifyShopLogout(DWORD pid);
	void UpdateOfflineTime(const char* data);
	void AddShopPremiumTime(const char* data);
	void RequestCloseShop(spShop shop, bool isDeleteShop);
	void RequestCloseShop(const char* data);
	void RenameShop(const char* data);

	void SynchronizePremiumTime(spShop shop);
	void SynchronizePremiumTime(const char* data);
public:
	void UnbindPeer(CPeer* peer);
#endif