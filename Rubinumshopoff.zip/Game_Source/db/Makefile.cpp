Arat:
# Depend Path File
ifneq ($(ENABLE_GCC_AUTODEPEND), 1)
DEPFILE = Depend
endif

�st�ne ekle:

ENABLE_OFFLINE_SHOP_SYSTEM = 1

Arat:
# PROJECT_OBJ_FILES BEGIN

�st�ne ekle:

ifeq ($(ENABLE_OFFLINE_SHOP_SYSTEM), 1)
	CPPFILE += ClientManagerShop.cpp Shop.cpp
endif