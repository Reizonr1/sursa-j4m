Arat:
	static const int	s_nMinFlushSec;		///< Minimum cache expire time
};
// END_OF_MYSHOP_PRICE_LIST

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
class CShopCache : public cache<TPlayerShopTableCache>
{
public:
	CShopCache();
	virtual ~CShopCache();

	virtual void OnFlush();

	DWORD GetLastUpdateTime() { return m_lastUpdateTime; }
};
#endif