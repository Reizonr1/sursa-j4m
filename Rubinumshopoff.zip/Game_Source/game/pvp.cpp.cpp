Arat:
	case CHAR_TYPE_NPC:

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case CHAR_TYPE_SHOP:
#endif