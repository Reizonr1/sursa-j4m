Arat:
	Set(HEADER_CG_DRAGON_SOUL_REFINE, sizeof(TPacketCGDragonSoulRefine), "DragonSoulRefine", false);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	Set(HEADER_CG_MYSHOP_REMOVE_ITEM, sizeof(TPacketMyShopRemoveItem), "MyShopRemove", false);
	Set(HEADER_CG_MYSHOP_ADD_ITEM, sizeof(TPacketMyShopAddItem), "MyShopAdd", false);
	Set(HEADER_CG_MYSHOP_CLOSE, sizeof(BYTE), "MyShopClose", false); //Header-only
	Set(HEADER_CG_MYSHOP_OPEN, sizeof(uint8_t), "MyShopOpen", false); //Header-only
	Set(HEADER_CG_MYSHOP_OPEN_SEARCH, sizeof(uint8_t), "MyShopOpenSearch", false); //Header-only
	Set(HEADER_CG_MYSHOP_WITHDRAW, sizeof(TPacketCGShopWithdraw), "MyShopWithdraw", false); //Header-only
	Set(HEADER_CG_MYSHOP_RENAME, sizeof(TPacketGCShopRename), "MyShopRename", false);
#endif

Arat:
	Set(HEADER_GG_MONARCH_TRANSFER, sizeof(TPacketMonarchGGTransfer), "MonarchTransfer", false);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	Set(HEADER_GG_SHOP_OFFLINE_START,	sizeof(TPacketGGShopStartOffline),	"ShopStartOffline");
	Set(HEADER_GG_SHOP_OFFLINE_END,		sizeof(TPacketGGShopEndOffline),	"ShopEndOffline");
#endif