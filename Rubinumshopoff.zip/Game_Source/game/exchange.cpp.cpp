Arat:
	if (IsOpenSafebox() || GetShopOwner() || GetMyShop() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if ( IsOpenSafebox() || GetViewingShopOwner() || IsCubeOpen())
#else
	if (IsOpenSafebox() || GetShopOwner() || GetMyShop() || IsCubeOpen())
#endif

Arat:
	if (victim->IsOpenSafebox() || victim->GetShopOwner() || victim->GetMyShop() || victim->IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if ( victim->IsOpenSafebox() || victim->GetViewingShopOwner() || victim->IsCubeOpen() )
#else
	if (victim->IsOpenSafebox() || victim->GetShopOwner() || victim->GetMyShop() || victim->IsCubeOpen())
#endif