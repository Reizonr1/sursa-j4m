Arat:
	if (GetMyShop())
		return false;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
		return false;
#else
	if (GetMyShop())
		return false;
#endif

Arat:
	case DRAGON_SOUL_INVENTORY:
		if (wCell >= DRAGON_SOUL_INVENTORY_MAX_NUM)
		{
			sys_err("CHARACTER::GetInventoryItem: invalid DS item cell %d", wCell);
			return NULL;
		}
		return m_pointsInstant.pDSItems[wCell];

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case SHOP:
		if ( wCell >= SHOP_INVENTORY_MAX_NUM )
		{
			sys_err("CHARACTER::GetInventoryItem: invalid shop item cell %d", wCell);
			return NULL;
		}
		return m_pointsInstant.pShopItems[wCell];
#endif

Arat:
		m_pointsInstant.pDSItems[wCell] = pItem;
	}
	break;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case SHOP:
	{
		if (wCell >= SHOP_INVENTORY_MAX_NUM)
		{
			sys_err("CHARACTER::SetItem: invalid shop item cell %d", wCell);
			return;
		}

		LPITEM pOld = m_pointsInstant.pShopItems[wCell];

		if (pOld)
		{
			for (int i = 0; i < pOld->GetSize(); ++i)
			{
				int p = wCell + (i * 5);

				if (p >= SHOP_INVENTORY_MAX_NUM)
					continue;

				if (m_pointsInstant.pShopItems[p] && m_pointsInstant.pShopItems[p] != pOld)
					continue;

				m_pointsInstant.bShopItemGrid[p] = 0;
			}
		}

		if (pItem)
		{
			for (int i = 0; i < pItem->GetSize(); ++i)
			{
				int p = wCell + (i * 5);

				if (p >= SHOP_INVENTORY_MAX_NUM)
					continue;

				// wCell + 1 �� �ϴ� ���� ����� üũ�� �� ����
				// �������� ����ó���ϱ� ����
				m_pointsInstant.bShopItemGrid[p] = wCell + 1;
			}
		}

		m_pointsInstant.pShopItems[wCell] = pItem;
	}
	break;
#endif

Arat:
		case DRAGON_SOUL_INVENTORY:
			pItem->SetWindow(DRAGON_SOUL_INVENTORY);
			break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case SHOP:
			pItem->SetWindow(SHOP);
			break;
#endif

Arat:
bool CHARACTER::IsEmptyItemGrid(TItemPos Cell, BYTE bSize, int iExceptionCell) const

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CHARACTER::ClearShopItem()
{
	int		i;
	LPITEM	item;

	for (i = 0; i < SHOP_INVENTORY_MAX_NUM; ++i)
	{
		if ((item = GetItem(TItemPos(SHOP, i))))
		{
			item->SetSkipSave(true);
			ITEM_MANAGER::instance().FlushDelayedSave(item);

			item->RemoveFromCharacter();
			M2_DESTROY_ITEM(item);
		}
	}
}
#endif

Arat:
void CHARACTER::__OpenPrivateShop()

Blo�u de�i�tir ve kendinize g�re d�zenleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CHARACTER::OpenPrivateShop()
{
#ifdef ENABLE_SIT_SYSTEM
	if (GetPosition() == POS_SITTING)
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_OPEN_PRIVATE_SHOP_WITH_SIT"));
		return;
	}
#endif
	if (!GetShopItems().empty())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_NEED_TO_CLOSE_YOUR_CURRENT_SHOP_BEFORE_OPENING_NEW_ONE"));
		return;
	}

	if(SECTREE_MANAGER::instance().GetEmpireFromMapIndex(GetMapIndex()) != GetEmpire())
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_OPEN_SHOP_IN_OTHER_EMPIRE"));
		return;
	}

	if (!CShop::CanOpenShopHere(GetMapIndex()))
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_OPEN_SHOP_ON_THIS_MAP"));
		return;
	}

	ChatPacket(CHAT_TYPE_COMMAND, "OpenPrivateShop");
}
#else
void CHARACTER::__OpenPrivateShop()
{
#ifdef ENABLE_SIT_SYSTEM
	if (GetPosition() == POS_SITTING)
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_OPEN_PRIVATE_SHOP_WITH_SIT"));
		return;
	}
#endif
#ifdef ENABLE_OPEN_SHOP_WITH_ARMOR
	ChatPacket(CHAT_TYPE_COMMAND, "OpenPrivateShop");
#else
	unsigned bodyPart = GetPart(PART_MAIN);
	switch (bodyPart)
	{
	case 0:
	case 1:
	case 2:
		ChatPacket(CHAT_TYPE_COMMAND, "OpenPrivateShop");
		break;
	default:
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("������ ����� ���� ������ �� �� �ֽ��ϴ�."));
		break;
	}
#endif
}
#endif

Arat:
	__OpenPrivateShop();

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	OpenPrivateShop();
#else
	__OpenPrivateShop();
#endif

Arat:
		__OpenPrivateShop();

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		OpenPrivateShop();
#else
		__OpenPrivateShop();
#endif

Arat:
			case 50200:

Komple de�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			case 50200: // ������
				OpenPrivateShop();
				break;
#else
			case 50200:
				if (g_bEnableBootaryCheck)
				{
					if (IS_BOTARYABLE_ZONE(GetMapIndex()) == true)
					{
						__OpenPrivateShop();
					}
					else
					{
						ChatPacket(CHAT_TYPE_INFO, LC_TEXT("���� ������ �� �� ���� �����Դϴ�"));
					}
				}
				else
				{
					__OpenPrivateShop();
				}
				break;
#endif

Arat:
			case ITEM_ELK_VNUM:
			{
				int iGold = item->GetSocket(0);
				ITEM_MANAGER::instance().RemoveItem(item);
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�� %d ���� ȹ���߽��ϴ�."), iGold);
				PointChange(POINT_GOLD, iGold);
			}
			break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			case 91400: //Hourglass Sand (Shop time increase)
			case 91401:
			case 91402:
			case 91403:
			{
				if (GetShopPremiumTime() > 38 * 60) {
					ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOUR_SHOP_OFFLINE_PREMIUM_TIME_REACHED_ITS_MAX"));
					return false;
				}

				long socketValue = item->GetValue(0);
				int premTime = socketValue ? socketValue : 120;

				AlterShopPremiumTime(premTime);

				BYTE subtype = SHOP_SUBHEADER_GD_ADD_PREMIUM_TIME;
				DWORD pid = GetPlayerID();

				db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(int));
				db_clientdesc->Packet(&(subtype), sizeof(BYTE));
				db_clientdesc->Packet(&pid, sizeof(DWORD));
				db_clientdesc->Packet(&premTime, sizeof(int));

				TPacketGCShopPremiumTimeSync pTP; //Sync premium time on client
				pTP.bHeader = HEADER_GC_SYNC_SHOP_PREMTIME;
				pTP.value = GetShopPremiumTime();
				GetDesc()->Packet(&pTP, sizeof(TPacketGCShopPremiumTimeSync));

				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOUR_SHOP_TIME_WAS_INCREASED_BY_%d"), premTime);

				item->SetCount(item->GetCount()-1);
				return false;
			}
			break;
#endif

Arat:
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (GetExchange() || IsShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

Arat:
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (GetExchange() || IsShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

Arat:
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

Arat:
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
	if (GetExchange() || GetMyShop() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

Arat:
bool CHARACTER::CanDoCube() const
i�indeki
	if (GetShop())		return false;
	if (GetMyShop())	return false;
De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetViewingShop())	return false;
#else
	if (GetShop())		return false;
	if (GetMyShop())	return false;
#endif

Arat:	case MALL:
		if (NULL != m_pkMall)
			return m_pkMall->IsValidPosition(cell);
		else
			return false;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case SHOP:
		return cell < SHOP_INVENTORY_MAX_NUM;
#endif
