Arat:

	PointChange(POINT_SP_RECOVERY, -GetPoint(POINT_SP_RECOVERY));

Alt�na ekle:

#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
	CloseMyShop();
#endif

Arat:

void CHARACTER::ItemDropPenalty(LPCHARACTER pkKiller)
{
i�indeki:


	if (GetMyShop())
		return;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
		return;
#else
	if (GetMyShop())
		return;
#endif

Arat:
	CloseMyShop();

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	//Just in case we are ever .Dead()'ing a shop...
	if (IsShop())
		CloseShop();
#else
	CloseMyShop();
#endif
