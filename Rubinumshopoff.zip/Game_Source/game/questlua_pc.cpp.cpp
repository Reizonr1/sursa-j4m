Arat:
		case PREMIUM_GOLD:

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case PREMIUM_SHOP_DOUBLE_UP:
#endif

Arat:
		lua_pushboolean(L, (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen()));

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		lua_pushboolean(L, (ch->GetExchange() || ch->GetViewingShop() || ch->GetViewingShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen()));
#else
		lua_pushboolean(L, (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen()));
#endif