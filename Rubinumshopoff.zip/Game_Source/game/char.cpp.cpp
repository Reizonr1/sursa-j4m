Arat:
	m_pkShop = NULL;
	m_pkChrShopOwner = NULL;
	m_pkMyShop = NULL;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_pkViewingShop		= NULL;
	m_pkChrShopOwner	= NULL;
	m_shopOfflineEvent = NULL;
	m_shopOfflineEventRunning = false;
#else
	m_pkShop = NULL;
	m_pkChrShopOwner = NULL;
	m_pkMyShop = NULL;
#endif

Arat:
}

void CHARACTER::Create(const char* c_pszName, DWORD vid, bool isPC)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_shopItems.clear();
	m_pkMyShop = nullptr;
	m_stShopSign.clear();
	m_dwShopStash = 0;
	m_iPremiumTime = 0;
#endif

Arat:
void CHARACTER::Destroy()

Hemen alt�ndaki
CloseMyShop();
De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
	{
		CancelShopOfflineEvent();
		CloseShop();
	}
#else
	CloseMyShop();
#endif

Arat:

	if (GetShop())
	{
		GetShop()->RemoveGuest(this);
		SetShop(NULL);
	}

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetViewingShop())
	{
		GetViewingShop()->RemoveGuest(this);
		SetViewingShop(NULL);
	}
#else
	if (GetShop())
	{
		GetShop()->RemoveGuest(this);
		SetShop(NULL);
	}
#endif

Arat:
	if (NULL == m_pkMobData)
	{
		DragonSoul_CleanUp();
		ClearItem();
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	else if (IsShop())
	{
		ClearShopItem();
	}
#endif

Arat:
	void CHARACTER::OpenMyShop(const char * c_pszSign, TShopItemTable * pTable, BYTE bItemCount)


Kendinize g�re d�zenleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
	void CHARACTER::OpenMyShop(const char * c_pszSign, TShopItemTable * pTable, WORD bItemCount)
	#else
	void CHARACTER::OpenMyShop(const char * c_pszSign, TShopItemTable * pTable, BYTE bItemCount)
	#endif
{
	quest::PC * pPC = quest::CQuestManager::instance().GetPCForce(GetPlayerID());
	if (pPC->IsRunning())
		return;

	if (bItemCount == 0)
		return;
	
	//Disallow shops on certain maps
	if (!CShop::CanOpenShopHere(GetMapIndex()))
		return;

	//Check if the items + our current shop gold stash are exceeding the max yang amount.
	unsigned long long nTotalMoney = GetShopGoldStash();
	for (int n = 0; n < bItemCount; ++n)
		nTotalMoney += static_cast<unsigned long long>((pTable + n)->price);
	
	if (GOLD_MAX <= nTotalMoney)
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_HAVE_%s_IN_GOLD_STASH_AND_THE_ITEMS_YOU_SELL_ARE_WORTH_%s"), pretty_number(GetShopGoldStash()).c_str(), pretty_number(nTotalMoney - GetShopGoldStash()).c_str());
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_OPEN_THE_SHOP_BECAUSE_IT_WOULD_SET_YOU_OVER_%s"), pretty_number(GOLD_MAX).c_str());
		return;
	}

	//Don't create the shop if the title has invalid words in it (or is empty)
	char szName[256];
	DBManager::instance().EscapeString(szName, 256, c_pszSign, strlen(c_pszSign));
	std::string shopSign = szName;
	boost::replace_all(shopSign, "%", "%%");

	/*shopSign.erase(std::remove_if(shopSign.begin(), shopSign.end(), [](char c){
		return !isalnum(c) && c != ' ' && c != '+'; //< remove if this applies
	}), shopSign.end());*/

	if (shopSign.length() < 3)
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("SHOP_SIGN_INVALID_OR_TOO_SMALL"));
		return;
	}

	if (CBanwordManager::instance().CheckString(shopSign.c_str(), shopSign.length() + 1)) // Check for banned words
	{
		ChatPacket(CHAT_TYPE_INFO, LC_TEXT("SHOP_NAME_NOT_ALLOWED"));
		return;
	}
	
	// MYSHOP_PRICE_LIST
	std::map<DWORD, unsigned long long> itemkind;  // ������ ������ ����, first: vnum, second: ���� ���� ����
	// END_OF_MYSHOP_PRICE_LIST

	std::set<TItemPos> cont;
	bool emptyShop = true;
#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
	for (WORD i = 0; i < bItemCount; ++i)
#else
	for (BYTE i = 0; i < bItemCount; ++i)
#endif
	{
		if (cont.find((pTable + i)->pos) != cont.end())
		{
			sys_err("MYSHOP: duplicate shop item detected! (name: %s)", GetName());
			return;
		}

		// ANTI_GIVE, ANTI_MYSHOP check
		LPITEM pkItem = GetItem((pTable + i)->pos);

		if (pkItem)
		{
			if (emptyShop)
				emptyShop = false;

			const TItemTable * item_table = pkItem->GetProto();

			if (item_table && (IS_SET(item_table->dwAntiFlags, ITEM_ANTIFLAG_GIVE | ITEM_ANTIFLAG_MYSHOP)))
			{
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_SELL_THIS_ITEM_IN_A_PRIVATE_SHOP"));
				return;
			}

			if (pkItem->IsEquipped())
			{
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_SELL_EQUIPPED_ITEMS_IN_A_PRIVATE_SHOP"));
				return;
			}

			if (pkItem->isLocked())
			{
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEMS_BEING_IN_USE_CAN_NOT_BE_SOLD_IN_SHOP"));
				return;
			}
			
#ifdef ENABLE_ITEM_SEAL_SYSTEM
			if (pkItem->IsSealed())
			{
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEM_IS_SEALED_CANNOT_DO"));
				return;
			}
#endif

			if (pkItem->GetVnum() == 50200 || pkItem->GetVnum() == 71049) //SHOP bundle never let this get into the shop!
			{
				ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEMS_BEING_IN_USE_CAN_NOT_BE_SOLD_IN_SHOP"));
				return;
			}

			if (pkItem->GetWindow() != INVENTORY && pkItem->GetWindow() != DRAGON_SOUL_INVENTORY
#ifdef ENABLE_SPECIAL_STORAGE
			&& pkItem->GetWindow() != UPGRADE_INVENTORY && pkItem->GetWindow() != BOOK_INVENTORY && pkItem->GetWindow() != STONE_INVENTORY
#endif
			)
			{
				sys_err("Wrong window (%d) when setting item %lu on shop", pkItem->GetWindow(), pkItem->GetID());
				return;
			}

			// MYSHOP_PRICE_LIST
			itemkind[pkItem->GetVnum()] = (pTable + i)->price / pkItem->GetCount();
			// END_OF_MYSHOP_PRICE_LIST
		}

		cont.insert((pTable + i)->pos);
	}

	//No shop to build
	if (emptyShop) {
		return;
	}

	bool removeBundle = false;
	if (CountSpecifyItem(50200))
		removeBundle = true; //Remove later, only if the shop successfully spawned
	else if (CountSpecifyItem(71049))
		removeBundle = false;
	else
		return;
	//
	// ������ ���������� �����ϱ� ���� ������ �������� ��Ŷ�� ����� DB ĳ�ÿ� ������.
	//
	TPacketMyshopPricelistHeader header;
	TItemPriceInfo info;

	header.dwOwnerID = GetPlayerID();
	header.byCount = itemkind.size();

	TEMP_BUFFER buf;
	buf.write(&header, sizeof(header));

	for (itertype(itemkind) it = itemkind.begin(); it != itemkind.end(); ++it)
	{
		info.dwVnum = it->first;
		info.llPrice = it->second;

		buf.write(&info, sizeof(info));
	}

	db_clientdesc->DBPacket(HEADER_GD_MYSHOP_PRICELIST_UPDATE, 0, buf.read_peek(), buf.size());

	if (m_pkExchange)
		m_pkExchange->Cancel();

	if (CHARACTER_MANAGER::instance().SpawnShop(this, shopSign, pTable, bItemCount))
	{
		if (removeBundle)
			RemoveSpecifyItem(50200, 1);
	}
}

Arat:
if (IsPC() == true || m_bCharType == CHAR_TYPE_NPC)
De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsPC() == true || m_bCharType == CHAR_TYPE_NPC || IsShop())
#else
	if (IsPC() == true || m_bCharType == CHAR_TYPE_NPC)
#endif

Arat:
void CHARACTER::EncodeInsertPacket(LPENTITY entity)
i�indeki

	if (IsShop())
K�sm�ndan sonuna kadar kendinize g�re de�i�tirin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
	{
		TPacketGCShopSign p;

		p.bHeader = HEADER_GC_SHOP_SIGN;
		p.dwVID = GetVID();
		strlcpy(p.szSign, GetShopSign().c_str(), sizeof(p.szSign));
#ifdef ENABLE_SHOP_ITEM_PREVIEW
		LPSHOP shop = GetMyShop();
		if (shop)
		{
			std::vector<CShop::SHOP_ITEM> sendItems; // send to client
			
			std::vector<CShop::SHOP_ITEM> shop_items = GetMyShop()->GetItemVector();
			std::vector<CShop::SHOP_ITEM>::iterator item;

			for (item = shop_items.begin(); item != shop_items.end(); ++item)
			{
				LPITEM curItem = item->pkItem;
				
				if (!curItem)
					continue;
				
				if (curItem->GetSize() > 2)
					continue;
				
				if (sendItems.size() >= 4)
					continue;
				
				sendItems.push_back(*item);
			}
			
			std::stable_sort(sendItems.begin(), sendItems.end(), CompareItemVnumAcPriceAC);
			
			std::vector<CShop::SHOP_ITEM>::iterator itemSend;
			int i = 0;
			memset(p.items, 0, sizeof(p.items)); // set memory to zero
			for (item = sendItems.begin(); item != sendItems.end(); ++item)
			{
				LPITEM curItem = item->pkItem;

				if (curItem)
				{
					LPDESC d = ch->GetDesc();

					if (!d)
						return;
					
					p.items[i].count = static_cast<BYTE>(item->count);
					p.items[i].vnum = curItem->GetVnum();
					
					// memset to zero
					p.items[i].price = 0;
					p.items[i].display_pos = 0;
					memset(p.items[i].alSockets, 0, sizeof(p.items[i].alSockets));
					memset(p.items[i].aAttr, 0, sizeof(p.items[i].aAttr));
#ifdef ENABLE_BUY_WITH_ITEM
					p.items[i].witemVnum = 0;
#endif
					i++;
				}
			}
		}
#endif
		d->Packet(&p, sizeof(TPacketGCShopSign));
	}
#else
	if (GetMyShop())
	{
		TPacketGCShopSign p;

		p.bHeader = HEADER_GC_SHOP_SIGN;
		p.dwVID = GetVID();
		strlcpy(p.szSign, m_stShopSign.c_str(), sizeof(p.szSign));

		d->Packet(&p, sizeof(TPacketGCShopSign));
	}
#endif
	
	if (entity->IsType(ENTITY_CHARACTER))
	{
		sys_log(3, "EntityInsert %s (RaceNum %d) (%d %d) TO %s",
			GetName(), GetRaceNum(), GetX() / SECTREE_SIZE, GetY() / SECTREE_SIZE, ((LPCHARACTER)entity)->GetName());
	}
}

Arat:
void CHARACTER::SaveReal()
{
	if (m_bSkipSave)
		return;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
	{
		sys_err("SaveReal should not be happening on a shop char (PID %lu)", GetPlayerID());
		return;
	}
#endif

Arat:
void CHARACTER::Disconnect(const char* c_pszReason)
i�indeki
	if (GetShop())
	{
		GetShop()->RemoveGuest(this);
		SetShop(NULL);
	}
De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetViewingShop())
	{
		GetViewingShop()->RemoveGuest(this);
		SetViewingShop(NULL);
	}
#else
	if (GetShop())
	{
		GetShop()->RemoveGuest(this);
		SetShop(NULL);
	}
#endif

Arat:
bool CHARACTER::CanMove() const
{
	if (CannotMoveByAffect())
		return false;

��indeki
	if (GetMyShop())
		return false;
De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
		return false;
#else
	if (GetMyShop())
		return false;
#endif

Arat:
void CHARACTER::SetShop(LPSHOP pkShop)

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CHARACTER::SetViewingShop(LPSHOP pkShop)
{
	if ((m_pkViewingShop = pkShop))
		SET_BIT(m_pointsInstant.instant_flag, INSTANT_FLAG_SHOP);
	else
	{
		REMOVE_BIT(m_pointsInstant.instant_flag, INSTANT_FLAG_SHOP);
		SetViewingShopOwner(NULL);
	}
}
#else
void CHARACTER::SetShop(LPSHOP pkShop)
{
	if ((m_pkShop = pkShop))
		SET_BIT(m_pointsInstant.instant_flag, INSTANT_FLAG_SHOP);
	else
	{
		REMOVE_BIT(m_pointsInstant.instant_flag, INSTANT_FLAG_SHOP);
		SetShopOwner(NULL);
	}
}
#endif

Arat:
void CHARACTER::OnClick(LPCHARACTER pkChrCauser)
{
	if (!pkChrCauser)
	{
		sys_err("OnClick %s by NULL", GetName());
		return;
	}

	DWORD vid = GetVID();
	sys_log(0, "OnClick %s[vnum %d ServerUniqueID %d, pid %d] by %s", GetName(), GetRaceNum(), vid, GetPlayerID(), pkChrCauser->GetName());

Alt�na ekle:

#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
	{
		if (pkChrCauser->GetMyShop() && pkChrCauser != this)
		{
			sys_err("OnClick Fail (%s->%s) - pc has shop", pkChrCauser->GetName(), GetName());
			return;
		}
	}
#endif

Arat:
	{
		if (pkChrCauser->GetExchange())
		{
			sys_err("OnClick Fail (%s->%s) - pc is exchanging", pkChrCauser->GetName(), GetName());
			return;
		}
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (IsShop())
	{
		//Hey, it's our own shop! Say no more
		if (GetPlayerID() == pkChrCauser->GetPlayerID()) 
		{
			TPacketGCShop pack;

			pack.header = HEADER_GC_SHOP;
			pack.subheader = SHOP_SUBHEADER_GC_OPEN_SHOP_EDITOR;
			pack.size = sizeof(TPacketGCShop);

			pkChrCauser->GetDesc()->Packet(&pack, sizeof(pack));
			return;
		}

		//Dead players can't trade
		if (pkChrCauser->IsDead() == true) 
			return;
	
		//If clicker has safebox open, a npc shop open, or cube open, that probably breaks things,
		//so... you can't open a shop.
		if (pkChrCauser->IsOpenSafebox() || pkChrCauser->GetViewingShopOwner() || pkChrCauser->IsCubeOpen())
		{
			pkChrCauser->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_USE_PRIVATE_SHOPS_CURRENTLY"));
			return;
		}

		if (pkChrCauser->GetViewingShop())
		{
			pkChrCauser->GetViewingShop()->RemoveGuest(pkChrCauser);
			pkChrCauser->SetViewingShop(NULL);
		}

		GetMyShop()->AddGuest(pkChrCauser, GetVID(), false);
		pkChrCauser->SetViewingShopOwner(this);
		return;
	}
#endif

Arat:
	if (IsPC())
	{
		if (!CTargetManager::instance().GetTargetInfo(pkChrCauser->GetPlayerID(), TARGET_TYPE_VID, GetVID()))
		{

Alt�na ekle:

#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
			// 2005.03.17.myevan.
			if (GetMyShop())
			{
				if (pkChrCauser->IsDead() == true) return;

				//PREVENT_TRADE_WINDOW
				if (pkChrCauser == this)
				{
					if ((GetExchange() || IsOpenSafebox() || GetShopOwner()) || IsCubeOpen())
					{
						pkChrCauser->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�ٸ� �ŷ���(â��,��ȯ,����)���� ���λ����� ����� �� �����ϴ�."));
						return;
					}
				}
				else
				{
					if ((pkChrCauser->GetExchange() || pkChrCauser->IsOpenSafebox() || pkChrCauser->GetMyShop() || pkChrCauser->GetShopOwner()) || pkChrCauser->IsCubeOpen())
					{
						pkChrCauser->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�ٸ� �ŷ���(â��,��ȯ,����)���� ���λ����� ����� �� �����ϴ�."));
						return;
					}

					//if ((GetExchange() || IsOpenSafebox() || GetShopOwner()))
					if ((GetExchange() || IsOpenSafebox() || IsCubeOpen()))
					{
						pkChrCauser->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("������ �ٸ� �ŷ��� �ϰ� �ִ� ���Դϴ�."));
						return;
					}

				}
				//END_PREVENT_TRADE_WINDOW

				if (pkChrCauser->GetShop())
				{
					pkChrCauser->GetShop()->RemoveGuest(pkChrCauser);
					pkChrCauser->SetShop(NULL);
				}

				GetMyShop()->AddGuest(pkChrCauser, GetVID(), false);
				pkChrCauser->SetShopOwner(this);
				return;
			}
#endif

Arat:
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (GetExchange() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
		if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

Arat:
	if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (GetExchange() || GetViewingShopOwner() || IsOpenSafebox() || IsCubeOpen())
#else
	if (GetExchange() || GetMyShop() || GetShopOwner() || IsOpenSafebox() || IsCubeOpen())
#endif

En alta ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CHARACTER::RemoveShopItemByPos(BYTE pos)
{
	TPacketPlayerShopSet pack;
	pack.header = HEADER_GC_PLAYER_SHOP_SET;
	pack.pos = pos;

	pack.count = 0;
	pack.vnum = 0;
	pack.price = 0;

	memset(pack.alSockets, 0, sizeof(pack.alSockets));
	memset(pack.aAttr, 0, sizeof(pack.aAttr));
	GetDesc()->Packet(&pack, sizeof(TPacketPlayerShopSet));
}

void CHARACTER::SetClearShop()
{
	m_shopItems.clear();
}

void CHARACTER::ShopSellResult(DWORD itemVnum, int amount, unsigned long long gold, BYTE pos)
{
	TItemTable * itemTable = ITEM_MANAGER::instance().GetTable(itemVnum);
	if (!itemTable) 
	{
		sys_err("Error informing of a sale of %d of %lu for %llu (Item does not exist)", amount, itemVnum, gold);
		return;
	}

	std::vector<TPlayerItem> shopItems = GetShopItems(); 	//Remove it from the list of the shop items on the receiver
	for (auto it = shopItems.begin(); it != shopItems.end(); ++it)
	{
		if (it->pos == pos)	
		{
			shopItems.erase(it);
			break;
		}
	}
	SetShopItems(shopItems);

	char buf[256];
	snprintf(buf, sizeof(buf), "ShopSaleResult %d %s %lld %d", amount, itemTable->szLocaleName, gold, pos);
	ChatPacket(CHAT_TYPE_COMMAND, buf);
	
	//Inform
	//ChatPacket(CHAT_TYPE_INFO, LC_TEXT("SALE_OF_%d_OF_%s_FOR_%s_GOLD"), amount, itemTable->szLocaleName, pretty_number(gold).c_str());
	
	//if (shopItems.empty())
		//ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOUR_SHOP_HAS_CLOSED_AFTER_RUNNING_OUT_OF_ITEMS_TOTAL_PROFIT_%s"), pretty_number(gold + GetShopGoldStash()).c_str());

	//Remove the sold item from the shop UI
	RemoveShopItemByPos(pos);

	//Update stash local value and sync in client
	AlterShopGoldStash(gold);

	TPacketGCShopStashSync stash;
	stash.bHeader = HEADER_GC_SYNC_SHOP_STASH;
	stash.value = GetShopGoldStash();
	GetDesc()->Packet(&stash, sizeof(TPacketGCShopStashSync));
	
	//Log
	sys_log(0, "ShopSellNotify: %dx %lu for %llu gold [%s] stash [%llu]", amount, itemVnum, gold, GetName(), stash.value);
}

EVENTINFO(shop_offline_event_info)
{
	DynamicCharacterPtr ch;
	int loops;
};

EVENTFUNC(shop_offline_event)
{
	shop_offline_event_info* info = dynamic_cast<shop_offline_event_info*>(event->info);
	if (!info) {
		sys_err("shop_offline_event char nullptr");
		return 0;
	}

	LPCHARACTER	ch = info->ch;
	if (!ch)
		return 0;

	ch->SetShopOfflineEventRunning(true);

	if (!ch->AlterShopOfflineTime(-1)) // Time ran out.
	{
		if (test_server)
			sys_log(0, "Closing shop #%lu after having ran out of offline time", ch->GetPlayerID());

		ch->SetShopOfflineEventRunning(false);
		ch->GetMyShop()->SetClosed(true);
		ch->GetMyShop()->SaveOffline();
		ch->GetMyShop()->Save();
		M2_DESTROY_CHARACTER(ch);
		return 0;
	}

	//Save every 5 loops (i.e 5 minutes)
	++info->loops;
	if (info->loops % 5 == 0)
		ch->GetMyShop()->SaveOffline();

	return PASSES_PER_SEC(60);
}

bool CHARACTER::AlterShopOfflineTime(int delta)
{
	if (!GetMyShop())
	{
		sys_err("No open shop to alter time on.");
		return false;
	}

	int premiumMinutes = GetMyShop()->GetPremiumMinutes();
	int offlineMinutes = GetMyShop()->GetOfflineMinutes();

	//Let's exhaust free minutes first
	if (offlineMinutes > 0)
	{
		offlineMinutes = std::max(0, offlineMinutes + delta);
		GetMyShop()->SetOfflineMinutes(offlineMinutes);
	}
	else
	{
		premiumMinutes = std::max(0, premiumMinutes + delta);
		GetMyShop()->SetPremiumMinutes(premiumMinutes);
	}

	return offlineMinutes > 0 || premiumMinutes > 0; // Return whether the time has ran out.
}

int CHARACTER::GetShopOfflineTime()
{
	if (!GetMyShop())
		return 0;

	return GetMyShop()->GetOfflineMinutes();
}


void CHARACTER::StartShopOfflineEvent()
{
	shop_offline_event_info* info = AllocEventInfo<shop_offline_event_info>();
	info->ch = this;
	info->loops = 0;

	m_shopOfflineEvent = event_create(shop_offline_event, info, test_server ? PASSES_PER_SEC(1 * 60) : PASSES_PER_SEC(5 * 60));

	TPacketGGShopStartOffline p;
	p.bHeader = HEADER_GG_SHOP_OFFLINE_START;
	p.bChannel = g_bChannel;
	p.lMapIndex = GetMapIndex();
	p.bEmpire = GetEmpire();
	p.dwPID = GetPlayerID();

	P2P_MANAGER::instance().Send(&p, sizeof(TPacketGGShopStartOffline));
}

void CHARACTER::CancelShopOfflineEvent()
{
	if (!m_shopOfflineEvent)
		return;

	if (IsShopOfflineEventRunning()) //Only if the event did not already destroy the shop
		GetMyShop()->SaveOffline();

	event_cancel(&m_shopOfflineEvent);
	SetShopOfflineEventRunning(false);

	TPacketGGShopEndOffline p;
	p.bHeader = HEADER_GG_SHOP_OFFLINE_END;
	p.dwPID = GetPlayerID();

	P2P_MANAGER::instance().Send(&p, sizeof(TPacketGGShopEndOffline));
}
#endif