Arat:
	void			RegisterRaceNum(DWORD dwVnum);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	int				CountOfflineShops();
#endif

Arat:
	bool			BeginPendingDestroy();
	void			FlushPendingDestroy();

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	LPCHARACTER 	SpawnShop(LPCHARACTER ch, std::string shopSign, TShopItemTable* shopItemTable, BYTE itemCount, DWORD startTime = 0);
	LPCHARACTER 	FindPCShopCharacterByPID(DWORD pid);
#endif