Arat:
	WORD			wDSItemGrid[DRAGON_SOUL_INVENTORY_MAX_NUM];

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	LPITEM			pShopItems[SHOP_INVENTORY_MAX_NUM];
	BYTE			bShopItemGrid[SHOP_INVENTORY_MAX_NUM];
#endif

Arat:
	bool			IsGoto() const { return m_bCharType == CHAR_TYPE_GOTO; }

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	bool			IsShop() const { return m_bCharType == CHAR_TYPE_SHOP; }
#endif

Arat:
	////////////////////////////////////////////////////////////////////////////////////////
	// Shop related
public:
	void			SetShop(LPSHOP pkShop);
	LPSHOP			GetShop() const { return m_pkShop; }
	void			ShopPacket(BYTE bSubHeader);

	void			SetShopOwner(LPCHARACTER ch) { m_pkChrShopOwner = ch; }
	LPCHARACTER		GetShopOwner() const { return m_pkChrShopOwner; }

	void			OpenMyShop(const char* c_pszSign, TShopItemTable* pTable, BYTE bItemCount);
	LPSHOP			GetMyShop() const { return m_pkMyShop; }
	void			CloseMyShop();

protected:

	LPSHOP			m_pkShop;
	LPSHOP			m_pkMyShop;
	std::string		m_stShopSign;
	LPCHARACTER		m_pkChrShopOwner;
	// End of shop

De�i�tir i�ini kendinize g�re d�zenleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	////////////////////////////////////////////////////////////////////////////////////////
	// Shop related
public:
	void			SetViewingShop(LPSHOP pkShop);
	LPSHOP			GetViewingShop() const { return m_pkViewingShop; }
	void			ShopPacket(BYTE bSubHeader);

	void			SetViewingShopOwner(LPCHARACTER ch) { m_pkChrShopOwner = ch; }
	LPCHARACTER		GetViewingShopOwner() const { return m_pkChrShopOwner;}
	
	#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
	void			OpenMyShop(const char * c_pszSign, TShopItemTable * pTable, WORD bItemCount);
	#else
	void			OpenMyShop(const char * c_pszSign, TShopItemTable * pTable, BYTE bItemCount);
	#endif
	void			CloseShop();

	void			SetMyShop(LPSHOP shop) { m_pkMyShop = shop; };
	LPSHOP			GetMyShop() const { return m_pkMyShop; }
	
	//Inform the player that a successful sale took place
	void ShopSellResult(DWORD itemVnum, int amount, unsigned long long gold, BYTE pos);

	//Shop information
	void			SetShopSign(std::string sign) { m_stShopSign = sign; }
	std::string		GetShopSign() const { return m_stShopSign; }
	void			ClearShopSign() { m_stShopSign.clear(); }

	void AlterShopGoldStash(long long gold) { m_dwShopStash += gold; }
	unsigned long long GetShopGoldStash() const { return m_dwShopStash; }

	void			AlterShopPremiumTime(int time) { m_iPremiumTime += time; }
	int				GetShopPremiumTime() const { return m_iPremiumTime; }

	//Shop offline timing and events
	void			StartShopOfflineEvent();
	void			CancelShopOfflineEvent();
	bool			AlterShopOfflineTime(int delta);
	int				GetShopOfflineTime();

	void			SetShopOfflineEventRunning(bool value) { m_shopOfflineEventRunning = value; }
	bool			IsShopOfflineEventRunning() const { return m_shopOfflineEventRunning; }

	std::vector<npc_info>::iterator m_npcListVectorPosition;

protected:
	LPEVENT m_shopOfflineEvent;
	bool m_shopOfflineEventRunning;
	std::vector<TPlayerItem> m_shopItems;
	LPSHOP			m_pkViewingShop;
	LPSHOP			m_pkMyShop;
	
	LPCHARACTER		m_pkChrShopOwner;

	std::string m_stShopSign;
	unsigned long long m_dwShopStash;
	int m_iPremiumTime;
	// End of shop
#else
	////////////////////////////////////////////////////////////////////////////////////////
	// Shop related
public:
	void			SetShop(LPSHOP pkShop);
	LPSHOP			GetShop() const { return m_pkShop; }
	void			ShopPacket(BYTE bSubHeader);

	void			SetShopOwner(LPCHARACTER ch) { m_pkChrShopOwner = ch; }
	LPCHARACTER		GetShopOwner() const { return m_pkChrShopOwner; }

	void			OpenMyShop(const char* c_pszSign, TShopItemTable* pTable, BYTE bItemCount);
	LPSHOP			GetMyShop() const { return m_pkMyShop; }
	void			CloseMyShop();

protected:

	LPSHOP			m_pkShop;
	LPSHOP			m_pkMyShop;
	std::string		m_stShopSign;
	LPCHARACTER		m_pkChrShopOwner;
	// End of shop
#endif

Arat:
private:
	void	__OpenPrivateShop();

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
public:
	void	OpenPrivateShop();
#else
private:
	void	__OpenPrivateShop();
#endif

Sonlara do�ru m�sait bir yere ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
public:
	void MarkAsShop() { m_bCharType = CHAR_TYPE_SHOP; }
	void RemoveShopItemByPos(BYTE pos);
	void ClearShopItem();
	void SetClearShop();
	void SetShopItems(std::vector<TPlayerItem> vec) { m_shopItems = vec; }
	std::vector<TPlayerItem> GetShopItems() const { return m_shopItems; }
#endif
