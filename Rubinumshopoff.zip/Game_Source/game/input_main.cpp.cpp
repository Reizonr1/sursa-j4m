Arat:
				if (ch->GetMyShop() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->IsCubeOpen())

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
				if (ch->IsOpenSafebox() || ch->GetViewingShopOwner() || ch->IsCubeOpen())
#else
				if (ch->GetMyShop() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->IsCubeOpen())
#endif

Arat:
		switch (victim->GetCharType())
		{
		case CHAR_TYPE_NPC:

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case CHAR_TYPE_SHOP:
#endif

Arat:
		switch (victim->GetCharType())
		{
		case CHAR_TYPE_NPC:

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		case CHAR_TYPE_SHOP:
#endif

Arat:
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->IsCubeOpen())

De�i�tir

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetViewingShopOwner() || ch->IsCubeOpen())
#else
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->IsCubeOpen())
#endif


Hemen alt�nda bul:

	sys_log(0, "MyShop count %d", p->bCount);
	ch->OpenMyShop(p->szSign, (TShopItemTable*)(c_pData + sizeof(TPacketCGMyShop)), p->bCount);
	return (iExtraLen);
}

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!ch->GetShopItems().empty()) 
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_NEED_TO_CLOSE_YOUR_CURRENT_SHOP_BEFORE_OPENING_NEW_ONE"));
		return iExtraLen;
	}

	//Disallow shops on certain maps
	if (!CShop::CanOpenShopHere(ch->GetMapIndex()))
		return iExtraLen;
#endif

Arat:
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->GetMyShop() || ch->IsCubeOpen())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetViewingShopOwner() || ch->IsCubeOpen())
#else
	if (ch->GetExchange() || ch->IsOpenSafebox() || ch->GetShopOwner() || ch->GetMyShop() || ch->IsCubeOpen())
#endif

Arat:
void CInputMain::Refine(LPCHARACTER ch, const char* c_pData)

Bu blo�un biti�inin alt�na ekleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CInputMain::RemoveMyShopItem(LPCHARACTER ch, const char * c_pData)
{
	const TPacketMyShopRemoveItem * p = reinterpret_cast<const TPacketMyShopRemoveItem *>(c_pData);
	LPCHARACTER myShopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(ch->GetPlayerID());

	if (ch->GetShopItems().empty())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("PRIVATE_SHOP_NOT_OPEN"));
		if (myShopChar) 
		{
			sys_err("Player #%lu should not have a shop open! Closing it down.", ch->GetPlayerID());
			myShopChar->CloseShop();
			M2_DESTROY_CHARACTER(myShopChar);
		}

		return;
	}

	//Player needs to be in the shop's map AND near the shop
	if (!myShopChar ||
		myShopChar->GetMapIndex() != ch->GetMapIndex() ||
		DISTANCE_APPROX(myShopChar->GetX() - ch->GetX(), myShopChar->GetY() - ch->GetY()) > 20000)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_TAKE_ITEMS_FROM_MYSHOP_FROM_FAR_AWAY"));
		return;
	}

	//The item on the position we are removing must exist on the shop.
	LPITEM item = myShopChar->GetItem(TItemPos(SHOP, p->slot));
	if (!item) {
		return;
	}

	if (LPSHOP shop = myShopChar->GetMyShop())
	{
		if (shop->TransferItemAway(ch, (BYTE)p->slot, p->target))
		{
			LogManager::instance().ItemLog(ch, item, "TAKE_FROM_SHOP", item->GetName());

			//Remove from DB
			DWORD pid = ch->GetPlayerID();
			BYTE pos = (BYTE)p->slot;

			if (!shop->IsEmpty())
			{
				db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(BYTE));
				BYTE subheader = SHOP_SUBHEADER_GD_REMOVE;
				db_clientdesc->Packet(&subheader, sizeof(BYTE));
				db_clientdesc->Packet(&pid, sizeof(DWORD));
				db_clientdesc->Packet(&pos, sizeof(BYTE));
			}

			//Remove it at the player interface
			TPacketPlayerShopSet pack;
			pack.header = HEADER_GC_PLAYER_SHOP_SET;
			pack.pos = (BYTE)p->slot;

			pack.count = 0;
			pack.vnum = 0;
			pack.price = 0;

			memset(pack.alSockets, 0, sizeof(pack.alSockets));
			memset(pack.aAttr, 0, sizeof(pack.aAttr));

			ch->GetDesc()->Packet(&pack, sizeof(TPacketPlayerShopSet));
		}

		//Closed shop, destroy it (through owner)
		if (shop->IsClosed()) 
		{
			TPacketPlayerShopSign p; // Also sync the shop sign here
			p.header = HEADER_GC_MY_SHOP_SIGN;
			memset(p.sign, 0, sizeof(p.sign));
			ch->GetDesc()->Packet(&p, sizeof(TPacketPlayerShopSign));

			M2_DESTROY_CHARACTER(myShopChar);
			myShopChar = nullptr;
		}
	}
}

/*
* Add an item to the player's private shop, provided the player
* is close to it.
*/
void CInputMain::AddMyShopItem(LPCHARACTER ch, const char * c_pData)
{
	const TPacketMyShopAddItem * p = reinterpret_cast<const TPacketMyShopAddItem *>(c_pData);

	if (ch->GetShopItems().empty()) 
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("PRIVATE_SHOP_NOT_OPEN"));
		return;
	}

	if (p->from.window_type != INVENTORY && p->from.window_type != DRAGON_SOUL_INVENTORY
#ifdef ENABLE_SPECIAL_STORAGE
		&& p->from.window_type != UPGRADE_INVENTORY && p->from.window_type != BOOK_INVENTORY && p->from.window_type != STONE_INVENTORY
#endif
	) 
	{
		sys_err("Ignoring my shop item transfer because the window is not valid (%d)", p->from.window_type);
		return;
	}

	LPCHARACTER myShopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(ch->GetPlayerID());

	if (!myShopChar)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOUR_MYSHOP_COULD_NOT_BE_FOUND_ON_THIS_CHANNEL"));
		return;
	}

	if(DISTANCE_APPROX(myShopChar->GetX() - ch->GetX(), myShopChar->GetY() - ch->GetY()) > 20000)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_ADD_ITEMS_TO_MYSHOP_FROM_FAR_AWAY"));
		return;
	}

	//Player needs to be in the shop's map AND near the shop
	if (myShopChar->GetMapIndex() != ch->GetMapIndex())		
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_ADD_ITEMS_TO_MYSHOP_FROM_ANOTHER_MAP"));
		return;
	}

	if (SECTREE_MANAGER::instance().GetEmpireFromMapIndex(ch->GetMapIndex()) != ch->GetEmpire())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_ADD_ITEMS_TO_MYSHOP_FROM_OTHER_COUNTRY"));
		return;
	}
	
	//If current gold stash plus the price we want to sell this item for would go over max gold, 
	//then we can't add the item to the shop.
	unsigned long long currentStash = ch->GetShopGoldStash();
	if (currentStash + p->price >= GOLD_MAX)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_ADD_THIS_ITEM_OR_YOU_WILL_EXCEED_MAX_GOLD_IN_SHOP_STASH"));
		return;
	}
	
	//That was a preliminary stash check. Now let's take into account aaall the items we have in the shop.
	//If we sold all of them, could the gold still fit in within the stash limits?
	unsigned long long finalStash = currentStash + p->price;

	LPSHOP shop = myShopChar->GetMyShop();
	if (!shop)
		return;

	for (const auto sItem : shop->GetItemVector())	{
		finalStash += sItem.price;
	}

	if (finalStash >= GOLD_MAX)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_ADD_THIS_ITEM_OR_YOU_WILL_EXCEED_MAX_GOLD_IN_SHOP_STASH"));
		return;
	}

	//The item on the position we are removing must exist on the player.
	LPITEM item = ch->GetItem(p->from);
	if (!item) {
		return;
	}

	if (IS_SET(item->GetAntiFlag(), ITEM_ANTIFLAG_GIVE | ITEM_ANTIFLAG_MYSHOP))
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("����ȭ �������� ���λ������� �Ǹ��� �� �����ϴ�."));
		return;
	}

	if (item->IsEquipped())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("������� �������� ���λ������� �Ǹ��� �� �����ϴ�."));
		return;
	}

	if (item->isLocked())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEMS_BEING_IN_USE_CAN_NOT_BE_SOLD_IN_SHOP"));
		return;
	}

#ifdef ENABLE_ITEM_SEAL_SYSTEM
	if (item->IsSealed())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEM_IS_SEALED_CANNOT_DO"));
		return;
	}
#endif

	if (item->GetVnum() == 50200 || item->GetVnum() == 71049) //SHOP bundle never let this get into the shop!
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("ITEMS_BEING_IN_USE_CAN_NOT_BE_SOLD_IN_SHOP"));
		return;
	}

	if (shop)
	{
		TShopItemTable t;
		t.vnum = item->GetVnum();
#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
		t.count = (WORD)item->GetCount();
#else
		t.count = (BYTE)item->GetCount();
#endif
		t.display_pos = p->targetPos;
		t.price = p->price;
		t.pos = p->from;
		
		shop->TransferItems(ch, &t, 1);
		shop->SetShopItem(&t);

		shop->BroadcastUpdateItem(p->targetPos);

		//Optimizable: Only save the new item's data (Or all items), instead of performing a full save.
		shop->Save();

		sys_log(0, "Completed addition of %lu at pos %d on #%lu's shop", t.vnum, t.display_pos, ch->GetPlayerID());
	}
}


void CInputMain::OpenPlayerShop(LPCHARACTER ch)
{
#ifdef ENABLE_PRIVATESHOP_SYSTEM_ALWAYS_SILK
	ch->UseSilkBotary();
#else
	ch->OpenPrivateShop();
#endif 
}

/*
* Close the private shop completely.
*/
void CInputMain::ClosePlayerShop(LPCHARACTER ch)
{
	if (ch->GetShopItems().empty())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("PRIVATE_SHOP_NOT_OPEN"));
		return;
	}

	LPCHARACTER myShopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(ch->GetPlayerID());

	//Player needs to be in the shop's map AND near the shop
	if (!myShopChar || myShopChar->GetMapIndex() != ch->GetMapIndex() ||
		DISTANCE_APPROX(myShopChar->GetX() - ch->GetX(), myShopChar->GetY() - ch->GetY()) > 20000)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_CLOSE_YOUR_SHOP_FROM_FAR_AWAY"));
		return;
	}

	LPSHOP shop = myShopChar->GetMyShop();
	if (!shop)
	{
		sys_err("No shop on shop char for %lu!", ch->GetPlayerID());
		return;
	}

	//Create a grid and fill it with the inventory.
	CGrid inventoryGrid1(5, INVENTORY_MAX_NUM / 5 / 2);
	CGrid inventoryGrid2(5, INVENTORY_MAX_NUM / 5 / 2);
	CGrid inventoryGrid3(5, INVENTORY_MAX_NUM / 5 / 2);
	CGrid inventoryGrid4(5, INVENTORY_MAX_NUM / 5 / 2);
	CGrid inventoryGrid5(5, INVENTORY_MAX_NUM / 5 / 2);

	inventoryGrid1.Clear();
	inventoryGrid2.Clear();
	inventoryGrid3.Clear();
	inventoryGrid4.Clear();
	inventoryGrid5.Clear();

	LPITEM item;

	int i;

	const int perPageSlotCount = INVENTORY_PAGE_SIZE;

	for (i = 0; i < INVENTORY_MAX_NUM; ++i) {
		if (!(item = ch->GetInventoryItem(i)))
			continue;

		BYTE itemSize = item->GetSize();

		if (i < perPageSlotCount) // Notice: This is adjusted for 4 Pages only!
			inventoryGrid1.Put(i, 1, itemSize);
		else if (i < perPageSlotCount * 2)
			inventoryGrid2.Put(i - perPageSlotCount, 1, itemSize);
		else if (i < perPageSlotCount * 3)
			inventoryGrid3.Put(i - perPageSlotCount * 2, 1, itemSize);
		else if (i < perPageSlotCount * 4)
			inventoryGrid4.Put(i - perPageSlotCount * 3, 1, itemSize);
		else
			inventoryGrid5.Put(i - perPageSlotCount * 4, 1, itemSize);
	}
	
	//Create a vector just with the valid items and then reverse sort it
	std::vector<LPITEM> shopItems;
	for (const auto sItem : shop->GetItemVector())
	{
		if (sItem.pkItem)
			shopItems.push_back(sItem.pkItem);
	}

	std::sort(shopItems.begin(), shopItems.end(), [](const LPITEM& lhs, const LPITEM& rhs) {
		return lhs->GetSize() > rhs->GetSize();
	});

	//Add (to the grid) the items that shop contains
	for (const auto shopItem : shopItems)
	{
		int height = shopItem->GetSize();
		if (!shopItem->IsDragonSoul()
#ifdef ENABLE_SPECIAL_STORAGE
			&& !shopItem->IsUpgradeItem() && !shopItem->IsBook() && !shopItem->IsStone()
#endif
		)
		{
			int inv1Pos = inventoryGrid1.FindBlank(1, height);
			int inv2Pos = inventoryGrid2.FindBlank(1, height);
			int inv3Pos = inventoryGrid3.FindBlank(1, height);
			int inv4Pos = inventoryGrid4.FindBlank(1, height);

			if (inv1Pos >= 0)
			{
				inventoryGrid1.Put(inv1Pos, 1, height);
			}
			else if (inv2Pos >= 0)
			{
				inventoryGrid2.Put(inv2Pos, 1, height);
			}
			else if (inv3Pos >= 0)
			{
				inventoryGrid3.Put(inv3Pos, 1, height);
			}
			else if (inv4Pos >= 0)
			{
				inventoryGrid4.Put(inv4Pos, 1, height);
			}
			else
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				return;
			}
		}
		else
		{
			//We can almost always place Dragon Soul(s)
		}
	}

	//We got here, all is OK! Transfer.
	//Must transfer in this order.
	for (const auto item : shopItems)
	{
		BYTE displayPos = (BYTE)item->GetCell();

		if (item->IsDragonSoul())
		{
			int pos = ch->GetEmptyDragonSoulInventory(item);
			if (pos < 0) 
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				sys_err("Closing shop failed. Could not place DS of vnum %d", item->GetVnum());
				return;
			}

			if (!shop->TransferItemAway(ch, displayPos, TItemPos(DRAGON_SOUL_INVENTORY, pos)))
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("FAILED_TO_TRANSFER_ITEM_TO_INVENTORY"));
				return;
			}
				
		}
#ifdef ENABLE_SPECIAL_STORAGE
		else if (item->IsUpgradeItem())
		{
			int pos = ch->GetEmptyUpgradeInventory(item);
			if (pos < 0) 
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				sys_err("Closing shop failed. Could not place DS of vnum %d", item->GetVnum());
				return;
			}

			if (!shop->TransferItemAway(ch, displayPos, TItemPos(UPGRADE_INVENTORY, pos)))
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("FAILED_TO_TRANSFER_ITEM_TO_INVENTORY"));
				return;
			}
		}
		else if (item->IsBook())
		{
			int pos = ch->GetEmptyBookInventory(item);
			if (pos < 0) 
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				sys_err("Closing shop failed. Could not place DS of vnum %d", item->GetVnum());
				return;
			}

			if (!shop->TransferItemAway(ch, displayPos, TItemPos(BOOK_INVENTORY, pos)))
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("FAILED_TO_TRANSFER_ITEM_TO_INVENTORY"));
				return;
			}
		}
		else if (item->IsStone())
		{
			int pos = ch->GetEmptyStoneInventory(item);
			if (pos < 0) 
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				sys_err("Closing shop failed. Could not place DS of vnum %d", item->GetVnum());
				return;
			}

			if (!shop->TransferItemAway(ch, displayPos, TItemPos(STONE_INVENTORY, pos)))
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("FAILED_TO_TRANSFER_ITEM_TO_INVENTORY"));
				return;
			}
		}
#endif
		else
		{
			int pos = ch->GetEmptyInventory(item->GetSize());
			if (pos < 0)
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_DONT_HAVE_ENOUGH_INVENTORY_SPACE_TO_CLOSE_YOUR_SHOP"));
				sys_err("Closing shop failed. Unexpected could not place item of size %d", item->GetSize());
				return;
			}

			if (!shop->TransferItemAway(ch, displayPos, TItemPos(INVENTORY, pos)))
			{
				ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("FAILED_TO_TRANSFER_ITEM_TO_INVENTORY"));
				return;
			}
		}

		LogManager::instance().ItemLog(ch, item, "TAKE_FROM_SHOP", item->GetName());

		//Remove from DB (if not done already)
		if (!shop->IsEmpty())
		{
			DWORD pid = ch->GetPlayerID();
			BYTE pos = displayPos;

			db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(BYTE));
			BYTE subheader = SHOP_SUBHEADER_GD_REMOVE;
			db_clientdesc->Packet(&subheader, sizeof(BYTE));
			db_clientdesc->Packet(&pid, sizeof(DWORD));
			db_clientdesc->Packet(&pos, sizeof(BYTE));
		}

		//Remove it at the player interface
		TPacketPlayerShopSet pack;
		pack.header = HEADER_GC_PLAYER_SHOP_SET;
		pack.pos = displayPos;

		pack.count = 0;
		pack.vnum = 0;
		pack.price = 0;

		memset(pack.alSockets, 0, sizeof(pack.alSockets));
		memset(pack.aAttr, 0, sizeof(pack.aAttr));

		ch->GetDesc()->Packet(&pack, sizeof(TPacketPlayerShopSet));
	}	

	//Closed shop, destroy it (through owner)
	if (shop->IsClosed())
	{
		TPacketPlayerShopSign p; // Also sync the shop sign here
		p.header = HEADER_GC_MY_SHOP_SIGN;
		memset(p.sign, 0, sizeof(p.sign));
		ch->GetDesc()->Packet(&p, sizeof(TPacketPlayerShopSign));

		M2_DESTROY_CHARACTER(myShopChar);
		myShopChar = nullptr;
	}
}

/*
* Withdraw gold from the shop stash (generated by sales)
*/
void CInputMain::WithdrawShopStash(LPCHARACTER ch, const TPacketCGShopWithdraw * pack)
{
	if (!ch)
		return;

	unsigned long long withdrawAmount = pack->amount;

	if (withdrawAmount > ch->GetShopGoldStash())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANT_WITHDRAW_MORE_THAN_YOU_HAVE"));
		return;
	}

	if (ch->GetGold() + withdrawAmount >= GOLD_MAX)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("CANNOT_WITHDRAW_%s_GOLD_INVENTORY_LIMIT"), pretty_number(GOLD_MAX).c_str());
		return;
	}

	auto pid = ch->GetPlayerID();

	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, ch->GetDesc()->GetHandle(), sizeof(BYTE) + sizeof(DWORD) + sizeof(unsigned long long));
	BYTE subheader = SHOP_SUBHEADER_GD_WITHDRAW;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));
	db_clientdesc->Packet(&withdrawAmount, sizeof(unsigned long long));

}
void CInputMain::RenameShop(LPCHARACTER ch, TPacketGCShopRename *pack)
{
	if (!ch)
		return;

	DWORD pid = ch->GetPlayerID();

	char newName[SHOP_SIGN_MAX_LEN + 1];
	strlcpy(newName, pack->sign, sizeof(newName));

	LPCHARACTER myShopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(pid);

	if (!myShopChar ||
		myShopChar->GetMapIndex() != ch->GetMapIndex() ||
		DISTANCE_APPROX(myShopChar->GetX() - ch->GetX(), myShopChar->GetY() - ch->GetY()) > 20000)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CANNOT_CHANGE_NAME_OF_MYSHOP_FROM_FAR_AWAY"));
		return;
	}


	LPSHOP shop = myShopChar->GetMyShop();

	if (!shop)
		return;

	int lastRenamePulse = shop->GetRenamePulse();
	int currentPulse = thecore_pulse();

	if (lastRenamePulse > currentPulse) {
		int deltaInSeconds = ((lastRenamePulse / PASSES_PER_SEC(1)) - (currentPulse / PASSES_PER_SEC(1)));
		int minutes = deltaInSeconds / 60;
		int seconds = (deltaInSeconds - (minutes * 60));

		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_CAN_ONLY_CHANGE_YOUR_SHOP_NAME_ONCE_IN_60_MINUTES_(%02d:%02d_left)"), minutes, seconds);
		return;
	}

	//Don't create the shop if the title has invalid words in it (or is empty)
	std::string shopSign = newName;

	shopSign.erase(std::remove_if(shopSign.begin(), shopSign.end(), [](char c){
		return !isalnum(c) && c != ' ' && c != '+'; //< remove if this applies
	}), shopSign.end());

	if (shopSign.length() < 3)
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("SHOP_SIGN_INVALID_OR_TOO_SMALL"));
		return;
	}

	if (CBanwordManager::instance().CheckString(shopSign.c_str(), shopSign.length() + 1)) // Check for banned words
	{
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("SHOP_NAME_NOT_ALLOWED"));
		return;
	}

	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(newName));
	BYTE subheader = SHOP_SUBHEADER_GD_RENAME;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));
	db_clientdesc->Packet(shopSign.c_str(), sizeof(newName));
}
#endif

Arat:
	if (ch->IsOpenSafebox() || ch->GetShop() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange() || ch->GetMyShop())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->IsOpenSafebox() || ch->GetViewingShopOwner() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange())
#else
	if (ch->IsOpenSafebox() || ch->GetShop() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange() || ch->GetMyShop())
#endif

Arat:
	if (ch->IsOpenSafebox() || ch->GetShop() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange() || ch->GetMyShop())

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->IsOpenSafebox() || ch->GetViewingShopOwner() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange())
#else
	if (ch->IsOpenSafebox() || ch->GetShop() || ch->IsCubeOpen() || ch->IsDead() || ch->GetExchange() || ch->GetMyShop())
#endif

Arat:
	}
	return (iExtraLen);
}


�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case HEADER_CG_MYSHOP_REMOVE_ITEM:
		RemoveMyShopItem(ch, c_pData);
		break;

	case HEADER_CG_MYSHOP_ADD_ITEM:
		AddMyShopItem(ch, c_pData);
		break;
	case HEADER_CG_MYSHOP_OPEN:
		OpenPlayerShop(ch);
		break;
	case HEADER_CG_MYSHOP_CLOSE:
		ClosePlayerShop(ch);
		break;

	case HEADER_CG_MYSHOP_WITHDRAW:
		WithdrawShopStash(ch, reinterpret_cast< const TPacketCGShopWithdraw*>(c_pData));
		break;
	case HEADER_CG_MYSHOP_RENAME:
		RenameShop(ch, (TPacketGCShopRename*)c_pData);
		break;
#endif
