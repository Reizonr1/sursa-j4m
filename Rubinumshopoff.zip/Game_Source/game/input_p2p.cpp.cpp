Arat:
int CInputP2P::Analyze(LPDESC d, BYTE bHeader, const char* c_pData)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CInputP2P::StartShopOffline(LPDESC d, const char * c_pData)
{
	P2P_MANAGER::instance().StartShopOffline(d, (TPacketGGShopStartOffline *)c_pData);
}

void CInputP2P::EndShopOffline(LPDESC d, const char * c_pData)
{
	TPacketGGShopEndOffline * p = (TPacketGGShopEndOffline *)c_pData;
	P2P_MANAGER::instance().EndShopOffline(p->dwPID);
}
#endif

Arat:	case HEADER_GG_CHECK_AWAKENESS:
		IamAwake(d, c_pData);
		break;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case HEADER_GG_SHOP_OFFLINE_START:
		StartShopOffline(d, c_pData);
		break;

	case HEADER_GG_SHOP_OFFLINE_END:
		EndShopOffline(d, c_pData);
		break;
#endif