Arat:
	LPSHOP	CreatePCShop(LPCHARACTER ch, TShopItemTable* pTable, BYTE bItemCount);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	LPSHOP	CreatePCShop(LPCHARACTER ch, LPCHARACTER owner, TShopItemTable * pTable, BYTE bItemCount, std::string sign);
#else
	LPSHOP	CreatePCShop(LPCHARACTER ch, TShopItemTable* pTable, BYTE bItemCount);
#endif