Arat:
		else
		{
			o->SyncQuickslot(QUICKSLOT_TYPE_ITEM, item->GetCell(), 255);
			item->RemoveFromCharacter();
		}
	}

	M2_DESTROY_ITEM(item);
}
�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		else if (item->GetWindow() == SHOP)
		{
			if (LPSHOP shop = o->GetMyShop()) {
				shop->RemoveItemByID(item->GetID());
				item->RemoveFromCharacter();
			}
		}
#endif