Arat:
void CHARACTER_MANAGER::GracefulShutdown()

Bul:
	while (it != m_map_pkPCChr.end())
		(it++)->second->Disconnect("GracefulShutdown");

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	CharacterVectorInteractor cvi;
	if (GetCharactersByRaceNum(30000, cvi))
	{
		for (auto ch : cvi)
		{
			if (ch && ch->IsShop())
				ch->CancelShopOfflineEvent();
		}
	}
#endif

Arat:
	if (0 != ch->GetPlayerID())
	{
		itertype(m_map_pkChrByPID) it = m_map_pkChrByPID.find(ch->GetPlayerID());

		if (m_map_pkChrByPID.end() != it)
		{
			m_map_pkChrByPID.erase(it);
		}
	}

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	//Shops and possible fake character copies (non-PC) hold the player ID as GetPlayerID(), but we should't delete the actual player from here.
	if (ch->GetPlayerID() && ch->IsPC())
    {
        itertype(m_map_pkChrByPID) it = m_map_pkChrByPID.find(ch->GetPlayerID());

        if (m_map_pkChrByPID.end() != it)
        {
            m_map_pkChrByPID.erase(it);
        }
    }
#else
	if (0 != ch->GetPlayerID())
	{
		itertype(m_map_pkChrByPID) it = m_map_pkChrByPID.find(ch->GetPlayerID());

		if (m_map_pkChrByPID.end() != it)
		{
			m_map_pkChrByPID.erase(it);
		}
	}

Arat:
bool CHARACTER_MANAGER::GetCharactersByRaceNum(DWORD dwRaceNum, CharacterVectorInteractor& i)
{
	std::map<DWORD, CHARACTER_SET>::iterator it = m_map_pkChrByRaceNum.find(dwRaceNum);

	if (it == m_map_pkChrByRaceNum.end())
		return false;

	i = it->second;
	return true;
}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
int CHARACTER_MANAGER::CountOfflineShops()
{
	std::map<DWORD, CHARACTER_SET>::iterator it = m_map_pkChrByRaceNum.find(30000);

	if (it == m_map_pkChrByRaceNum.end())
		return 0;

	int count = 0;
	for (const LPCHARACTER ch : it->second)
	{
		if (ch->IsShopOfflineEventRunning())
			++count;
	}

	return count;
}
#endif

En alta ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
LPCHARACTER CHARACTER_MANAGER::SpawnShop(LPCHARACTER ch, std::string shopSign, TShopItemTable* shopItemTable, BYTE itemCount, DWORD startTime /*= 0*/)
{
	//Create the shop character instance (The name's only used for VID CRC generation)
	LPCHARACTER myDetachedShop = CHARACTER_MANAGER::instance().CreateCharacter("shop");
	myDetachedShop->SetShopSign(shopSign);

	//Load the shop npc info and store it
	const CMob * pkMob = CMobManager::instance().Get(30000);
	if (!pkMob) 
	{
		sys_err("Could not load shop npc info when creating shop!");
		return nullptr;
	}
	myDetachedShop->SetProto(pkMob);

	//Register detached Shop as real Shop
	std::string name = ch->GetName();
	myDetachedShop->SetName(name);
	myDetachedShop->MarkAsShop();

	//Block it from randomly moving around.
	//myDetachedShop->SetNoMoveFlag();

	// Link the ghost shop with the owner. Note that while the shop carries
	// the player ID, it will not be possible to find the shop on 
	// CHARACTER_MANAGER's find-by-player-id map.
	myDetachedShop->SetPlayerID(ch->GetPlayerID());

	//Create the shop and bind it
	myDetachedShop->SetMyShop(CShopManager::instance().CreatePCShop(myDetachedShop, ch, shopItemTable, itemCount, shopSign.c_str()));

	/*
	* This shop should be as separated as possible from other shops.
	* To achieve this we are going to create a 20x20 grid around the shop, each grid being a surface of value 1 in the map.
	*
	* The grid will have some initially unavailable positions for the coordinates that can not be walked on.
	* The grid will then be filled with all the shops within that 400 units area (those positions will be unavailable).
	* Finally, a shop position will be picked
	*/
	long curX = ch->GetX();
	long curY = ch->GetY();
	long mapIndex = ch->GetMapIndex();
	int deltaX = 0;
	int deltaY = 0;

	if (!mapIndex)
	{
		sys_log(0, "OpenMyShop: invalid mapindex for char");
		M2_DESTROY_CHARACTER(myDetachedShop);
		return nullptr;
	}

	{
		// Create the grid
		int gridSide = 33;
		assert(gridSide % 2 != 0); //Must be odd!
		CGrid grid(gridSide, gridSide);
		
		int gridToCoordRatio = 70 * 5/2; // One grid cell will equal to a N units area in the world. 70 is the minimum
		int centerPos = (gridSide + 1) / 2 * (gridSide - 1); // Center position of the grid
		int centerPosColumn = grid.GetPosColumn(centerPos);
		int centerPosRow = grid.GetPosRow(centerPos);

		int coordVar = (gridSide - 1) / 2 + 1; // Coordinate variance (considering we are assuming the centerPos is our current position).

		// Inspect terrain
		LPSECTREE tree;
		for (long col = 0; col < gridSide; ++col)
		{
			for (long row = 0; row < gridSide; ++row)
			{
				int x = (col - coordVar)*gridToCoordRatio + curX;
				int y = (row - coordVar)*gridToCoordRatio + curY;
				tree = SECTREE_MANAGER::instance().Get(mapIndex, x, y);
				if (tree->IsAttr(x, y, ATTR_BLOCK | ATTR_OBJECT | ATTR_WATER))
					grid.Put(col + row * gridSide, 1, 1);
			}
		}

		// Add shops to the grid
		CharacterVectorInteractor cvi;
		if (GetCharactersByRaceNum(30000, cvi))
		{
			for (const auto shopChar : cvi)
			{
				if (shopChar->GetPlayerID() == ch->GetPlayerID())
					continue;

				long shopX = shopChar->GetX();
				long shopY = shopChar->GetY();

				// Is shop within our grid?
				if (shopX >= curX - coordVar*gridToCoordRatio && shopX <= curX + coordVar*gridToCoordRatio &&
					shopY >= curY - coordVar*gridToCoordRatio && shopY <= curY + coordVar*gridToCoordRatio)
				{
					int col = (shopX - curX) / gridToCoordRatio + centerPosColumn;
					int row = (shopY - curY) / gridToCoordRatio + centerPosRow;
					
					int pos = col + row * gridSide;
					grid.Put(pos, 1, 1);
				}
			}
		}

		// Grid is created, let's see where we place our new shop.
		bool placed = false;

		// First stick to the position we are at if possible (center position of the grid)
		
		if (grid.IsEmpty(centerPos, 1, 1))
		{
			placed = true;
			grid.Put(centerPos, 1, 1);
		}
		// Otherwise, find a blank position in the grid, closest to the center
		else
		{
			int bestDist = -1;
			int bestPos = -1;

			for (int col = 0; col < gridSide; ++col)
			{
				for (int row = 0; row < gridSide; ++row)
				{
					int pos = row * gridSide + col;
					if (grid.IsEmpty(pos, 1, 1))
					{
						int dist = abs(row - centerPosRow) + abs(col - centerPosColumn);
						if (bestDist < 0 || bestDist > dist)
						{
							bestDist = dist;
							bestPos = pos;
						}
					}
				}
			}
			
			if (bestPos > -1)
			{
				placed = true;
				deltaX = (grid.GetPosColumn(bestPos) - centerPosColumn) * gridToCoordRatio;
				deltaY = (grid.GetPosRow(bestPos) - centerPosRow) * gridToCoordRatio;

				grid.Put(bestPos, 1, 1);
			}
		}

		if (!placed)
			sys_err("Shop #%lu could not placed at coords (%ld, %ld) - Mapindex %ld, channel %d", ch->GetPlayerID(), ch->GetX(), ch->GetY(), ch->GetMapIndex(), g_bChannel);
		else
			sys_log(0, "Shop #%lu placed around (%ld, %ld) with an offset of (%d, %d)", ch->GetPlayerID(), ch->GetX(), ch->GetY(), deltaX, deltaY);
		
		/*if (test_server)
			grid.Print();*/
	}

	//Reposition shop if needed
	if (deltaX != 0 || deltaY != 0)
	{
		PIXEL_POSITION pos = { curX + deltaX, curY + deltaY, 0 };
		ch->SetXYZ(pos);
	}

	TPacketPlayerShopSign p;
	p.header = HEADER_GC_MY_SHOP_SIGN;

	if (!myDetachedShop->Show(ch->GetMapIndex(), ch->GetX(), ch->GetY(), ch->GetZ(), true)) 
	{
		memset(p.sign, 0, sizeof(p.sign)); //Close shop on client
		ch->GetDesc()->Packet(&p, sizeof(TPacketPlayerShopSign));
		sys_log(0, "OpenMyShop: cannot display detached shop");
		M2_DESTROY_CHARACTER(myDetachedShop);
		return nullptr;
	}

	if (ch->IsPC()) 
	{
		//Return to our old position
		PIXEL_POSITION ppos = { curX, curY, 0 };
		ch->SetXYZ(ppos);

		//Set the shop sign for the owner
		strlcpy(p.sign, shopSign.c_str(), sizeof(p.sign));
		ch->GetDesc()->Packet(&p, sizeof(TPacketPlayerShopSign));

		//Broadcast if we are spawning dynamically (not on boot), as only then there will be an actual character.
		TPacketGCShopSign p;
		p.bHeader = HEADER_GC_SHOP_SIGN;
		p.dwVID = myDetachedShop->GetVID();
		strlcpy(p.szSign, shopSign.c_str(), sizeof(p.szSign));
		ch->PacketAround(&p, sizeof(TPacketGCShopSign));

		//Sync position on client
		TPacketGCShopSyncPos pos;
		pos.bHeader = HEADER_GC_SYNC_SHOP_POSITION;
		pos.channel = g_bChannel;
		pos.xGlobal = curX + deltaX;
		pos.yGlobal = curY + deltaY;
		ch->GetDesc()->Packet(&pos, sizeof(TPacketGCShopSyncPos));
	}

	//LPSECTREE_MAP pTargetMap = SECTREE_MANAGER::instance().GetMap(myDetachedShop->GetMapIndex());
	
	//Set the start time
	if (!startTime)
		startTime = std::time(nullptr);

	if (!ch->IsPC())
	{
		// Shop was created on boot & no player is online!
		myDetachedShop->StartShopOfflineEvent();
	}
	else
	{
		//Request syncing of times (offline / premium offline), as we are spawning it *now*
		//and shop may already have some
		DWORD pid = ch->GetPlayerID();
		db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD));
		BYTE subheader = SHOP_SUBHEADER_GD_REQUEST_PREMIUM_TIME_SYNC;
		db_clientdesc->Packet(&subheader, sizeof(BYTE));
		db_clientdesc->Packet(&pid, sizeof(DWORD));

		//Shop is being created by the player. Give it offline time,
		spActivityHandler activity = ch->GetActivityHandler();
		bool isPremium = ch->GetPremiumRemainSeconds(PREMIUM_SHOP_DOUBLE_UP) > 0;
		myDetachedShop->GetMyShop()->SetOfflineMinutes(GetOfflineShopMinutesFromActivity(activity->GetActivity(), isPremium));
	}

	myDetachedShop->GetMyShop()->SetOpenTime(startTime);

	//This is the event that will save the shop in db to recover from crashes.
	myDetachedShop->GetMyShop()->Save();

	return myDetachedShop;
}