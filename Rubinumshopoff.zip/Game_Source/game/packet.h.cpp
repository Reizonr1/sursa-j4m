// De�erleri kendi koydu�unuz s�raya do�ru d�zenleyiniz.

Arat:
	HEADER_CG_SYMBOL_CRC = 113,

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_CG_MYSHOP_REMOVE_ITEM	= 117,
	HEADER_CG_MYSHOP_ADD_ITEM		= 118,
	HEADER_CG_MYSHOP_CLOSE			= 119,
	HEADER_CG_MYSHOP_WITHDRAW		= 120,
	HEADER_CG_MYSHOP_RENAME			= 121,
	HEADER_CG_MYSHOP_OPEN			= 122,
	HEADER_CG_MYSHOP_OPEN_SEARCH	= 123,
#endif

Arat:
	HEADER_GC_PANAMA_PACK = 151,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_GC_PLAYER_SHOP_SET		= 155,
	HEADER_GC_MY_SHOP_SIGN 			= 156,
	HEADER_GC_SYNC_SHOP_STASH 		= 157,
	HEADER_GC_SYNC_SHOP_OFFTIME 	= 158,
	HEADER_GC_SYNC_SHOP_PREMTIME	= 159,
	HEADER_GC_SYNC_SHOP_POSITION 	= 160,
	HEADER_GC_SHOP_POSITION			= 161,
#endif

Arat:	HEADER_GG_CHECK_AWAKENESS = 29,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_GG_SHOP_SALE_INFO		= 31,
	HEADER_GG_SHOP_OFFLINE_START	= 32,
	HEADER_GG_SHOP_OFFLINE_END		= 33,
#endif


Arat:
typedef struct SPacketGGLogout
{
	BYTE	bHeader;
	char	szName[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGGLogout;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct SPacketGGShopStartOffline
{
	BYTE	bHeader;
	DWORD	dwPID;
	BYTE	bEmpire;
	long	lMapIndex;
	BYTE	bChannel;
} TPacketGGShopStartOffline;

typedef struct SPacketGGShopEndOffline
{
	BYTE	bHeader;
	DWORD	dwPID;
} TPacketGGShopEndOffline;
#endif

Arat:
enum
{
	SHOP_SUBHEADER_CG_END,
	SHOP_SUBHEADER_CG_BUY,
	SHOP_SUBHEADER_CG_SELL,
	SHOP_SUBHEADER_CG_SELL2,
};

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct packet_shop_set
{
	BYTE		header;
	BYTE		pos;
	DWORD		vnum;
#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
	WORD		count;
#else
	BYTE		count;
#endif
	unsigned long long		price;
	long		alSockets[ITEM_SOCKET_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_MAX_NUM];
} TPacketPlayerShopSet;

typedef struct packet_shop_sign
{
	BYTE	header;
	char	sign[SHOP_SIGN_MAX_LEN + 1];
} TPacketPlayerShopSign;
#endif

Arat:
	SHOP_SUBHEADER_GC_NOT_ENOUGH_MONEY_EX,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SHOP_SUBHEADER_GC_OPEN_SHOP_EDITOR,
#endif

Arat:
} TPacketGCNPCPosition;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
} TPacketGCNPCPosition, TPacketGCShopPosition;
#else
} TPacketGCNPCPosition;
#endif

Arat:
#pragma pack()

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct myshop_remove
{
	BYTE header;
	int slot;
	TItemPos target;
} TPacketMyShopRemoveItem;

typedef struct myshop_add
{
	BYTE header;
	TItemPos from;
	int targetPos;
	unsigned long long price;
} TPacketMyShopAddItem;

typedef struct shopStashSync
{
	BYTE	bHeader;
	unsigned long long	value;
} TPacketGCShopStashSync;

typedef struct shopOfflineTimeSync
{
	BYTE	bHeader;
	DWORD	value;
} TPacketGCShopOffTimeSync;

typedef struct shopPremiumTimeSync
{
	BYTE	bHeader;
	int	value;
} TPacketGCShopPremiumTimeSync;

typedef struct shopSyncPos
{
	BYTE	bHeader;
	int channel;
	int	xGlobal;
	int yGlobal;
} TPacketGCShopSyncPos;

typedef struct shopRename
{
	BYTE bHeader;
	char sign[SHOP_SIGN_MAX_LEN + 1];
} TPacketGCShopRename;

typedef struct shopWithdraw
{
	uint8_t bHeader;
	uint64_t amount;
} TPacketCGShopWithdraw;
#endif