Arat:
ACMD(do_close_shop)

Tamamen de�i�tir:

ACMD(do_close_shop)
{
#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetMyShop())
	{
		ch->CloseMyShop();
		return;
	}
#endif
}

Uygun alana ekleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
enum eTypeOfAction
{
	OFFLINESHOP_DELETE_FROM_ITEM = 1,
	OFFLINESHOP_DELETE_FROM_SHOP = 2,
};

bool GetExistItems(DWORD pos, DWORD pid) /* Check if exist items in shop */
{
	char szQuery[1024];
	snprintf(szQuery, sizeof(szQuery), "SELECT from player.private_shop_items WHERE pos = %d and pid = %u", pos, pid);
	std::auto_ptr<SQLMsg> pMsg(DBManager::instance().DirectQuery(szQuery));	
	
	return (pMsg->Get()->uiNumRows > 0) ? true : false;
}

void ClearItems(DWORD pos, DWORD pid, int mode) /* Clear items from mysql player.private_shop_items and player.item */
{
	switch(mode)
	{
		case OFFLINESHOP_DELETE_FROM_ITEM:
			DBManager::instance().DirectQuery("DELETE FROM player.item WHERE owner_id = %u and pos = %u and window = 'SHOP'", pid, pos);			
			break;
		case OFFLINESHOP_DELETE_FROM_SHOP:
			DBManager::instance().DirectQuery("DELETE FROM player.private_shop_items WHERE pos = %d and pid = %u", pos, pid);	
			break;
		default:
			break;
	}
}

void RemoveShop(DWORD pid) /* Clear shop by pid */
{
	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD));
	BYTE subheader = SHOP_SUBHEADER_GD_CLOSE_REQUEST;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));
}

ACMD(do_offlineshop_debug)
{
	char arg1[256];
	one_argument(argument, arg1, sizeof(arg1));
	
	if (!strcmp(arg1, "force_stop"))
	{
		if (ch->IsShop())
		{
			ch->ChatPacket(CHAT_TYPE_INFO, "ch->IsShop() == true");
		}
		
		RemoveShop(ch->GetPlayerID());
		ch->CancelShopOfflineEvent();
		ch->CloseShop();	
		ch->SetClearShop();
		
		ch->ChatPacket(CHAT_TYPE_INFO, "CancelShopOfflineEvent | CloseShop | SetClearShop");
	}

	char szQuery[1024];
	snprintf(szQuery, sizeof(szQuery), "SELECT pos,count,vnum,socket0,socket1,socket2,attrtype0,attrvalue0,attrtype1,attrvalue1,attrtype2,attrvalue2,attrtype3,attrvalue3,attrtype4,attrvalue4,attrtype5,attrvalue5,attrtype6,attrvalue6 FROM player.item WHERE owner_id = %u and window = 'SHOP'", ch->GetPlayerID());
	std::auto_ptr<SQLMsg> pMsg(DBManager::instance().DirectQuery(szQuery));
		
	if (pMsg->Get()->uiNumRows == 0)
		return;
		
	MYSQL_ROW row;
	while (NULL != (row = mysql_fetch_row(pMsg->Get()->pSQLResult)))
	{
		TPlayerItem item;

		str_to_number(item.pos, row[0]);
		str_to_number(item.count, row[1]);
		str_to_number(item.vnum, row[2]);
			
		// Set Sockets
		for (int i = 0, n = 3; i < ITEM_SOCKET_MAX_NUM; ++i, n++)
			str_to_number(item.alSockets[i], row[n]);
		// End Of Set Sockets

		// Set Attributes
		for (int i = 0, iStartAttributeType = 6, iStartAttributeValue = 7; i < 7; ++i, iStartAttributeType += 2, iStartAttributeValue += 2)
		{
			str_to_number(item.aAttr[i].bType, row[iStartAttributeType]);
			str_to_number(item.aAttr[i].sValue, row[iStartAttributeValue]);
		}
		// End Of Set Attributes

		LPITEM pItem = ITEM_MANAGER::instance().CreateItem(item.vnum, item.count);

		if (pItem)
		{
			int iEmptyPos = 0;
				
			if (pItem->IsDragonSoul())
				iEmptyPos = ch->GetEmptyDragonSoulInventory(pItem);
			else
				iEmptyPos = ch->GetEmptyInventory(pItem->GetSize());

			if (iEmptyPos < 0)
			{
				ch->ChatPacket(CHAT_TYPE_INFO, "[Rubinum Shop] You do not have enough space in inventory!");
				return;
			}

			// Set attributes and sockets for items
			pItem->SetSockets(item.alSockets);
			pItem->SetAttributes(item.aAttr);
				
			if (pItem->IsDragonSoul())
				pItem->AddToCharacter(ch, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyPos));
			else
				pItem->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyPos));
				
			ch->ChatPacket(CHAT_TYPE_INFO, "[Rubinum Shop] You received [%s] from offlineshop.", pItem->GetName());

			ClearItems(item.pos, ch->GetPlayerID(), OFFLINESHOP_DELETE_FROM_ITEM);
			
			if (GetExistItems(item.pos, ch->GetPlayerID()))
				ClearItems(item.pos, ch->GetPlayerID(), OFFLINESHOP_DELETE_FROM_SHOP);
		}
	}
	
	RemoveShop(ch->GetPlayerID()); // Remove your shop
	DBManager::instance().DirectQuery("DELETE FROM rb_player.private_shop WHERE pid = %u", ch->GetPlayerID());
}
#endif

Arat:
	if (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetExchange() || ch->GetViewingShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())
#else
	if (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())
#endif

Arat:
	if (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetExchange() || ch->GetViewingShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())
#else
	if (ch->GetExchange() || ch->GetMyShop() || ch->GetShopOwner() || ch->IsOpenSafebox() || ch->IsCubeOpen())
#endif