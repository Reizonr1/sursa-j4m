Arat:
ACMD(do_clear_affect);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
ACMD (do_shop_withdraw);
ACMD (do_shop_close);
ACMD (do_shop_moderate);
ACMD (do_offlineshop_debug);
#endif

Arat:
	{ "\n",		NULL,			0,			POS_DEAD,	GM_IMPLEMENTOR	}

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	{ "shop_withdraw", do_shop_withdraw, 0, POS_DEAD, GM_IMPLEMENTOR },
	{ "shop_close", do_shop_close, 0, POS_DEAD, GM_HIGH_WIZARD },
	{ "shop_moderate", do_shop_moderate, 0, POS_DEAD, GM_HIGH_WIZARD },
	{ "offlineshop_debug",	do_offlineshop_debug,	0,	POS_DEAD,	GM_IMPLEMENTOR	},
#endif