Arat:
	db_clientdesc->DBPacketHeader(HEADER_GD_ADD_MONARCH_MONEY, ch->GetDesc()->GetHandle(), sizeof(int) + sizeof(int));

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	db_clientdesc->DBPacketHeader(HEADER_GD_ADD_MONARCH_MONEY, 0, sizeof(int) + sizeof(unsigned long long));
#else
	db_clientdesc->DBPacketHeader(HEADER_GD_ADD_MONARCH_MONEY, ch->GetDesc()->GetHandle(), sizeof(int) + sizeof(int));
#endif