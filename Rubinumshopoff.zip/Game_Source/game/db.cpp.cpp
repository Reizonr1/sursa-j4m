Arat:
				str_to_number(aiPremiumTimes[PREMIUM_GOLD], row[col++]);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
				str_to_number(aiPremiumTimes[PREMIUM_SHOP_DOUBLE_UP], row[col++]);
#endif