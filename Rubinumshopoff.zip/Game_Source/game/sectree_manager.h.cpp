Arat:
typedef std::map<std::string, TAreaInfo> TAreaMap;

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
struct shop_info
{
	DWORD vid;
	char name[CHARACTER_NAME_MAX_LEN + 1];
	long x, y;
};
#endif

Arat:
	std::map<DWORD, std::vector<npc_info> > m_mapNPCPosition;

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	std::map < DWORD, std::vector < shop_info > > m_mapSHOPPosition;
#endif