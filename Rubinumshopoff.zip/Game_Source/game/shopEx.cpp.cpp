Arat:
	if (ch->GetShop())
		return false;

	ch->SetShop(this);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetViewingShop())
		return false;

	ch->SetViewingShop(this);
#else
	if (ch->GetShop())
		return false;

	ch->SetShop(this);
#endif