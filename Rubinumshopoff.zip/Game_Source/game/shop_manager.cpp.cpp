Arat:
	if (pkChr->GetShopOwner() == pkChrShopKeeper)

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (pkChr->GetViewingShopOwner() == pkChrShopKeeper)
#else
	if (pkChr->GetShopOwner() == pkChrShopKeeper)
#endif

Arat:
	pkChr->SetShopOwner(pkChrShopKeeper);

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	pkChr->SetViewingShopOwner(pkChrShopKeeper);
#else
	pkChr->SetShopOwner(pkChrShopKeeper);
#endif

Arat:
LPSHOP CShopManager::CreatePCShop(LPCHARACTER ch, TShopItemTable* pTable, BYTE bItemCount)

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
LPSHOP CShopManager::CreatePCShop(LPCHARACTER ch, LPCHARACTER owner, TShopItemTable * pTable, BYTE bItemCount, std::string sign)
#else
LPSHOP CShopManager::CreatePCShop(LPCHARACTER ch, TShopItemTable* pTable, BYTE bItemCount)
#endif

Arat:

	pkShop->SetShopItems(pTable, bItemCount);

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	pkShop->TransferItems(owner, pTable, bItemCount);
	pkShop->SetShopItems(pTable, bItemCount);
	pkShop->SetShopSign(sign);
#else
	pkShop->SetShopItems(pTable, bItemCount);
#endif

Arat:
	if (!(shop = ch->GetShop()))

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!(shop = ch->GetViewingShop()))
#else
	if (!(shop = ch->GetShop()))
#endif

Arat:
	if (!ch->GetShop())
		return;

	if (!ch->GetShopOwner())
		return;

	if (DISTANCE_APPROX(ch->GetX() - ch->GetShopOwner()->GetX(), ch->GetY() - ch->GetShopOwner()->GetY()) > 2000)

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!ch->GetViewingShop())
		return;

	if (!ch->GetViewingShopOwner())
		return;

	if (DISTANCE_APPROX(ch->GetX() - ch->GetViewingShopOwner()->GetX(), ch->GetY() - ch->GetViewingShopOwner()->GetY()) > 2000)
#else
	if (!ch->GetShop())
		return;

	if (!ch->GetShopOwner())
		return;

	if (DISTANCE_APPROX(ch->GetX() - ch->GetShopOwner()->GetX(), ch->GetY() - ch->GetShopOwner()->GetY()) > 2000)
#endif

Arat:
	CShop* pkShop = ch->GetShop();

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	CShop* pkShop = ch->GetViewingShop();
#else
	CShop* pkShop = ch->GetShop();
#endif

Hemen alt�nda bul:
	if (!pkShop)
		return;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (pkShop->IsClosed())
	{
		sys_err("Player %lu trying to buy from closed shop.", ch->GetPlayerID());
		return;
	}
#endif

Arat:
		ch->GetDesc()->Packet(&pack, sizeof(pack));
	}

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	//If, after buying, the shop is closed, destroy it (through its owner char)
	if (pkShop->IsClosed() && pkShop->IsPCShop())
	{
		M2_DESTROY_CHARACTER(pkShop->GetOwner());
	}
#endif

Arat:
	if (!ch->GetShop())
		return;

	if (!ch->GetShopOwner())
		return;

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!ch->GetViewingShop())
		return;

	if (!ch->GetViewingShopOwner())
		return;
#else
	if (!ch->GetShop())
		return;

	if (!ch->GetShopOwner())
		return;
#endif

Arat:
	if (ch->GetShop()->IsPCShop())
		return;

	if (DISTANCE_APPROX(ch->GetX() - ch->GetShopOwner()->GetX(), ch->GetY() - ch->GetShopOwner()->GetY()) > 2000)

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetViewingShop()->IsPCShop())
		return;

	if (DISTANCE_APPROX(ch->GetX()-ch->GetViewingShopOwner()->GetX(), ch->GetY()-ch->GetViewingShopOwner()->GetY())>2000)
#else
	if (ch->GetShop()->IsPCShop())
		return;

	if (DISTANCE_APPROX(ch->GetX() - ch->GetShopOwner()->GetX(), ch->GetY() - ch->GetShopOwner()->GetY()) > 2000)
#endif

Arat:
	CGrid grid = CGrid(5, 9);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	CGrid grid = CGrid(SHOP_GRID_WIDTH, SHOP_GRID_HEIGHT);
#else
	CGrid grid = CGrid(5, 9);
#endif