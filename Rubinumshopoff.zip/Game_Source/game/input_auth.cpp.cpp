Arat:
			"UNIX_TIMESTAMP(money_drop_rate_expire),"

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			"UNIX_TIMESTAMP(shop_double_up_expire),"
#endif

Arat:
			"UNIX_TIMESTAMP(money_drop_rate_expire),"

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			"UNIX_TIMESTAMP(shop_double_up_expire),"
#endif

Arat:
			"UNIX_TIMESTAMP(money_drop_rate_expire),"

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
			"UNIX_TIMESTAMP(shop_double_up_expire),"
#endif