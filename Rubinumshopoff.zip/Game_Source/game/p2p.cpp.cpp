Arat:
	memset(m_aiEmpireUserCount, 0, sizeof(m_aiEmpireUserCount));

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_map_shopCCI.clear();
#endif

Arat:
void P2P_MANAGER::EraseUserByDesc(LPDESC d)
{
	TCCIMap::iterator it = m_map_pkCCI.begin();

	while (it != m_map_pkCCI.end())
	{
		CCI* pkCCI = it->second;
		it++;

		if (pkCCI->pkDesc == d)
			Logout(pkCCI);
	}
Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	for (const auto it : m_map_shopCCI)
	{
		if (it.second->pkDesc == d)
			EndShopOffline(it.second);
	}
#endif

Arat:
void P2P_MANAGER::Logout(const char* c_pszName)
{
	CCI* pkCCI = Find(c_pszName);

	if (!pkCCI)
		return;

	Logout(pkCCI);
	sys_log(0, "P2P: 

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void P2P_MANAGER::StartShopOffline(LPDESC d, const TPacketGGShopStartOffline * p)
{
	spShopCCI shopCCI = FindShop(p->dwPID);

	if (!shopCCI) //Did not exist previously (this should be what always happens)
	{
		shopCCI = std::shared_ptr<ShopCCI>(new ShopCCI());
		shopCCI->dwPID = p->dwPID;
		shopCCI->bEmpire = p->bEmpire;

		m_map_shopCCI.insert(std::make_pair(shopCCI->dwPID, shopCCI));
	}

	shopCCI->pkDesc = d;
	shopCCI->bChannel = p->bChannel;
	shopCCI->lMapIndex = p->lMapIndex;
	sys_log(0, "P2P: Shop enter offline #%lu", p->dwPID);
}

void P2P_MANAGER::EndShopOffline(DWORD pid)
{
	spShopCCI shopCCI = FindShop(pid);

	if (!shopCCI)
		return;

	EndShopOffline(shopCCI);
	sys_log(0, "P2P: End shop offline %lu", pid);
}

void P2P_MANAGER::EndShopOffline(spShopCCI shopCCI)
{	
	m_map_shopCCI.erase(shopCCI->dwPID);
}
#endif

Arat:int P2P_MANAGER::GetCount()
{
	//return m_map_pkCCI.size();
	return m_aiEmpireUserCount[1] + m_aiEmpireUserCount[2] + m_aiEmpireUserCount[3];
}

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
spShopCCI P2P_MANAGER::FindShop(DWORD pid)
{
	for (const auto it : m_map_shopCCI)
	{
		if (it.first == pid)
			return it.second;
	}

	return nullptr;
}
#endif

En alta ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
int P2P_MANAGER::GetForeignShopCount()
{
	return m_map_shopCCI.size();
}
#endif