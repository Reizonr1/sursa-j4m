Arat:		if (GetWindow() != SAFEBOX && GetWindow() != MALL)

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (GetWindow() != SAFEBOX && GetWindow() != MALL && GetWindow() != SHOP)
#else
		if (GetWindow() != SAFEBOX && GetWindow() != MALL)
#endif

Arat:
		m_pOwner = NULL;
		m_wCell = 0;

		SetWindow(RESERVED_WINDOW);
		Save();
		return (this);
	}
}
�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		else if (GetWindow() == SHOP)
		{
			TItemPos cell(SHOP, m_wCell);
			pOwner->SetItem(cell, NULL);
		}
#endif

Arat:
	else if (DRAGON_SOUL_INVENTORY == window_type)
	{
		if (m_wCell >= DRAGON_SOUL_INVENTORY_MAX_NUM)
		{
			sys_err("CItem::AddToCharacter: cell overflow: %s to %s cell %d", m_pProto->szName, ch->GetName(), m_wCell);
			return false;
		}
	}

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	else if (SHOP == window_type)
	{
		if (m_wCell >= SHOP_INVENTORY_MAX_NUM)
		{
			sys_err("CItem::AddToCharacter: cell overflow: %s to %s cell %d", m_pProto->szName, ch->GetName(), m_wCell);
			return false;
		}
	}
#endif