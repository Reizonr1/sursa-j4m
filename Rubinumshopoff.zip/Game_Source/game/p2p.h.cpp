Arat:
class P2P_MANAGER : public singleton<P2P_MANAGER>

�st�ne ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct _ShopCCI
{
	DWORD	dwPID;
	long	lMapIndex;
	BYTE	bEmpire;
	BYTE	bChannel;
	LPDESC	pkDesc;
} ShopCCI;

typedef std::shared_ptr<ShopCCI> spShopCCI;
#endif

Arat:
	CCI* FindByPID(DWORD pid);

�st�ne ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	spShopCCI FindShop(DWORD pid);
#endif

Arat:
	void			GetP2PHostNames(std::string& hostNames);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void			StartShopOffline(LPDESC d, const TPacketGGShopStartOffline * p);
	void			EndShopOffline(DWORD pid);
	int				GetForeignShopCount();
#endif

Arat:
	void			Logout(CCI* pkCCI);

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void			EndShopOffline(spShopCCI shopCCI);
#endif

Arat:
	typedef boost::unordered_map<DWORD, CCI*> TPIDCCIMap;

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	typedef std::unordered_map<DWORD, spShopCCI> TShopCCIMap;
#endif

Arat:
	TPIDCCIMap		m_map_dwPID_pkCCI;

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	TShopCCIMap		m_map_shopCCI;
#endif

Arat:
	int			m_aiEmpireUserCount[EMPIRE_MAX_NUM];

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	int			m_aiEmpireShopCount[EMPIRE_MAX_NUM];
#endif