Arat:
	bool	Create(DWORD dwVnum, DWORD dwNPCVnum, TShopItemTable* pItemTable);

�st�ne ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	static bool CanOpenShopHere(long mapindex);
#endif

Arat:
	void	SetShopItems(TShopItemTable* pItemTable, BYTE bItemCount);

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void	SetShopItems(TShopItemTable * pItemTable, BYTE bItemCount);
	void	TransferItems(LPCHARACTER owner, TShopItemTable * pTable, BYTE bItemCount);
	void	SetShopItem(TShopItemTable * pItemTable);
	LPCHARACTER GetOwner() { return  m_pkPC;  };
#else
	void	SetShopItems(TShopItemTable* pItemTable, BYTE bItemCount);
#endif

Arat:
	virtual int	Buy(LPCHARACTER ch, BYTE pos, bool isSearchBuy = false);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	bool TransferItemAway(LPCHARACTER ch, BYTE pos, TItemPos targetPos);
	bool RemoveItemByID(DWORD itemID);
#endif

Arat:
	LPCHARACTER	GetPC() { return m_pkPC; }

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	std::string GetShopSign() { return m_sign; }
	void		SetShopSign(std::string sign) { m_sign = sign; }
	void SetClosed(bool status) { m_closed = status; }
	bool IsClosed() const { return m_closed; }

	void SetOpenTime(DWORD time) { m_openTime = time; }
	DWORD GetOpenTime() const { return m_openTime; }

	void SetOfflineMinutes(int mins) { m_offlineMinutes = mins; }
	int GetOfflineMinutes() const { return m_offlineMinutes; }

	void SetPremiumMinutes(int mins) { m_premiumMinutes = mins; }
	int GetPremiumMinutes() const { return m_premiumMinutes;  }

	void SetNextRenamePulse(int pulse) { m_renamePulse = pulse; }
	int	 GetRenamePulse() { return m_renamePulse; }

	void Save();
	void SaveOffline();

	bool	IsEmpty();
	
	std::vector<SHOP_ITEM>	GetItemVector() const { return m_itemVector; }
#endif

Arat:
	void	Broadcast(const void* data, int bytes);

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void	CloseMyShop();
#endif

Arat:
	LPCHARACTER			m_pkPC;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	std::string m_sign;
	bool	m_closed;

	DWORD m_openTime;
	int m_offlineMinutes;
	int m_premiumMinutes;
	int m_renamePulse;
#endif
