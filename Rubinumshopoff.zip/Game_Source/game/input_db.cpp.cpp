Ekle
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
#include "../../common/shop_helper.h"
#endif

Arat:
	if (ch->GetShopOwner() || ch->GetExchange() || ch->GetMyShop() || ch->IsCubeOpen())

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetViewingShopOwner() || ch->GetExchange() || ch->IsCubeOpen() )
#else
	if (ch->GetShopOwner() || ch->GetExchange() || ch->GetMyShop() || ch->IsCubeOpen())
#endif

Arat:
	std::vector<LPITEM> v;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	std::vector<TPlayerItem> shopItems;
#endif

Arat:
	for (DWORD i = 0; i < dwCount; ++i, ++p)
	{

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (p->window == EWindows::SHOP)
		{
			shopItems.push_back(*p);
			continue;
		}
#endif

Arat:
	ch->CheckMaximumPoints();

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	ch->SetShopItems(shopItems);
#endif


Arat:
void CInputDB::AffectLoad(LPDESC d, const char* c_pData)

�st�ne ekle i�eri�ini kendinize g�re d�zenleyiniz:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
/*
* Obtain all the information about the shop (items, name, gold, times and position),
* cache gold locally and send everything to the client.
*/
void CInputDB::MyShopInfoLoad(LPDESC d, const char * c_pData)
{
	LPCHARACTER ch;

	if (!d || !(ch = d->GetCharacter()))
		return;

	//Amount of items in the shop
	BYTE bCount = decode_byte(c_pData);
	c_pData += sizeof(BYTE);

	//Shop sign
	TPacketPlayerShopSign namePack;
	namePack.header = HEADER_GC_MY_SHOP_SIGN;
	strlcpy(namePack.sign, c_pData, sizeof(namePack.sign));
	ch->GetDesc()->Packet(&namePack, sizeof(TPacketPlayerShopSign));
	c_pData += sizeof(namePack.sign);

	//Gold stash in the shop
	unsigned long long goldStash = (unsigned long long)decode_8bytes(c_pData);
	c_pData += sizeof(unsigned long long);

	//Premium Time on our shop
	int premiumTime = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	//Channel where our shop is at
	int channel = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	//X-Cord of our shop
	int x = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	//Y-Cord of our shop
	int y = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	//Load shop items
	if (bCount > 0)
	{
		std::vector<TPlayerItem> shopItems = ch->GetShopItems();
		if (shopItems.empty())
		{
			sys_err("Trying to load myshop items without having loaded items! (%d items on shop)", bCount);
			c_pData += sizeof(TMyShopPriceInfo) * bCount;
			return;
		}

		if (bCount > SHOP_HOST_ITEM_MAX_NUM)
		{
			sys_err("MyShopItemLoad: Cannot load %d items (Over the max)", bCount);
			c_pData += sizeof(TMyShopPriceInfo) * bCount;
			return;
		}

		TMyShopPriceInfo * p = (TMyShopPriceInfo *)c_pData;

		std::array <TMyShopPriceInfo, SHOP_HOST_ITEM_MAX_NUM> info;
		for (BYTE i = 0; i < bCount; ++i, ++p) {
			info[p->pos] = *p;
		}

		for (const auto item : shopItems)
		{
			if (info[item.pos].price == 0)
			{
				sys_err("Position %d has no price when loading items for shop inventory of #%lu", item.pos, ch->GetPlayerID());
				continue;
			}

			TPacketPlayerShopSet pack;
			pack.header = HEADER_GC_PLAYER_SHOP_SET;
			pack.pos = (BYTE)item.pos;

#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
			pack.count = (WORD)item.count;
#else
			pack.count = (BYTE)item.count;
#endif
			pack.vnum = item.vnum;
			pack.price = info[item.pos].price;

			thecore_memcpy(pack.alSockets, item.alSockets, sizeof(pack.alSockets));
			thecore_memcpy(pack.aAttr, item.aAttr, sizeof(pack.aAttr));

			ch->GetDesc()->Packet(&pack, sizeof(TPacketPlayerShopSet));
		}
	}

	//Set the gold and premium time our shop has
	ch->AlterShopGoldStash(goldStash);
	ch->AlterShopPremiumTime(-ch->GetShopPremiumTime() + premiumTime);

	//Sync gold stash on client
	TPacketGCShopStashSync stash;
	stash.bHeader = HEADER_GC_SYNC_SHOP_STASH;
	stash.value = goldStash;
	ch->GetDesc()->Packet(&stash, sizeof(TPacketGCShopStashSync));

	//Sync premium time on client
	/*TPacketGCShopPremiumTimeSync premTime;
	premTime.bHeader = HEADER_GC_SYNC_SHOP_PREMTIME;
	premTime.value = premiumTime;
	ch->GetDesc()->Packet(&premTime, sizeof(TPacketGCShopPremiumTimeSync));
	*/
	//Sync position on client
	TPacketGCShopSyncPos pos;
	pos.bHeader = HEADER_GC_SYNC_SHOP_POSITION;
	pos.channel = channel;
	pos.xGlobal = x;
	pos.yGlobal = y;
	ch->GetDesc()->Packet(&pos, sizeof(TPacketGCShopSyncPos));

	//If player has been disconnected for over an hour, and they have gold in
	//the shop stash, remember them so!
	if (ch->GetLogOffInterval() > 3600 && goldStash > 0) {
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("YOU_HAVE_%s_GOLD_WAITING_WITHDRAW_SHOP"), pretty_number(goldStash).c_str());
	}
}

void CInputDB::MyShopPremiumTimeUpdate(const char * c_pData)
{
	DWORD pid = decode_4bytes(c_pData);
	c_pData += sizeof(DWORD);

	int newPremiumMinutes = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	LPCHARACTER shopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(pid);
	if (!shopChar)
		return;

	shopChar->GetMyShop()->SetPremiumMinutes(newPremiumMinutes);
}

void CInputDB::CloseShop(const char * c_pData)
{
	DWORD pid = decode_4bytes(c_pData);
	c_pData += sizeof(DWORD);

	LPCHARACTER shopChar = CHARACTER_MANAGER::instance().FindPCShopCharacterByPID(pid);
	if (!shopChar)
		return;

	M2_DESTROY_CHARACTER(shopChar);
}
#endif

Arat:
int CInputDB::Analyze(LPDESC d, BYTE bHeader, const char* c_pData)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CInputDB::ReceiveShopSaleInfo(const char * c_pData)
{
	DWORD pid = *(DWORD*)c_pData;
	c_pData += sizeof(DWORD);

	TPacketShopSaleResult* p = (TPacketShopSaleResult*)c_pData;
	c_pData += sizeof(TPacketShopSaleResult);

	//The princess is not in this castle
	LPCHARACTER ch = CHARACTER_MANAGER::instance().FindByPID(pid);
	if (!ch)
	{
		sys_err("Character by pid %lu could not be delivered a shop sale info", pid);
		return;
	}

	ch->ShopSellResult(p->itemVnum, p->amount, p->gold, p->pos);
}

/*
* Receive information about one or more shops and spawn them.
*
* This function will only do something if there's no shop spawned already in the core
* associated with the given PID.
*
* A fake CHARACTER instance is created and destroyed to allow better code reuse in
* other parts of the source.
*/
void CInputDB::SpawnPlayerShops(const char* c_pData)
{
	//Fetch how many shops to spawn and then loop until all are.
	int spawnAmount = decode_4bytes(c_pData);
	c_pData += sizeof(int);

	//Create a fake char
	LPCHARACTER fake = CHARACTER_MANAGER::instance().CreateCharacter("fake");
	
	//Initialize
	LPITEM item;

	struct ReadShopTable: TPlayerShopTable {
		int offlineMinutes;
		int premiumMinutes;
	};

	ReadShopTable* p = (ReadShopTable*)c_pData;

	for (int i = 0; i < spawnAmount; ++i, ++p)
	{		
		if (CHARACTER_MANAGER::Instance().FindPCShopCharacterByPID(p->pid)) //Shop already exists
			continue;

		std::string positionList = "";
		for (int i = 0; i < SHOP_HOST_ITEM_MAX_NUM; ++i)
		{
			if (p->items[i].vnum == 0)
				continue;

			if (positionList != "")
				positionList += ", ";

			positionList += std::to_string(p->items[i].display_pos);
		}

		if (positionList.empty())
		{
			sys_err("Empty position list (empty item table?) for pid %lu", p->pid);
			continue;
		}

		fake->SetName(p->playerName);

		//Set the char's position
		PIXEL_POSITION pos = { p->x, p->y, 0 };
		long mapIndex = SECTREE_MANAGER::instance().GetMapIndex(p->x, p->y);

		fake->SetXYZ(pos);
		fake->SetMapIndex(mapIndex);

		//Set the PID (always after creating it so that it doesn't get into the real character PID lists)
		fake->SetPlayerID(p->pid);

		//Load the items (synchronously)
		//TODO/OPTIMIZE: Possible optimization if items are loaded someplace else/asynchronously.
		char queryStr[QUERY_MAX_LEN];
		snprintf(queryStr, sizeof(queryStr),
			"SELECT id,window+0,pos,count,vnum,socket0,socket1,socket2,attrtype0,attrvalue0,attrtype1,attrvalue1,attrtype2,attrvalue2,attrtype3,attrvalue3,attrtype4,attrvalue4,attrtype5,attrvalue5,attrtype6,attrvalue6 "
			"FROM item WHERE owner_id=%d AND window = %d AND pos IN (%s)",
			p->pid, SHOP, positionList.c_str());

		std::unique_ptr<SQLMsg> upMsg(DBManager::instance().DirectQuery(queryStr));
		SQLResult* res = upMsg->Get();

		if (!res || res->uiNumRows < 1)
		{
			sys_err("Query yielded no results! %s", queryStr);
			continue;
		}

		if (res->uiNumRows > 255) 
		{
			sys_err("Max number of shop items exceeded.");
			continue;
		}

		std::vector<TPlayerItem> itemVec;
		itemVec.resize((unsigned int)res->uiNumRows);

		BYTE count = 0;
		for (size_t k = 0; k < res->uiNumRows; ++k)
		{
			MYSQL_ROW row = mysql_fetch_row(upMsg->Get()->pSQLResult);

			//Store the data
			TPlayerItem & info = itemVec.at(k);

			int cur = 0;
			str_to_number(info.id, row[cur++]);
			str_to_number(info.window, row[cur++]);
			str_to_number(info.pos, row[cur++]);
			str_to_number(info.count, row[cur++]);
			str_to_number(info.vnum, row[cur++]);
			str_to_number(info.alSockets[0], row[cur++]);
			str_to_number(info.alSockets[1], row[cur++]);
			str_to_number(info.alSockets[2], row[cur++]);

			for (int j = 0; j < ITEM_ATTRIBUTE_MAX_NUM; j++)
			{
				str_to_number(info.aAttr[j].bType, row[cur++]);
				str_to_number(info.aAttr[j].sValue, row[cur++]);
			}

			info.owner = p->pid;

			//Sanity check
			if (info.window != SHOP)
			{
				sys_err("Not shop window while loading shop item %lu!", info.id);
				continue;
			}

			//Create the item
			item = ITEM_MANAGER::Instance().CreateItem(info.vnum, info.count, info.id);

			if (!item)
			{
				sys_err("cannot create shop item by vnum %u (pid %lu id %u)", info.vnum, p->pid, info.id);
				continue;
			}

			item->SetSkipSave(true);
			item->SetSockets(info.alSockets);
			item->SetAttributes(info.aAttr);
			item->AddToCharacter(fake, TItemPos(info.window, info.pos));
			item->SetSkipSave(false);

			++count;
		}

		if (count < 1) 
		{
			sys_err("Boot SpawnPlayerShop: Shop %s (pid #%lu) had no items / an error!", p->shopName, p->pid);
			continue;
		}

		//Finally, spawn the shop if there are any items in it
		LPCHARACTER shopChar = CHARACTER_MANAGER::instance().SpawnShop(fake, p->shopName, p->items, count, p->openTime);

		if (shopChar && shopChar->GetMyShop())
		{
			shopChar->GetMyShop()->SetOfflineMinutes(p->offlineMinutes);
			shopChar->GetMyShop()->SetPremiumMinutes(p->premiumMinutes);
		}
	}

	M2_DESTROY_CHARACTER(fake);
}

/*
* Start a 5 minutes timer after which the shop will start to consume offline time.
* Before doing so, a check against P2P logins is ran to prevent a slow packet from
* interfering with normal functioning.
*/
void CInputDB::SpinPlayerShopTimer(const char* c_pData)
{
	DWORD pid = *(DWORD*)c_pData;
	c_pData += sizeof(DWORD);

	int offMinutes = *(int*)c_pData;
	c_pData += sizeof(int);

	int premMinutes = *(int*)c_pData;
	c_pData += sizeof(int);

	if (P2P_MANAGER::Instance().FindByPID(pid)) // We found the player in p2p, packet probably delayed!
		return;

	LPCHARACTER owner = CHARACTER_MANAGER::Instance().FindPCShopCharacterByPID(pid);
	if (!owner)
	{
		sys_err("No shop to spin timer on (PID %lu)", pid);
		return;
	}

	//Set offline minutes based on the activity value sent by DB
	if (!owner->GetMyShop())
		return;

	owner->GetMyShop()->SetOfflineMinutes(offMinutes);
	owner->GetMyShop()->SetPremiumMinutes(premMinutes);
	owner->StartShopOfflineEvent();
}

/*
* Cancels the shop timer in the event that there is one running
*/
void CInputDB::StopPlayerShopTimer(const char* c_pData)
{
	DWORD pid = *(DWORD*)c_pData;
	c_pData += sizeof(DWORD);

	LPCHARACTER owner = CHARACTER_MANAGER::Instance().FindPCShopCharacterByPID(pid);
	if (!owner)
	{
		sys_err("No shop to stop for (PID %lu)", pid);
		return;
	}

	if (!owner->GetMyShop())
		return;

	owner->CancelShopOfflineEvent();
}

void CInputDB::WithdrawGoldResult(LPDESC desc, TPacketGoldWithdrawResult* p)
{
	LPCHARACTER ch = desc ? desc->GetCharacter() : nullptr;

	if (!desc || !ch) {

		sys_err("Desc%s gold: %llu, pid: %lu", !desc ? " did not exist" : "->GetCharacter() was nullptr", p->goldAmount, p->shopPid);

		if (p->success)
		{
			sys_log(0, "Bouncing rollback for shop withdraw transaction worth %llu gold on shop %lu back to db",p->goldAmount, p->shopPid);

			db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(uint64_t));
			BYTE subheader = SHOP_SUBHEADER_GD_WITHDRAW_ROLLBACK;
			db_clientdesc->Packet(&subheader, sizeof(BYTE));
			db_clientdesc->Packet(&p->shopPid, sizeof(DWORD));
			db_clientdesc->Packet(&p->goldAmount, sizeof(uint64_t));
		}

		return;
	}

	if (!p->success)
	{
		// Gold removal did not go right
		sys_err("Unknown error withdrawing an amount of %lu gold for #%lu", p->goldAmount, ch->GetPlayerID());
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("UNKNOWN_ERROR_WITHDRAWING_GOLD_FROM_SHOP"));
	}
	else
	{
		//All worked fine. Increase player's gold (reduce the gold stash) + tell them
		ch->AlterShopGoldStash(-p->goldAmount);
		ch->PointChange(POINT_GOLD, p->goldAmount);


		//Sync gold stash on client
		TPacketGCShopStashSync stash;
		stash.bHeader = HEADER_GC_SYNC_SHOP_STASH;
		stash.value = ch->GetShopGoldStash();
		ch->GetDesc()->Packet(&stash, sizeof(TPacketGCShopStashSync));

		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("%s_GOLD_WITHDRAWN_FROM_SHOP"), pretty_number(p->goldAmount).c_str());
	}
}

void CInputDB::MyShopClose(const char * c_pData)
{
	DWORD pid = *(DWORD*)c_pData;
	c_pData += sizeof(DWORD);

	bool isDeleteShop = *(bool*)c_pData;
	c_pData += sizeof(bool);

	LPCHARACTER shopChar = CHARACTER_MANAGER::Instance().FindPCShopCharacterByPID(pid);
	if (!shopChar)
		return;

	LPSHOP shop = shopChar->GetMyShop();
	if (shop)
	{
		if (!isDeleteShop)
		{
			shop->SetClosed(true);
			if (shopChar->IsShopOfflineEventRunning())
				shop->SaveOffline();
			shop->Save();
		}
		else
		{
			//We are deleting - avoid flushes
			shopChar->SetShopOfflineEventRunning(false);
		}

		M2_DESTROY_CHARACTER(shopChar);
	}
}

void CInputDB::UpdateMyShopName(const char * c_pData)
{
	DWORD pid = *(DWORD*)c_pData;
	c_pData += sizeof(DWORD);

	char shopName[SHOP_SIGN_MAX_LEN + 1];
	strlcpy(shopName, c_pData, sizeof(shopName));
	c_pData += sizeof(shopName);

	LPCHARACTER shopChar = CHARACTER_MANAGER::Instance().FindPCShopCharacterByPID(pid);
	if (!shopChar)
		return;

	shopChar->SetShopSign(shopName);
	shopChar->GetMyShop()->SetShopSign(shopName);
	shopChar->GetMyShop()->SetNextRenamePulse(thecore_pulse() + PASSES_PER_SEC(60*60));

	TPacketGCShopSign p;
	p.bHeader = HEADER_GC_SHOP_SIGN;
	p.dwVID = shopChar->GetVID();
	strlcpy(p.szSign, shopName, sizeof(p.szSign));
	shopChar->PacketAround(&p, sizeof(TPacketGCShopSign));

	LPCHARACTER owner = CHARACTER_MANAGER::Instance().FindByPID(pid); // Try on the fly update if possible
	if (!owner)
		return;

	LPDESC d = owner->GetDesc();
	if (!d)
		return;

	TPacketPlayerShopSign namePack;
	namePack.header = HEADER_GC_MY_SHOP_SIGN;
	strlcpy(namePack.sign, shopName, sizeof(namePack.sign));
	
	d->Packet(&namePack, sizeof(TPacketPlayerShopSign));
}
#endif


Arat:
	default:
		return (-1);
	}

	return 0;
}
�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	case HEADER_DG_SHOP_MYINFO_LOAD:
		MyShopInfoLoad(DESC_MANAGER::instance().FindByHandle(m_dwHandle), c_pData);
		break;

	case HEADER_DG_SHOP_SALE_INFO:
		ReceiveShopSaleInfo(c_pData);
		break;

	case HEADER_DG_PLAYER_SPAWN_SHOP:
		SpawnPlayerShops(c_pData);
		break;

	case HEADER_DG_SHOP_TIMER:
		SpinPlayerShopTimer(c_pData);
		break;

	case HEADER_DG_SHOP_STOP_OFFLINE:
		StopPlayerShopTimer(c_pData);
		break;

	case HEADER_DG_SHOP_WITHDRAW_RESULT:
		WithdrawGoldResult(DESC_MANAGER::instance().FindByHandle(m_dwHandle), (TPacketGoldWithdrawResult*)c_pData);
		break;

	case HEADER_DG_SHOP_PREMIUM_TIME_UPDATE:
		MyShopPremiumTimeUpdate(c_pData);
		break;

	case HEADER_DG_SHOP_CLOSE:
		MyShopClose(c_pData);
		break;

	case HEADER_DG_SHOP_UPDATE_NAME:
		UpdateMyShopName(c_pData);
		break;
#endif