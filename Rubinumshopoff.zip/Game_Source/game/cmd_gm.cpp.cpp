Arat:
		if (!m_bAll && iDist >= 1000)
			return;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (pkChr->IsShop()) //We dont want to purge shops
			return;
#endif

Arat:
	if (ch->GetShop())
		strlcat(buf, ", Shop", sizeof(buf));

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (tch->GetViewingShop())
		strlcat(buf, ", Shop", sizeof(buf));
#else
	if (ch->GetShop())
		strlcat(buf, ", Shop", sizeof(buf));
#endif

Arat:
	ch->ChatPacket(CHAT_TYPE_INFO, "LEV %d", tch->GetLevel());
	ch->ChatPacket(CHAT_TYPE_INFO, "HP %d/%d", tch->GetHP(), tch->GetMaxHP());
	ch->ChatPacket(CHAT_TYPE_INFO, "SP %d/%d", tch->GetSP(), tch->GetMaxSP());

Bunlar�n buldu�u blo�u kendinize g�re d�zenleyerek de�i�tirin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (!tch->IsShop())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "LEV %d", tch->GetLevel());
		ch->ChatPacket(CHAT_TYPE_INFO, "HP %d/%d", tch->GetHP(), tch->GetMaxHP());
		ch->ChatPacket(CHAT_TYPE_INFO, "SP %d/%d", tch->GetSP(), tch->GetMaxSP());
		ch->ChatPacket(CHAT_TYPE_INFO, "ATT %d MAGIC_ATT %d SPD %d CRIT %d%% PENE %d%% ATT_BONUS %d%%",
			tch->GetPoint(POINT_ATT_GRADE),
			tch->GetPoint(POINT_MAGIC_ATT_GRADE),
			tch->GetPoint(POINT_ATT_SPEED),
			tch->GetPoint(POINT_CRITICAL_PCT),
			tch->GetPoint(POINT_PENETRATE_PCT),
			tch->GetPoint(POINT_ATT_BONUS));
		ch->ChatPacket(CHAT_TYPE_INFO, "DEF %d MAGIC_DEF %d BLOCK %d%% DODGE %d%% DEF_BONUS %d%%",
			tch->GetPoint(POINT_DEF_GRADE),
			tch->GetPoint(POINT_MAGIC_DEF_GRADE),
			tch->GetPoint(POINT_BLOCK),
			tch->GetPoint(POINT_DODGE),
			tch->GetPoint(POINT_DEF_BONUS));
		ch->ChatPacket(CHAT_TYPE_INFO, "RESISTANCES:");
		ch->ChatPacket(CHAT_TYPE_INFO, "   WARR:%3d%% ASAS:%3d%% SURA:%3d%% SHAM:%3d%%"
	#ifdef ENABLE_WOLFMAN_CHARACTER
			" WOLF:%3d%%"
	#endif
			,
			tch->GetPoint(POINT_RESIST_WARRIOR),
			tch->GetPoint(POINT_RESIST_ASSASSIN),
			tch->GetPoint(POINT_RESIST_SURA),
			tch->GetPoint(POINT_RESIST_SHAMAN)
	#ifdef ENABLE_WOLFMAN_CHARACTER
			, tch->GetPoint(POINT_RESIST_WOLFMAN)
	#endif
		);
		ch->ChatPacket(CHAT_TYPE_INFO, "   SWORD:%3d%% THSWORD:%3d%% DAGGER:%3d%% BELL:%3d%% FAN:%3d%% BOW:%3d%%"
	#ifdef ENABLE_WOLFMAN_CHARACTER
			" CLAW:%3d%%"
	#endif
			,
			tch->GetPoint(POINT_RESIST_SWORD),
			tch->GetPoint(POINT_RESIST_TWOHAND),
			tch->GetPoint(POINT_RESIST_DAGGER),
			tch->GetPoint(POINT_RESIST_BELL),
			tch->GetPoint(POINT_RESIST_FAN),
			tch->GetPoint(POINT_RESIST_BOW)
	#ifdef ENABLE_WOLFMAN_CHARACTER
			, tch->GetPoint(POINT_RESIST_CLAW)
	#endif
		);
		ch->ChatPacket(CHAT_TYPE_INFO, "   FIRE:%3d%% ELEC:%3d%% MAGIC:%3d%% WIND:%3d%% CRIT:%3d%% PENE:%3d%%",
			tch->GetPoint(POINT_RESIST_FIRE),
			tch->GetPoint(POINT_RESIST_ELEC),
			tch->GetPoint(POINT_RESIST_MAGIC),
			tch->GetPoint(POINT_RESIST_WIND),
			tch->GetPoint(POINT_RESIST_CRITICAL),
			tch->GetPoint(POINT_RESIST_PENETRATE));
		ch->ChatPacket(CHAT_TYPE_INFO, "   ICE:%3d%% EARTH:%3d%% DARK:%3d%%",
			tch->GetPoint(POINT_RESIST_ICE),
			tch->GetPoint(POINT_RESIST_EARTH),
			tch->GetPoint(POINT_RESIST_DARK));

	#ifdef ENABLE_MAGIC_REDUCTION_SYSTEM
		ch->ChatPacket(CHAT_TYPE_INFO, "   MAGICREDUCT:%3d%%", tch->GetPoint(POINT_RESIST_MAGIC_REDUCTION));
	#endif

		ch->ChatPacket(CHAT_TYPE_INFO, "MALL:");
		ch->ChatPacket(CHAT_TYPE_INFO, "   ATT:%3d%% DEF:%3d%% EXP:%3d%% ITEMx%d GOLDx%d",
			tch->GetPoint(POINT_MALL_ATTBONUS),
			tch->GetPoint(POINT_MALL_DEFBONUS),
			tch->GetPoint(POINT_MALL_EXPBONUS),
			tch->GetPoint(POINT_MALL_ITEMBONUS) / 10,
			tch->GetPoint(POINT_MALL_GOLDBONUS) / 10);

		ch->ChatPacket(CHAT_TYPE_INFO, "BONUS:");
		ch->ChatPacket(CHAT_TYPE_INFO, "   SKILL:%3d%% NORMAL:%3d%% SKILL_DEF:%3d%% NORMAL_DEF:%3d%%",
			tch->GetPoint(POINT_SKILL_DAMAGE_BONUS),
			tch->GetPoint(POINT_NORMAL_HIT_DAMAGE_BONUS),
			tch->GetPoint(POINT_SKILL_DEFEND_BONUS),
			tch->GetPoint(POINT_NORMAL_HIT_DEFEND_BONUS));

		ch->ChatPacket(CHAT_TYPE_INFO, "   HUMAN:%3d%% ANIMAL:%3d%% ORC:%3d%% MILGYO:%3d%% UNDEAD:%3d%%",
			tch->GetPoint(POINT_ATTBONUS_HUMAN),
			tch->GetPoint(POINT_ATTBONUS_ANIMAL),
			tch->GetPoint(POINT_ATTBONUS_ORC),
			tch->GetPoint(POINT_ATTBONUS_MILGYO),
			tch->GetPoint(POINT_ATTBONUS_UNDEAD));

		ch->ChatPacket(CHAT_TYPE_INFO, "   DEVIL:%3d%% INSECT:%3d%% FIRE:%3d%% ICE:%3d%% DESERT:%3d%%",
			tch->GetPoint(POINT_ATTBONUS_DEVIL),
			tch->GetPoint(POINT_ATTBONUS_INSECT),
			tch->GetPoint(POINT_ATTBONUS_FIRE),
			tch->GetPoint(POINT_ATTBONUS_ICE),
			tch->GetPoint(POINT_ATTBONUS_DESERT));

		ch->ChatPacket(CHAT_TYPE_INFO, "   TREE:%3d%% MONSTER:%3d%%",
			tch->GetPoint(POINT_ATTBONUS_TREE),
			tch->GetPoint(POINT_ATTBONUS_MONSTER));

		ch->ChatPacket(CHAT_TYPE_INFO, "   WARR:%3d%% ASAS:%3d%% SURA:%3d%% SHAM:%3d%%"
	#ifdef ENABLE_WOLFMAN_CHARACTER
			" WOLF:%3d%%"
	#endif
			,
			tch->GetPoint(POINT_ATTBONUS_WARRIOR),
			tch->GetPoint(POINT_ATTBONUS_ASSASSIN),
			tch->GetPoint(POINT_ATTBONUS_SURA),
			tch->GetPoint(POINT_ATTBONUS_SHAMAN)
	#ifdef ENABLE_WOLFMAN_CHARACTER
			, tch->GetPoint(POINT_ATTBONUS_WOLFMAN)
	#endif
		);
		ch->ChatPacket(CHAT_TYPE_INFO, "IMMUNE:");
		ch->ChatPacket(CHAT_TYPE_INFO, "   STUN:%d SLOW:%d FALL:%d",
			tch->GetPoint(POINT_IMMUNE_STUN),
			tch->GetPoint(POINT_IMMUNE_SLOW),
			tch->GetPoint(POINT_IMMUNE_FALL));
	}
	else
	{
		LPSHOP targetShop = tch->GetMyShop();
		if (!targetShop)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, "Target is a shop with no shop instance (!?)");
		}
		else
		{
			ch->ChatPacket(CHAT_TYPE_INFO, "Shop name: %s", targetShop->GetShopSign().c_str());
			ch->ChatPacket(CHAT_TYPE_INFO, "Is offline counting: %s", tch->IsShopOfflineEventRunning() ? "Yes" : "No");
			if (tch->IsShopOfflineEventRunning())
			{
				ch->ChatPacket(CHAT_TYPE_INFO, "Free offline minutes: %d", targetShop->GetOfflineMinutes());
				ch->ChatPacket(CHAT_TYPE_INFO, "Premium off minutes: %d", targetShop->GetPremiumMinutes());
			}

			ch->ChatPacket(CHAT_TYPE_INFO, "Shop items:");
			const auto &vector = targetShop->GetItemVector();
			for (const auto shop_item : vector)
			{
				if (!shop_item.pkItem)
					continue;

				ch->ChatPacket(CHAT_TYPE_INFO, "    [%d] #%lu, %dx %s for %llu Yang", shop_item.pkItem->GetCell(), shop_item.itemid, shop_item.count, shop_item.pkItem->GetName(), shop_item.price);
			}
		}
	}
#else
	ch->ChatPacket(CHAT_TYPE_INFO, "LEV %d", tch->GetLevel());
	ch->ChatPacket(CHAT_TYPE_INFO, "HP %d/%d", tch->GetHP(), tch->GetMaxHP());
	ch->ChatPacket(CHAT_TYPE_INFO, "SP %d/%d", tch->GetSP(), tch->GetMaxSP());
	ch->ChatPacket(CHAT_TYPE_INFO, "ATT %d MAGIC_ATT %d SPD %d CRIT %d%% PENE %d%% ATT_BONUS %d%%",
		tch->GetPoint(POINT_ATT_GRADE),
		tch->GetPoint(POINT_MAGIC_ATT_GRADE),
		tch->GetPoint(POINT_ATT_SPEED),
		tch->GetPoint(POINT_CRITICAL_PCT),
		tch->GetPoint(POINT_PENETRATE_PCT),
		tch->GetPoint(POINT_ATT_BONUS));
	ch->ChatPacket(CHAT_TYPE_INFO, "DEF %d MAGIC_DEF %d BLOCK %d%% DODGE %d%% DEF_BONUS %d%%",
		tch->GetPoint(POINT_DEF_GRADE),
		tch->GetPoint(POINT_MAGIC_DEF_GRADE),
		tch->GetPoint(POINT_BLOCK),
		tch->GetPoint(POINT_DODGE),
		tch->GetPoint(POINT_DEF_BONUS));
	ch->ChatPacket(CHAT_TYPE_INFO, "RESISTANCES:");
	ch->ChatPacket(CHAT_TYPE_INFO, "   WARR:%3d%% ASAS:%3d%% SURA:%3d%% SHAM:%3d%%"
#ifdef ENABLE_WOLFMAN_CHARACTER
		" WOLF:%3d%%"
#endif
		,
		tch->GetPoint(POINT_RESIST_WARRIOR),
		tch->GetPoint(POINT_RESIST_ASSASSIN),
		tch->GetPoint(POINT_RESIST_SURA),
		tch->GetPoint(POINT_RESIST_SHAMAN)
#ifdef ENABLE_WOLFMAN_CHARACTER
		, tch->GetPoint(POINT_RESIST_WOLFMAN)
#endif
	);
	ch->ChatPacket(CHAT_TYPE_INFO, "   SWORD:%3d%% THSWORD:%3d%% DAGGER:%3d%% BELL:%3d%% FAN:%3d%% BOW:%3d%%"
#ifdef ENABLE_WOLFMAN_CHARACTER
		" CLAW:%3d%%"
#endif
		,
		tch->GetPoint(POINT_RESIST_SWORD),
		tch->GetPoint(POINT_RESIST_TWOHAND),
		tch->GetPoint(POINT_RESIST_DAGGER),
		tch->GetPoint(POINT_RESIST_BELL),
		tch->GetPoint(POINT_RESIST_FAN),
		tch->GetPoint(POINT_RESIST_BOW)
#ifdef ENABLE_WOLFMAN_CHARACTER
		, tch->GetPoint(POINT_RESIST_CLAW)
#endif
	);
	ch->ChatPacket(CHAT_TYPE_INFO, "   FIRE:%3d%% ELEC:%3d%% MAGIC:%3d%% WIND:%3d%% CRIT:%3d%% PENE:%3d%%",
		tch->GetPoint(POINT_RESIST_FIRE),
		tch->GetPoint(POINT_RESIST_ELEC),
		tch->GetPoint(POINT_RESIST_MAGIC),
		tch->GetPoint(POINT_RESIST_WIND),
		tch->GetPoint(POINT_RESIST_CRITICAL),
		tch->GetPoint(POINT_RESIST_PENETRATE));
	ch->ChatPacket(CHAT_TYPE_INFO, "   ICE:%3d%% EARTH:%3d%% DARK:%3d%%",
		tch->GetPoint(POINT_RESIST_ICE),
		tch->GetPoint(POINT_RESIST_EARTH),
		tch->GetPoint(POINT_RESIST_DARK));

#ifdef ENABLE_MAGIC_REDUCTION_SYSTEM
	ch->ChatPacket(CHAT_TYPE_INFO, "   MAGICREDUCT:%3d%%", tch->GetPoint(POINT_RESIST_MAGIC_REDUCTION));
#endif

	ch->ChatPacket(CHAT_TYPE_INFO, "MALL:");
	ch->ChatPacket(CHAT_TYPE_INFO, "   ATT:%3d%% DEF:%3d%% EXP:%3d%% ITEMx%d GOLDx%d",
		tch->GetPoint(POINT_MALL_ATTBONUS),
		tch->GetPoint(POINT_MALL_DEFBONUS),
		tch->GetPoint(POINT_MALL_EXPBONUS),
		tch->GetPoint(POINT_MALL_ITEMBONUS) / 10,
		tch->GetPoint(POINT_MALL_GOLDBONUS) / 10);

	ch->ChatPacket(CHAT_TYPE_INFO, "BONUS:");
	ch->ChatPacket(CHAT_TYPE_INFO, "   SKILL:%3d%% NORMAL:%3d%% SKILL_DEF:%3d%% NORMAL_DEF:%3d%%",
		tch->GetPoint(POINT_SKILL_DAMAGE_BONUS),
		tch->GetPoint(POINT_NORMAL_HIT_DAMAGE_BONUS),
		tch->GetPoint(POINT_SKILL_DEFEND_BONUS),
		tch->GetPoint(POINT_NORMAL_HIT_DEFEND_BONUS));

	ch->ChatPacket(CHAT_TYPE_INFO, "   HUMAN:%3d%% ANIMAL:%3d%% ORC:%3d%% MILGYO:%3d%% UNDEAD:%3d%%",
		tch->GetPoint(POINT_ATTBONUS_HUMAN),
		tch->GetPoint(POINT_ATTBONUS_ANIMAL),
		tch->GetPoint(POINT_ATTBONUS_ORC),
		tch->GetPoint(POINT_ATTBONUS_MILGYO),
		tch->GetPoint(POINT_ATTBONUS_UNDEAD));

	ch->ChatPacket(CHAT_TYPE_INFO, "   DEVIL:%3d%% INSECT:%3d%% FIRE:%3d%% ICE:%3d%% DESERT:%3d%%",
		tch->GetPoint(POINT_ATTBONUS_DEVIL),
		tch->GetPoint(POINT_ATTBONUS_INSECT),
		tch->GetPoint(POINT_ATTBONUS_FIRE),
		tch->GetPoint(POINT_ATTBONUS_ICE),
		tch->GetPoint(POINT_ATTBONUS_DESERT));

	ch->ChatPacket(CHAT_TYPE_INFO, "   TREE:%3d%% MONSTER:%3d%%",
		tch->GetPoint(POINT_ATTBONUS_TREE),
		tch->GetPoint(POINT_ATTBONUS_MONSTER));

	ch->ChatPacket(CHAT_TYPE_INFO, "   WARR:%3d%% ASAS:%3d%% SURA:%3d%% SHAM:%3d%%"
#ifdef ENABLE_WOLFMAN_CHARACTER
		" WOLF:%3d%%"
#endif
		,
		tch->GetPoint(POINT_ATTBONUS_WARRIOR),
		tch->GetPoint(POINT_ATTBONUS_ASSASSIN),
		tch->GetPoint(POINT_ATTBONUS_SURA),
		tch->GetPoint(POINT_ATTBONUS_SHAMAN)
#ifdef ENABLE_WOLFMAN_CHARACTER
		, tch->GetPoint(POINT_ATTBONUS_WOLFMAN)
#endif
	);
	ch->ChatPacket(CHAT_TYPE_INFO, "IMMUNE:");
	ch->ChatPacket(CHAT_TYPE_INFO, "   STUN:%d SLOW:%d FALL:%d",
		tch->GetPoint(POINT_IMMUNE_STUN),
		tch->GetPoint(POINT_IMMUNE_SLOW),
		tch->GetPoint(POINT_IMMUNE_FALL));
#endif
	for (int i = 0; i < MAX_PRIV_NUM; ++i)
		if (CPrivManager::instance().GetPriv(tch, i))
		{
			int iByEmpire = CPrivManager::instance().GetPrivByEmpire(tch->GetEmpire(), i);
			int iByGuild = 0;

			if (tch->GetGuild())
				iByGuild = CPrivManager::instance().GetPrivByGuild(tch->GetGuild()->GetID(), i);

			int iByPlayer = CPrivManager::instance().GetPrivByCharacter(tch->GetPlayerID(), i);

			if (iByEmpire)
				ch->ChatPacket(CHAT_TYPE_INFO, "%s for empire : %d", LC_TEXT(c_apszPrivNames[i]), iByEmpire);

			if (iByGuild)
				ch->ChatPacket(CHAT_TYPE_INFO, "%s for guild : %d", LC_TEXT(c_apszPrivNames[i]), iByGuild);

			if (iByPlayer)
				ch->ChatPacket(CHAT_TYPE_INFO, "%s for player : %d", LC_TEXT(c_apszPrivNames[i]), iByPlayer);
		}
}

Arat:
ACMD(do_who)

De�i�tir:

ACMD(do_who)
{
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	int iTotal;
	int * paiEmpireUserCount;
	int iLocal;

	DESC_MANAGER::instance().GetUserCount(iTotal, &paiEmpireUserCount, iLocal);
	int shopCount = P2P_MANAGER::instance().GetForeignShopCount() + CHARACTER_MANAGER::instance().CountOfflineShops();

	ch->ChatPacket(CHAT_TYPE_INFO, "Total [%d] %d / %d / %d (this server %d) | Shops: %d", 
			iTotal, paiEmpireUserCount[1], paiEmpireUserCount[2], paiEmpireUserCount[3], iLocal, shopCount);
#else
	int iTotal;
	int* paiEmpireUserCount;
	int iLocal;

	DESC_MANAGER::instance().GetUserCount(iTotal, &paiEmpireUserCount, iLocal);

	ch->ChatPacket(CHAT_TYPE_INFO, "Total [%d] %d / %d / %d (this server %d)",
		iTotal, paiEmpireUserCount[1], paiEmpireUserCount[2], paiEmpireUserCount[3], iLocal);
#endif
}

Uygun bir alana ekleyin:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
ACMD(do_shop_withdraw)
{
	char arg1[56];
	one_argument(argument, arg1, sizeof(arg1));

	unsigned long long gold;
	if (!*arg1 || !str_to_number(gold, arg1))
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "Usage: shop_withdraw <amount>");
		return;
	}

	if (gold < 1) 
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "The amount of gold to withdraw should be above zero.");
		return;
	}

	if ((unsigned long long)gold > ch->GetShopGoldStash())
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "You are trying to withdraw more gold than the %llu you have!", ch->GetShopGoldStash());
		return;
	}

	DWORD pid = ch->GetPlayerID();
	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, ch->GetDesc()->GetHandle(), sizeof(BYTE) + sizeof(DWORD) + sizeof(unsigned long long));
	BYTE subheader = SHOP_SUBHEADER_GD_WITHDRAW;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));
	db_clientdesc->Packet(&gold, sizeof(unsigned long long));
}

ACMD(do_shop_close)
{
	char arg1[56];
	DWORD pid = 0;
	one_argument(argument, arg1, sizeof(arg1));

	if (!*arg1 || !str_to_number(pid, arg1))
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "Usage: shop_close <pid>");
		return;
	}

	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD));
	BYTE subheader = SHOP_SUBHEADER_GD_CLOSE_REQUEST;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));

	ch->ChatPacket(CHAT_TYPE_INFO, "Shop closing requested for pid #%d", pid);
}

ACMD(do_shop_moderate)
{
	char arg1[56];
	DWORD pid = 0;
	one_argument(argument, arg1, sizeof(arg1));

	if (!*arg1 || !str_to_number(pid, arg1))
	{
		ch->ChatPacket(CHAT_TYPE_INFO, "Usage: shop_moderate <pid>");
		return;
	}

	char newName[SHOP_SIGN_MAX_LEN + 1];
	strlcpy(newName, "Private shop", sizeof(newName));

	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(newName));
	BYTE subheader = SHOP_SUBHEADER_GD_RENAME;
	db_clientdesc->Packet(&subheader, sizeof(BYTE));
	db_clientdesc->Packet(&pid, sizeof(DWORD));
	db_clientdesc->Packet(newName, sizeof(newName));

	ch->ChatPacket(CHAT_TYPE_INFO, "Renaming shop %lu to 'Private shop'", pid);
}
#endif
