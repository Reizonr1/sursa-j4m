Arat:
};

class CInputDead : public CInputMain

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		RemoveMyShopItem(LPCHARACTER ch, const char * c_pData);
	void		AddMyShopItem(LPCHARACTER ch, const char * c_pData);		
	void		ClosePlayerShop(LPCHARACTER ch);
	void		OpenPlayerShop(LPCHARACTER ch);
	void		OpenPlayerShopSearch(LPCHARACTER ch);
	void		WithdrawShopStash(LPCHARACTER ch, const TPacketCGShopWithdraw * pack);
	void		RenameShop(LPCHARACTER ch, TPacketGCShopRename *pack);
#endif

Arat:
	void		GuildLoad(const char* c_pData);

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		MyShopInfoLoad(LPDESC d, const char * c_pData);
	void		MyShopPremiumTimeUpdate(const char * c_pData);
	void		CloseShop(const char * c_pData);
#endif

Arat:
	void		MoneyLog(const char* c_pData);

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		SpawnPlayerShops(const char * c_pData);
	void		SpinPlayerShopTimer(const char * c_pData);
	void		StopPlayerShopTimer(const char * c_pData);
#endif

Arat:
protected:
	DWORD		m_dwHandle;
};

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
public:
	void		ReceiveShopSaleInfo(const char * c_pData);
	void		WithdrawGoldResult(LPDESC desc, TPacketGoldWithdrawResult* p);
	void		MyShopClose(const char * c_pData);
	void		UpdateMyShopName(const char * c_pData);
#endif

Arat:
protected:
	CPacketInfoGG 	m_packetInfoGG;
};

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	void		StartShopOffline(LPDESC d, const char * c_pData);
	void		EndShopOffline(LPDESC d, const char * c_pData);
#endif

