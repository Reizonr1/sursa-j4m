Arat:
	: m_dwVnum(0), m_dwNPCVnum(0), m_pkPC(NULL)
Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	, m_closed(false), m_openTime(0), m_offlineMinutes(0), m_premiumMinutes(0), m_renamePulse(0)
#endif

hemen alt�nda bul:
	m_pGrid = M2_NEW CGrid(5, 9);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	m_pGrid = M2_NEW CGrid(SHOP_GRID_WIDTH, SHOP_GRID_HEIGHT);
#else
	m_pGrid = M2_NEW CGrid(5, 9);
#endif

Arat:
		ch->SetShop(NULL);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		ch->SetViewingShop(NULL);
#else
		ch->SetShop(NULL);
#endif

Arat:
void CShop::SetShopItems(TShopItemTable* pTable, BYTE bItemCount)

�st�ne ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
void CShop::TransferItems(LPCHARACTER owner, TShopItemTable * pTable, BYTE bItemCount)
{
	if (!owner)
		return;

	std::vector<TPlayerItem> shopItems = owner->GetShopItems();

	// Start copying the items over
	for (int i = 0; i < bItemCount; ++i, ++pTable)
	{
		LPITEM pkItem = nullptr;
		pkItem = owner->GetItem(pTable->pos);
		
		if (!pkItem)
			continue;

		if (pkItem->IsEquipped())
			continue;

		if (!m_pGrid->IsEmpty(pTable->display_pos, 1, pkItem->GetProto()->bSize)) 
		{
			sys_err("Prevented from overriding item on position %d for shop #%lu!", pTable->display_pos, GetOwner()->GetPlayerID());
			continue;
		}

		if (owner->GetDesc()) //Actual player, not fake char from DB -> core shop spawns
		{
			//Store it into the shop vector
			TPlayerItem playerItem;
			playerItem.id = pkItem->GetID();
			playerItem.vnum = pkItem->GetVnum();
			playerItem.count = pkItem->GetCount();
			playerItem.owner = owner->GetPlayerID();
			playerItem.pos = pTable->display_pos;
			playerItem.window = pkItem->GetWindow();
			thecore_memcpy(playerItem.alSockets, pkItem->GetSockets(), sizeof(playerItem.alSockets));
			thecore_memcpy(playerItem.aAttr, pkItem->GetAttributes(), sizeof(playerItem.aAttr));
			shopItems.push_back(playerItem);

			//Inform the client
			TPacketPlayerShopSet pack;
			pack.header = HEADER_GC_PLAYER_SHOP_SET;
			pack.pos = pTable->display_pos;

#ifdef ENABLE_ITEM_COUNT_LIMIT_SYSTEM
			pack.count = (WORD)playerItem.count;
#else
			pack.count = (BYTE)playerItem.count;
#endif
			pack.vnum = playerItem.vnum;
			pack.price = pTable->price;

			thecore_memcpy(pack.alSockets, playerItem.alSockets, sizeof(pack.alSockets));
			thecore_memcpy(pack.aAttr, playerItem.aAttr, sizeof(pack.aAttr));

			owner->GetDesc()->Packet(&pack, sizeof(TPacketPlayerShopSet));
		}

		//Remove from quickslot
		owner->SyncQuickslot(QUICKSLOT_TYPE_ITEM, (BYTE)pkItem->GetCell(), 255);

		//Store latest window & transfer
		BYTE prevWindow = pkItem->GetWindow();
		if (prevWindow == SHOP)
			pkItem->SetSkipSave(true); //If it was already in SHOP window, we are transferring from some sort of "fake" char. No need to save.

		pkItem->RemoveFromCharacter();
		
		//We'll be setting it to a separate window
		pTable->pos = TItemPos(SHOP, pTable->display_pos);
		
		pkItem->AddToCharacter(m_pkPC, pTable->pos);
		
		if (prevWindow != SHOP) //Only if it's coming from someplace else that's not shop window (i.e only if its the first time this item goes to shop)
		{
			ITEM_MANAGER::instance().FlushDelayedSave(pkItem);
			LogManager::instance().ItemLog(owner, pkItem, "PUT_INTO_SHOP", pkItem->GetName());
		}
		else
		{
			pkItem->SetSkipSave(false); //as we enabled it before
		}
	}

	owner->SetShopItems(shopItems);
}
#endif

Arat:
void CShop::SetShopItems(TShopItemTable* pTable, BYTE bItemCount)

De�i�tir (kendinize g�re d�zenleyin:

void CShop::SetShopItems(TShopItemTable* pTable, BYTE bItemCount)
{
	if (bItemCount > SHOP_HOST_ITEM_MAX_NUM)
		return;

	m_pGrid->Clear();

	m_itemVector.resize(SHOP_HOST_ITEM_MAX_NUM);
	msl::refill(m_itemVector);

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	for (int i = 0; i < bItemCount; ++i)
	{
		SetShopItem(pTable);
		++pTable;
	}
#else
	for (int i = 0; i < bItemCount; ++i)
	{
		LPITEM pkItem = NULL;
		const TItemTable* item_table;

		if (m_pkPC)
		{
			pkItem = m_pkPC->GetItem(pTable->pos);

			if (!pkItem)
			{
				sys_err("cannot find item on pos (%d, %d) (name: %s)", pTable->pos.window_type, pTable->pos.cell, m_pkPC->GetName());
				continue;
			}

			item_table = pkItem->GetProto();
		}
		else
		{
			if (!pTable->vnum)
				continue;

			item_table = ITEM_MANAGER::instance().GetTable(pTable->vnum);
		}

		if (!item_table)
		{
			sys_err("Shop: no item table by item vnum #%d", pTable->vnum);
			continue;
		}

		int iPos;

		if (IsPCShop())
		{
			sys_log(0, "MyShop: use position %d", pTable->display_pos);
			iPos = pTable->display_pos;
		}
		else
			iPos = m_pGrid->FindBlank(1, item_table->bSize);

		if (iPos < 0)
		{
			sys_err("not enough shop window");
			continue;
		}

		if (!m_pGrid->IsEmpty(iPos, 1, item_table->bSize))
		{
			if (IsPCShop())
			{
				sys_err("not empty position for pc shop %s[%d]", m_pkPC->GetName(), m_pkPC->GetPlayerID());
			}
			else
			{
				sys_err("not empty position for npc shop");
			}
			continue;
		}

		m_pGrid->Put(iPos, 1, item_table->bSize);

		SHOP_ITEM& item = m_itemVector[iPos];

		item.pkItem = pkItem;
		item.itemid = 0;

		if (item.pkItem)
		{
			item.vnum = pkItem->GetVnum();
			item.count = pkItem->GetCount();
			item.price = pTable->price;
			item.itemid = pkItem->GetID();
#ifdef ENABLE_AUCTION_SYSTEM
			item.pos = pTable->pos;
#endif
		}
		else
		{
			item.vnum = pTable->vnum;
			item.count = pTable->count;
#ifdef ENABLE_BUY_WITH_ITEM
			item.witemVnum = pTable->witemVnum;
#endif
#ifdef ENABLE_AUCTION_SYSTEM
			item.pos = 0;
#endif
#ifdef ENABLE_SHOP_ITEM_PRICE_ON_SQL
			item.price = iPos;
			if (item.price == -1)//Tablodaki deger -1 ise protodan calisir
#endif
			{
				if (IS_SET(item_table->dwFlags, ITEM_FLAG_COUNT_PER_1GOLD))
				{
					if (item_table->dwGold == 0)
						item.price = item.count;
					else
						item.price = item.count / item_table->dwGold;
				}
				else
					item.price = item_table->dwGold * item.count;
			}
		}

		char name[36];
		snprintf(name, sizeof(name), "%-20s(#%-5d) (x %d)", item_table->szName, (int)item.vnum, item.count);

		sys_log(0, "SHOP_ITEM: %-36s PRICE %-5d", name, item.price);
		++pTable;
	}
#endif
}

Arat:
		m_pkPC->SyncQuickslot(QUICKSLOT_TYPE_ITEM, item->GetCell(), 255);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		if (!m_pkPC->GetPlayerID()) 
		{
			sys_err("Shop not bound to any player ID!");
			return SHOP_SUBHEADER_GC_SOLD_OUT;
		}
#else
		m_pkPC->SyncQuickslot(QUICKSLOT_TYPE_ITEM, item->GetCell(), 255);
#endif

Arat:
		r_item.pkItem = NULL;

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		r_item.count = 0;
		r_item.pkItem = NULL;
		r_item.itemid = 0;
		r_item.vnum = 0;
		r_item.price = 0;
#else
		r_item.pkItem = NULL;
#endif

�stteki yapt���m�z i�lemin hemen alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		m_pGrid->Get(pos, 1, item->GetSize());
#endif

Arat:
		m_pkPC->PointChange(POINT_GOLD, dwPrice, false);

		if (iVal > 0)
			m_pkPC->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�Ǹűݾ��� %d %% �� �������� �����Ե˴ϴ�"), iVal);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		DWORD pid = m_pkPC->GetPlayerID();

		db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(BYTE));
		BYTE subheader = SHOP_SUBHEADER_GD_BUY;
		db_clientdesc->Packet(&subheader, sizeof(BYTE));
		db_clientdesc->Packet(&pid, sizeof(DWORD));
		db_clientdesc->Packet(&pos, sizeof(BYTE));
#else
		m_pkPC->PointChange(POINT_GOLD, dwPrice, false);

		if (iVal > 0)
			m_pkPC->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("�Ǹűݾ��� %d %% �� �������� �����Ե˴ϴ�"), iVal);
#endif

�stteki yapt���m�z i�lemin hemen alt�na ekle:

#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
		//Tax goes for the seller's empire
		CMonarch::instance().SendtoDBAddMoney(dwTax, m_pkPC->GetEmpire(), m_pkPC);
#endif

�stteki yapt���m�z i�lemin hemen alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
		//If there's nothing more, we close shop.
		if (IsEmpty())
		{
			sys_log(0, "Closing player #%lu shop because there's nothing more to sell.", m_pkPC->GetPlayerID());
			CloseMyShop();
		}
#endif
	}
	else
	{
#ifndef ENABLE_OFFLINE_SHOP_SYSTEM
		//Tax goes for the buyer's empire.
		CMonarch::instance().SendtoDBAddMoney(dwTax, ch->GetEmpire(), ch);
#endif

Arat:	if (ch->GetShop())

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetViewingShop())
#else
	if (ch->GetShop())
#endif

Arat:
	ch->SetShop(this);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	ch->SetViewingShop(this);
#else
	ch->SetShop(this);
#endif

Arat:
	if (ch->GetShop() != this)

De�i�tir:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	if (ch->GetViewingShop() != this)
#else
	if (ch->GetShop() != this)
#endif

Arat:
	ch->SetShop(NULL);

De�i�tir:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	ch->SetViewingShop(NULL);
#else
	ch->SetShop(NULL);
#endif

En alta ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
bool CShop::IsEmpty()
{
	for (const auto i : m_itemVector)
	{
		if (i.vnum != 0) {
			return false;
		}
	}

	return true;
}

bool CShop::TransferItemAway(LPCHARACTER ch, BYTE pos, TItemPos targetPos)
{
	if (pos > m_itemVector.size()) {
		sys_err("Out of bounds attempt to transfer an item out of the shop (pos %d)", pos);
		return false;
	}

	if (!IsPCShop()) {
		sys_err("Trying to transfer an item from a non-pc shop. HACKER!");
		return false;
	}

	if (targetPos.window_type != INVENTORY && targetPos.window_type != DRAGON_SOUL_INVENTORY
#ifdef ENABLE_SPECIAL_STORAGE
		&& targetPos.window_type != UPGRADE_INVENTORY && targetPos.window_type != BOOK_INVENTORY && targetPos.window_type != STONE_INVENTORY
#endif
	) {
		sys_err("Invalid transfer window (%d) by %s.", targetPos.window_type, ch->GetName());
		return false;
	}
	
	//Can't deploy directly to equipment.
	if (targetPos.IsEquipPosition()) {
		return false;
	}

	SHOP_ITEM& r_item = m_itemVector[pos];
	if (!r_item.itemid)
		return false;
	
	LPITEM item = ITEM_MANAGER::instance().Find(r_item.itemid);
	if (!item) {
		sys_err("No item could be transferred for pos %d (Doesn't exist)", pos);
		return false;
	}

	//Determine if the position given for the item is OK or if
	//we need to find a new one (or whether we can't find any).
	//Note: Dragon Soul items are always sent to a position determined by the system.
	int iEmptyCell;
	if (!ch->GetItem(targetPos) && ch->IsEmptyItemGrid(targetPos,item->GetSize()) && !item->IsDragonSoul()
#ifdef ENABLE_SPECIAL_STORAGE
		&& !item->IsUpgradeItem() && !item->IsBook() && !item->IsStone()
#endif
	)
	{
		iEmptyCell = targetPos.cell;
	}
	else 
	{
		if (item->IsDragonSoul())
			iEmptyCell = ch->GetEmptyDragonSoulInventory(item);
#ifdef ENABLE_SPECIAL_STORAGE
		else if (item->IsUpgradeItem())
			iEmptyCell = ch->GetEmptyUpgradeInventory(item);
		else if (item->IsBook())
			iEmptyCell = ch->GetEmptyBookInventory(item);
		else if (item->IsStone())
			iEmptyCell = ch->GetEmptyStoneInventory(item);
#endif
		else
			iEmptyCell = ch->GetEmptyInventory(item->GetSize());
	}
	
	if (iEmptyCell < 0) {
		ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("NO_INVENTORY_POSITION_FOUND_FOR_YOUR_SHOP_ITEM_TRANSFER"));
		return false;
	}

	item->RemoveFromCharacter();

	//Remove it from the list of the shop items on the receiver
	std::vector<TPlayerItem> shopItems = ch->GetShopItems();
	for (auto it = shopItems.begin(); it != shopItems.end(); ++it)
	{
		if (it->pos == pos)
		{
			shopItems.erase(it);
			break;
		}
	}
	ch->SetShopItems(shopItems);

	//Add the item
	if (item->IsDragonSoul())
		item->AddToCharacter(ch, TItemPos(DRAGON_SOUL_INVENTORY, iEmptyCell));
#ifdef ENABLE_SPECIAL_STORAGE
	else if (item->IsUpgradeItem())
		item->AddToCharacter(ch, TItemPos(UPGRADE_INVENTORY, iEmptyCell));
	else if (item->IsBook())
		item->AddToCharacter(ch, TItemPos(BOOK_INVENTORY, iEmptyCell));
	else if (item->IsStone())
		item->AddToCharacter(ch, TItemPos(STONE_INVENTORY, iEmptyCell));
#endif
	else
		item->AddToCharacter(ch, TItemPos(INVENTORY, iEmptyCell));

	ITEM_MANAGER::instance().FlushDelayedSave(item);
	
	//Remove the item from the vector & update everyone
	r_item.count = 0;
	r_item.pkItem = NULL;
	r_item.itemid = 0;
	r_item.vnum = 0;
	r_item.price = 0;

	//Clear these slots on the grid
	m_pGrid->Get(pos, 1, item->GetSize());

	BroadcastUpdateItem(pos);

	if (IsEmpty())
	{
		sys_log(0, "Closing player #%lu shop because the owner took the last item from it.", m_pkPC->GetPlayerID());
		CloseMyShop();
	}

	return true;
}

void CShop::CloseMyShop()
{
	if (!IsPCShop())
		return;

	//Save the latest shop data
	SetClosed(true);
	Save();

	//We'll destroy the character and the shop from the outside.
}

void CShop::Save()
{
	if (!GetOwner()) 
	{
		sys_err("Trying to save non-pc shop.");
		return;
	}

	//Create a shop table and fill in basic info
	std::string shopSign = GetShopSign();

	TPlayerShopTable table;
	table.pid = m_pkPC->GetPlayerID();
	strlcpy(table.playerName, m_pkPC->GetName(), sizeof(table.playerName));
	strlcpy(table.shopName, shopSign.c_str(), sizeof(table.shopName));
	table.x = m_pkPC->GetX();
	table.y = m_pkPC->GetY();
	table.channel = g_bChannel;
	table.mapIndex = m_pkPC->GetMapIndex();
	table.closed = IsClosed();
	table.openTime = GetOpenTime();

	//Populate the items table.
	memset(table.items, 0, sizeof(table.items));
	std::vector<CShop::SHOP_ITEM> shopItems = GetItemVector();

	int i = 0;
	for (const auto si : shopItems)
	{
		if (!si.vnum || !si.pkItem) //Empty OR already bought
			continue;

		TShopItemTable t;
		t.vnum = si.vnum;
		t.price = si.price;
		t.pos = TItemPos(SHOP, si.pkItem->GetCell());
		t.display_pos = (BYTE)si.pkItem->GetCell();
		t.count = si.count;

		table.items[i] = t;
		++i;
	}

	//Send to DB
	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(TPlayerShopTable));
	BYTE subHeader = SHOP_SUBHEADER_GD_SAVE;

	db_clientdesc->Packet(&subHeader, sizeof(BYTE));
	db_clientdesc->Packet(&table, sizeof(TPlayerShopTable));
}

//Save offline minutes via a packet to DB.
void CShop::SaveOffline()
{
	if (!GetOwner())
	{
		sys_err("Trying to save non-pc shop.");
		return;
	}

	db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(int) + sizeof(int));
	
	BYTE subtype = SHOP_SUBHEADER_GD_UPDATE_OFFLINE;
	db_clientdesc->Packet(&subtype, sizeof(BYTE));
	
	DWORD pid = GetOwner()->GetPlayerID();
	db_clientdesc->Packet(&pid, sizeof(DWORD));

	int offTime = GetOfflineMinutes();
	db_clientdesc->Packet(&offTime, sizeof(int));

	int premTime = GetPremiumMinutes();
	db_clientdesc->Packet(&premTime, sizeof(int));
}

bool CShop::CanOpenShopHere(long mapindex)
{
	if (test_server && mapindex == 103) //GM map on test server
		return true;

	switch (mapindex)
	{
	//Map1
	case 1:
	case 21:
	case 41:
	
	//Map2
	case 3:
	case 23:
	case 43:
		return true;
		break;

	default:
		return false;
	}
}

bool CShop::RemoveItemByID(DWORD itemID)
{
	for (size_t i = 0; i < m_itemVector.size() && i < SHOP_HOST_ITEM_MAX_NUM; ++i)
	{
		SHOP_ITEM & item = m_itemVector[i];
		if (!item.pkItem || !item.vnum)
			continue;

		//Found! Delete, return OK
		if (item.itemid == itemID) 
		{
			BYTE pos = i;
			DWORD pid = m_pkPC->GetPlayerID();

			LPITEM pkItem = item.pkItem;


			LPCHARACTER pkOwner = CHARACTER_MANAGER::instance().FindByPID(pid);
			if (pkOwner)
			{
				std::vector<TPlayerItem> shopItems = pkOwner->GetShopItems(); 	//Remove it from the list of the shop items on the receiver
				for (auto it = shopItems.begin(); it != shopItems.end(); ++it)
				{
					if (it->pos == pos)
					{
						shopItems.erase(it);
						break;
					}
				}
				pkOwner->SetShopItems(shopItems);

				
			}


			item.itemid = 0;
			item.pkItem = NULL;
			item.vnum = 0;
			item.count = 0;
			item.price = 0;

			m_pGrid->Get(pos, 1, pkItem->GetSize());

			BroadcastUpdateItem(i);

			if (!IsEmpty())
			{
				db_clientdesc->DBPacketHeader(HEADER_GD_SHOP, 0, sizeof(BYTE) + sizeof(DWORD) + sizeof(BYTE));
				BYTE subheader = SHOP_SUBHEADER_GD_REMOVE;
				db_clientdesc->Packet(&subheader, sizeof(BYTE));
				db_clientdesc->Packet(&pid, sizeof(DWORD));
				db_clientdesc->Packet(&pos, sizeof(BYTE));
			}

			if(pkOwner)
				pkOwner->RemoveShopItemByPos(pos);

			if (IsEmpty())
			{
				sys_log(0, "Closing player #%lu shop because there's nothing more to sell.", m_pkPC->GetPlayerID());
				CloseMyShop();
			}

			//Closed shop, destroy it (through owner)
			if (IsClosed() && IsPCShop())
			{
				if(pkOwner)
				{
					TPacketPlayerShopSign p; // Also sync the shop sign here
					p.header = HEADER_GC_MY_SHOP_SIGN;
					memset(p.sign, 0, sizeof(p.sign));
					pkOwner->GetDesc()->Packet(&p, sizeof(TPacketPlayerShopSign));
				}

				M2_DESTROY_CHARACTER(GetOwner());
			}

			return true;
		}
	}

	return false;
}
#endif

