Arat:
	GUILD_NAME_MAX_LEN		= 12,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	PRIVATE_SHOP_ITEM_MAX_NUM = 84,
#endif

Arat:
	CHAR_TYPE_GOTO,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	CHAR_TYPE_SHOP,
#endif

Arat:
	DRAGON_SOUL_INVENTORY,

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SHOP,
#endif

Arat:
	PREMIUM_GOLD,

Alt�na ekle:
#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	PREMIUM_SHOP_DOUBLE_UP,		// Doubles MAX on Activity to => OfflineMinutes.
#endif

Arat:
} TItemPos;

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	bool operator!=(const struct SItemPos& rhs) const
	{
		return (window_type != rhs.window_type) || (cell != rhs.cell);
	}
#endif