Arat:
	HEADER_GD_REQUEST_CHANNELSTATUS	= 140,

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_GD_SHOP					= 142,
	HEADER_GD_SAVE_SHOP				= 143,
	HEADER_GD_WITHDRAW_SHOP_GOLD 	= 144,
#endif

Arat:

	HEADER_DG_RESPOND_CHANNELSTATUS		= 181,

Altna ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	HEADER_DG_SHOP_MYINFO_LOAD		 	= 183,
	HEADER_DG_SHOP_SALE_INFO 			= 184,
	HEADER_DG_SHOP_WITHDRAW_RESULT 		= 185,
	HEADER_DG_PLAYER_SPAWN_SHOP 		= 186,
	HEADER_DG_SHOP_STOP_OFFLINE 		= 187,
	HEADER_DG_SHOP_TIMER 				= 188,
	HEADER_DG_SHOP_PREMIUM_TIME_UPDATE 	= 189,
	HEADER_DG_SHOP_CLOSE 				= 190,
	HEADER_DG_SHOP_UPDATE_NAME 			= 191,
#endif

Arat:
typedef struct SShopItemTable

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
	SShopItemTable() : vnum(0), count(0), pos(0, 0), price(0), display_pos(0)
#endif

Arat:
typedef struct SChannelStatus

Alt�na ekle:

#ifdef ENABLE_OFFLINE_SHOP_SYSTEM
typedef struct SPlayerShopTable
{
	DWORD		pid;
	char		playerName[CHARACTER_NAME_MAX_LEN + 1];
	char		shopName[SHOP_SIGN_MAX_LEN + 1];
	long		x;
	long		y;
	long		mapIndex;
	int			channel;	
	DWORD		openTime;
	bool		closed;
	TShopItemTable	items[SHOP_HOST_ITEM_MAX_NUM];


	bool operator!= (const struct SPlayerShopTable& other) 
	{
		if (pid != other.pid || strcmp(shopName, other.shopName) != 0 ||
			x != other.x || y != other.y || channel != other.channel ||
			mapIndex != other.mapIndex || closed != other.closed || 
			openTime != other.openTime)
			return true;

		for (size_t i = 0; i < sizeof(items) / sizeof(TShopItemTable); ++i) 
		{
			if (items[i] != other.items[i])
				return true;
		}
		
		return false;
	}
} TPlayerShopTable;

typedef struct SPlayerShopTableCache: TPlayerShopTable
{
	unsigned long long goldStash;
	int offlineMinutesLeft;
	int premiumMinutesLeft;
} TPlayerShopTableCache;

typedef struct
{
	DWORD itemVnum;
	int amount;
	unsigned long long gold;
	BYTE pos;
} TPacketShopSaleResult;

typedef struct
{
	bool success;
	unsigned long long goldAmount;
	DWORD shopPid;
} TPacketGoldWithdrawResult;

enum ShopSubheaders
{
	SHOP_SUBHEADER_GD_SAVE,
	SHOP_SUBHEADER_GD_BUY,
	SHOP_SUBHEADER_GD_REMOVE,
	SHOP_SUBHEADER_GD_WITHDRAW,
	SHOP_SUBHEADER_GD_UPDATE_OFFLINE,
	SHOP_SUBHEADER_GD_ADD_PREMIUM_TIME,
	SHOP_SUBHEADER_GD_CLOSE_REQUEST,
	SHOP_SUBHEADER_GD_RENAME,
	SHOP_SUBHEADER_GD_REQUEST_PREMIUM_TIME_SYNC,
	SHOP_SUBHEADER_GD_WITHDRAW_ROLLBACK,
};

typedef struct SMyShopPriceInfo
{
	WORD	pos;
	unsigned long long	price;
} TMyShopPriceInfo;
#endif