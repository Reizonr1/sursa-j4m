# Metin2 Hide Objects(24.05.2018)
# Blackdragonx61
<img src="https://media.giphy.com/media/YBIdGKM9vghWjxLevn/giphy.gif" />
