//Find
		void								DeleteVehicleInstance(DWORD VirtualID);
		
///Add
#ifdef HIDE_OBJECTS
		void								SetVisibleShops(bool visible);
#endif