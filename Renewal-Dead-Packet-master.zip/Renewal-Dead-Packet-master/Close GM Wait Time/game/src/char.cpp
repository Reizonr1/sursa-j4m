//Find
	if (!m_pkDeadEvent)
		return 0;
	
///Change
	if (IsGM() || !m_pkDeadEvent)
		return 0;