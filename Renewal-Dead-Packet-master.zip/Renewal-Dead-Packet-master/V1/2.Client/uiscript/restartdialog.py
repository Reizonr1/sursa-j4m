#Find
				{
					"name" : "restart_town_button",
					"type" : "button",

					"x" : 10,
					"y" : 47,

					"text" : uiScriptLocale.RESTART_TOWN,

					"default_image" : ROOT + "XLarge_Button_01.sub",
					"over_image" : ROOT + "XLarge_Button_02.sub",
					"down_image" : ROOT + "XLarge_Button_03.sub",
				},
				
#Add
				{
					"name" : "T0",
					"type" : "text",
					"x" : 175,
					"y" : 23,         
					"text" : "",
				},
				{
					"name" : "T1",
					"type" : "text",   
					"x" : 175,
					"y" : 53,
					"text" : "",
				},
