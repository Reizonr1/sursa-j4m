//Find in: typedef struct packet_dead
	DWORD		vid;
	
///Add
#ifdef RENEWAL_DEAD_PACKET
	DWORD t_d[2];
#endif