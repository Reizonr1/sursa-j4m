//Find
		void			SetRace(BYTE race);
		
///Add
#ifdef RENEWAL_DEAD_PACKET
		DWORD			CalculateDeadTime(BYTE type);
#endif