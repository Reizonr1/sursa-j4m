//search for:
#include "ItemData.h"

//add below:
#include "../UserInterface/Locale_inc.h"

//search for:
		CItemData *		MakeItemData(DWORD dwIndex);

//add below:
#ifdef ENABLE_ITEMSHOP
		TItemMap		GetItems() const { return m_ItemMap; }
#endif
