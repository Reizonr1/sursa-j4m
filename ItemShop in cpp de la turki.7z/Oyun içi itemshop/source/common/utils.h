na samej gorze 
#pragma once