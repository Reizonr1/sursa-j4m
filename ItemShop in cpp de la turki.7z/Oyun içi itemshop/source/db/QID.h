//search for:
	// MYSHOP_PRICE_LIST
    QID_ITEMPRICE_SAVE,			///< 21, 아이템 가격정보 저장 쿼리
    QID_ITEMPRICE_DESTROY,		///< 22, 아이템 가격정보 삭제 쿼리
    QID_ITEMPRICE_LOAD_FOR_UPDATE,	///< 23, 가격정보 업데이트를 위한 아이템 가격정보 로드 쿼리
    QID_ITEMPRICE_LOAD,			///< 24, 아이템 가격정보 로드 쿼리
	// END_OF_MYSHOP_PRICE_LIST

//add below:
#ifdef __ITEM_SHOP__
	QID_ITEMSHOP_COINS_LOAD,
	QID_ITEMSHOP_ITEMS_LOAD,
	QID_ITEMSHOP_EDITORS_LOAD,
#endif