//search for:
const char * GetPlayerDBName();

//add below:
#ifdef __ITEM_SHOP__
const char * GetAccountDBName();
#endif