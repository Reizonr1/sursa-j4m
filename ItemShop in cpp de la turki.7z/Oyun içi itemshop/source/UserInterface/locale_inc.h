//add somewhere
#define ENABLE_ITEMSHOP