//search for:
PyObject* itemLoadItemTable(PyObject* poSelf, PyObject* poArgs)
{
	[...]
}

//add below:
#ifdef ENABLE_ITEMSHOP
PyObject * itemGetItemNames(PyObject * poSelf, PyObject * poArgs)
{
	CItemManager::TItemMap m_ItemMap = CItemManager::Instance().GetItems();
	CItemManager::TItemMap::iterator f = m_ItemMap.begin();
	PyObject* dict = PyTuple_New(m_ItemMap.size());
	int i = 0;
	while (m_ItemMap.end() != f)
	{
		PyObject* item = PyDict_New();
		PyDict_SetItemString(item, "vnum", Py_BuildValue("i", f->second->GetIndex()));
		PyDict_SetItemString(item, "name", Py_BuildValue("s", f->second->GetName()));
		PyTuple_SetItem(dict, i++, item);
		f++;
	}
	return dict;
}
#endif

//search for:
		{ "LoadItemTable",					itemLoadItemTable,						METH_VARARGS },

//add below:
#ifdef ENABLE_ITEMSHOP
		{ "GetNames",						itemGetItemNames,						METH_VARARGS },
#endif