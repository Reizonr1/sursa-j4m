//search for:
#include "HackShield.h"

//add below:
#ifdef __ITEM_SHOP__
#include "itemshop_manager.h"
#endif

//search for:
	case HEADER_DG_RESPOND_CHANNELSTATUS:
		RespondChannelStatus(DESC_MANAGER::instance().FindByHandle(m_dwHandle), c_pData);
		break;

//add below:
		#ifdef __ITEM_SHOP__
	case HEADER_DG_ITEMSHOP_COINS_LOAD:
		ItemShopCoinsLoad(DESC_MANAGER::instance().FindByHandle(m_dwHandle), c_pData);
		break;
		
	case HEADER_DG_ITEMSHOP_ITEMS_LOAD:
		ItemShopItemsLoad(DESC_MANAGER::instance().FindByHandle(m_dwHandle), c_pData);
		break;
		
	case HEADER_DG_ITEMSHOP_EDITORS_LOAD:
		ItemShopEditorsLoad(DESC_MANAGER::instance().FindByHandle(m_dwHandle), c_pData);
		break;
#endif

//search for:
void CInputDB::RespondChannelStatus(LPDESC desc, const char* pcData) 
{
	[...]
}

//add below:
#ifdef __ITEM_SHOP__
void CInputDB::ItemShopCoinsLoad(LPDESC d, const char * c_pData)
{
	if (!d)
		return;

	if (!d->GetCharacter())
		return;

	LPCHARACTER ch = d->GetCharacter();

	DWORD coins = decode_4bytes(c_pData);
	c_pData += sizeof(DWORD);

	ch->LoadCoins(coins);
	sys_log(0, "Load Coins from db success! Recived data %d", coins);
}

void CInputDB::ItemShopItemsLoad(LPDESC d, const char * c_pData)
{
	BYTE bType = decode_byte(c_pData);
	c_pData += sizeof(BYTE);
	
	DWORD dwCount = decode_4bytes(c_pData);
	c_pData += sizeof(DWORD);

	CItemShopManager::instance().LoadItems(bType, dwCount, (TItemShopItem *) c_pData);
}

void CInputDB::ItemShopEditorsLoad(LPDESC d, const char * c_pData)
{	
	DWORD dwCount = decode_4bytes(c_pData);
	c_pData += sizeof(DWORD);

	CItemShopManager::instance().LoadEditors(dwCount, (TItemShopEditor *) c_pData);
}
#endif