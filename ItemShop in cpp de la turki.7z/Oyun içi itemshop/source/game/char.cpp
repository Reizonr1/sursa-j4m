//add at the end of the file:

#ifdef __ITEM_SHOP__
void CHARACTER::SetCoins(int coins)
{
	TItemShopSetCoins p;
	p.coins = coins;
	p.account_id = GetDesc()->GetAccountTable().id;
	db_clientdesc->DBPacket(HEADER_GD_ITEMSHOP_SET_COINS, 0, &p, sizeof(TItemShopSetCoins));
	m_iCoins = coins;
}
#endif