//search for:
	void		AffectLoad(LPDESC d, const char * c_pData);

//add below:
#ifdef __ITEM_SHOP__
	void		ItemShopCoinsLoad(LPDESC d, const char * c_pData);
	void		ItemShopItemsLoad(LPDESC d, const char * c_pData);
	void		ItemShopEditorsLoad(LPDESC d, const char * c_pData);
#endif