//search for:
ACMD (do_clear_affect);

//add below:
#ifdef __ITEM_SHOP__
ACMD (do_itemshop);
#endif

//search for:
	{ "do_clear_affect", do_clear_affect, 	0, POS_DEAD,		GM_LOW_WIZARD},

//add below:
#ifdef __ITEM_SHOP__
	{ "itemshop", do_itemshop, 	0, POS_DEAD,		GM_PLAYER},
#endif