//search for:
#ifdef USE_STACKTRACE
#include <execinfo.h>
#endif

//add below:
#ifdef __ITEM_SHOP__
#include "itemshop_manager.h"
#endif

//search for:
	DSManager dsManager;

//add below:
#ifdef __ITEM_SHOP__
	CItemShopManager itemshop_manager;
#endif

//search for:
	PanamaLoad();

//add below:
#ifdef __ITEM_SHOP__
	CItemShopManager::instance().Initialize();
#endif