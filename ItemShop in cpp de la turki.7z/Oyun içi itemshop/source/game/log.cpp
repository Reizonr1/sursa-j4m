//search for:
void LogManager::HackShieldLog(unsigned long ErrorCode, LPCHARACTER ch)
{
	[...]
}

//add below:
#ifdef __ITEM_SHOP__
void LogManager::ItemShopBuyLog(DWORD dwItemVnum, DWORD count, DWORD dwID, DWORD dwCategory, DWORD dwAccountID, DWORD dwPrice)
{
	Query( "INSERT INTO itemshop_log%s VALUES( %d, %d, %d, %d, %d, %d, %d, NOW() )",
			get_table_postfix(),
			dwItemVnum, dwCategory, dwAccountID, dwPrice, g_bChannel);
}
#endif