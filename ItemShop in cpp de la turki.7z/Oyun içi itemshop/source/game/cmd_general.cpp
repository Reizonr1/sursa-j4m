//search for:
#include "log.h"

//add below:
#ifdef __ITEM_SHOP__
#include "itemshop_manager.h"
#endif

//add at the end of file:
#ifdef __ITEM_SHOP__
ACMD(do_itemshop)
{
	char arg1[256];

    char szQuery[QUERY_MAX_LEN];
    char szChat[CHAT_MAX_LEN];

	one_argument(argument, arg1, sizeof(arg1));

    if (!*arg1)
		return;

    if (!strcmp(arg1, "open"))
    {
        if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("REFRESH_DELAY"));
            return;
        }
		CItemShopManager::instance().OpenItemShop(ch);
    }
    else if (!strcmp(arg1, "coins"))
    {
        if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("REFRESH_DELAY"));
            return;
        }

        snprintf(szChat, sizeof(szChat), "SetItemShopCoins %d", ch->GetCoins());
        ch->ChatPacket(CHAT_TYPE_COMMAND, szChat);
		
    }
    else if (!strcmp(arg1, "buy"))
    {
        char arg2[256];
        char arg3[256];
		int byCategory, wNum;

        two_arguments(one_argument(argument, arg1, sizeof(arg1)), arg2, sizeof(arg2), arg3, sizeof(arg3));

        if (!*arg2 || !*arg3)
            return;

        if (!isnhdigit(*arg2) || !isnhdigit(*arg3))
            return;

		if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("BUY_DELAY"));
            return;
        }

        str_to_number(byCategory, arg2);
        str_to_number(wNum, arg3);
		
		CItemShopManager::instance().BuyItem(ch, wNum, byCategory);

    }
	
	else if (!strcmp(arg1, "delete"))
    {
        char arg2[256];
        char arg3[256];
		int byCategory, wNum;

        two_arguments(one_argument(argument, arg1, sizeof(arg1)), arg2, sizeof(arg2), arg3, sizeof(arg3));

        if (!*arg2 || !*arg3)
            return;

        if (!isnhdigit(*arg2) || !isnhdigit(*arg3))
            return;

		if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("BUY_DELAY"));
            return;
        }

        str_to_number(byCategory, arg2);
        str_to_number(wNum, arg3);
		
		CItemShopManager::instance().DeleteItem(ch, wNum, byCategory);

    }
	
	else if (!strcmp(arg1, "add"))
    {
        std::vector<std::string> vecArgs;
		split_argument(argument, vecArgs);
		int dwVnum, dwCount, dwPrice, byCategory;

		for (int i=2; i<5; i++)
			if (!*vecArgs[i].c_str() || !isnhdigit(*vecArgs[i].c_str()))
				return;
		
		int row = 2;
		
		str_to_number(dwVnum, vecArgs[row++].c_str());
        str_to_number(dwCount, vecArgs[row++].c_str());
        str_to_number(dwPrice, vecArgs[row++].c_str());
        str_to_number(byCategory, vecArgs[row++].c_str());

		if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("BUY_DELAY"));
            return;
        }
		
		CItemShopManager::instance().AddItem(ch, dwVnum, dwCount, dwPrice, byCategory);

    }
	
		else if (!strcmp(arg1, "edit"))
    {
        std::vector<std::string> vecArgs;
		split_argument(argument, vecArgs);
		int dwVnum, dwCount, dwPrice, byCategory, dwID;

		for (int i=2; i<6; i++)
			if (!*vecArgs[i].c_str() || !isnhdigit(*vecArgs[i].c_str()))
				return;
		
		int row = 2;
		
		str_to_number(dwVnum, vecArgs[row++].c_str());
        str_to_number(dwCount, vecArgs[row++].c_str());
        str_to_number(dwPrice, vecArgs[row++].c_str());
        str_to_number(byCategory, vecArgs[row++].c_str());
        str_to_number(dwID, vecArgs[row++].c_str());


		if (!ch->CanWarp())
        {
            ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("BUY_DELAY"));
            return;
        }
		
		CItemShopManager::instance().EditItem(ch, dwVnum, dwCount, dwPrice, byCategory, dwID);

    }
}
#endif