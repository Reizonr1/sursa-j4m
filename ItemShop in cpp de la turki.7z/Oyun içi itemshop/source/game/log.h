//search for:
void		HackShieldLog(unsigned long ErrorCode, LPCHARACTER ch);

//add below:
#ifdef __ITEM_SHOP__
		void		ItemShopBuyLog(DWORD dwItemVnum, DWORD count, DWORD dwID, DWORD dwCategory, DWORD dwAccountID, DWORD dwPrice);
#endif