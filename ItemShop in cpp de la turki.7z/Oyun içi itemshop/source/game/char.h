//search for:
		int				GetSyncHackCount() { return m_iSyncHackCount; }

//add below:
#ifdef __ITEM_SHOP__
	public:
		void				LoadCoins(int coins)	{ m_iCoins = coins; }
		int					GetCoins()			{ return m_iCoins; }
		void				SetCoins(int coins);

	protected:
		int					m_iCoins;
		
#endif