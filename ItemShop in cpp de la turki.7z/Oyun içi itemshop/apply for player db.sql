/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50634
 Source Host           : localhost:3306
 Source Schema         : player

 Target Server Type    : MySQL
 Target Server Version : 50634
 File Encoding         : 65001

 Date: 27/08/2018 12:31:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for itemshop_categories
-- ----------------------------
DROP TABLE IF EXISTS `itemshop_categories`;
CREATE TABLE `itemshop_categories`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for itemshop_editors
-- ----------------------------
DROP TABLE IF EXISTS `itemshop_editors`;
CREATE TABLE `itemshop_editors`  (
  `name` varchar(32) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for itemshop_items
-- ----------------------------
DROP TABLE IF EXISTS `itemshop_items`;
CREATE TABLE `itemshop_items`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `vnum` int(11) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `count` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `item_vnum_index`(`vnum`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

SET FOREIGN_KEY_CHECKS = 1;
