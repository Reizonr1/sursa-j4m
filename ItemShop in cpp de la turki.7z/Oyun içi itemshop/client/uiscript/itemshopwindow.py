import uiScriptLocale

window = {
	"name" : "ItemShopDialog",
	"style" : ("movable", "float",),

	"x" : 0,
	"y" : 0,

	"width" : 674,
	"height" : 453,

	"children" :
	(
		{
			"name" : "Board",
			"type" : "board_with_titlebar",
			"style" : ("attach",),

			"x" : 0,
			"y" : 0,

			"width" : 674,
			"height" : 453,
			"title" : uiScriptLocale.ITEMSHOP_TITLE,
			"children" :
			(
				{
					"name": "categories_board",
					"type": "board",

					"x": 9,
					"y" : 31,

					"width" : 170,
					"height" : 413,

					"children" : (
						{
							"name": "category_button_01",
							"type": "radio_button",

							"x": 11,
							"y": 9,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_02",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 1,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_03",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 2,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_04",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 3,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_05",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 4,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_06",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 5,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_07",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 6,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_08",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 7,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_09",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 8,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_10",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 9,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_11",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 10,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_12",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 11,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "category_button_13",
							"type": "radio_button",

							"x": 11,
							"y": 9 + 28 * 12,

							"default_image": "d:/ymir work/ui/game/myshop_deco/select_btn_01.sub",
							"over_image": "d:/ymir work/ui/game/myshop_deco/select_btn_02.sub",
							"down_image": "d:/ymir work/ui/game/myshop_deco/select_btn_03.sub",

							"text": "",
						},
						{
							"name": "money_thin",
							"type": "thinboardcircle",

							"x": 30-9,
							"y" : 430-31-24,

							"width" : 128,
							"height" : 24,

							"children" : (
								{
									"name" : "money_slot",
									"type" : "bar",

									"x" : 4,
									"y" : 4,

									"width" : 120,
									"height" : 16,

									"color" : 0xFF000000,

									"children" : (
										{
											"name" : "money_value",
											"type" : "text",

											"x" : 0,
											"y" : 0,

											"all_align" : "center",

											"text" : ""
										},
									),
								},
							),
						},
					),
				},

				{
					"name": "items_board",
					"type": "board",

					"x": 185,
					"y" : 31,

					"width" : 480,
					"height" : 413,

				},
			),
		},
	),
}