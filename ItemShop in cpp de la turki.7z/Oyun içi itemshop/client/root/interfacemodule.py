//search for:
import event

//add below:
import uiItemShop

//search for:
		self.dlgRefineNew = uiRefine.RefineDialogNew()
		self.dlgRefineNew.Hide()

//add below:
		self.wndItemShop = uiItemShop.ItemShopWindow()
		self.wndItemShop.Hide()

//search for:
		if self.dlgExchange:
			self.dlgExchange.Destroy()

//add below:
			if self.wndItemShop:
			self.wndItemShop.Destroy()

//search for:
		del self.wndItemSelect

//add below:
		del self.wndItemShop