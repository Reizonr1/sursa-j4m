class Window(object):
	def NoneMethod(cls):
		pass

	NoneMethod = classmethod(NoneMethod)

	def __init__(self, layer = "UI"):
		self.hWnd = None
		self.parentWindow = 0
		self.onMouseLeftButtonUpEvent = None
		self.RegisterWindow(layer)
		self.Hide()

	def __del__(self):
		wndMgr.Destroy(self.hWnd)

	def RegisterWindow(self, layer):
		self.hWnd = wndMgr.Register(self, layer)

	def Destroy(self):
		pass

	def GetWindowHandle(self):
		return self.hWnd

	def AddFlag(self, style):
		wndMgr.AddFlag(self.hWnd, style)

	def IsRTL(self):
		return wndMgr.IsRTL(self.hWnd)

	def SetWindowName(self, Name):
		wndMgr.SetName(self.hWnd, Name)

	def GetWindowName(self):
		return wndMgr.GetName(self.hWnd)

	def SetParent(self, parent):		
		wndMgr.SetParent(self.hWnd, parent.hWnd)

	def SetParentProxy(self, parent):
		self.parentWindow=proxy(parent)
		wndMgr.SetParent(self.hWnd, parent.hWnd)

	
	def GetParentProxy(self):
		return self.parentWindow

	def SetPickAlways(self):
		wndMgr.SetPickAlways(self.hWnd)

	def SetWindowHorizontalAlignLeft(self):
		wndMgr.SetWindowHorizontalAlign(self.hWnd, wndMgr.HORIZONTAL_ALIGN_LEFT)

	def SetWindowHorizontalAlignCenter(self):
		wndMgr.SetWindowHorizontalAlign(self.hWnd, wndMgr.HORIZONTAL_ALIGN_CENTER)

	def SetWindowHorizontalAlignRight(self):
		wndMgr.SetWindowHorizontalAlign(self.hWnd, wndMgr.HORIZONTAL_ALIGN_RIGHT)

	def SetWindowVerticalAlignTop(self):
		wndMgr.SetWindowVerticalAlign(self.hWnd, wndMgr.VERTICAL_ALIGN_TOP)

	def SetWindowVerticalAlignCenter(self):
		wndMgr.SetWindowVerticalAlign(self.hWnd, wndMgr.VERTICAL_ALIGN_CENTER)

	def SetWindowVerticalAlignBottom(self):
		wndMgr.SetWindowVerticalAlign(self.hWnd, wndMgr.VERTICAL_ALIGN_BOTTOM)

	def SetTop(self):
		wndMgr.SetTop(self.hWnd)

	def Show(self):
		wndMgr.Show(self.hWnd)

	def Hide(self):
		wndMgr.Hide(self.hWnd)

	def Lock(self):
		wndMgr.Lock(self.hWnd)

	def Unlock(self):
		wndMgr.Unlock(self.hWnd)

	def IsShow(self):
		return wndMgr.IsShow(self.hWnd)

	def UpdateRect(self):
		wndMgr.UpdateRect(self.hWnd)

	def SetSize(self, width, height):
		wndMgr.SetWindowSize(self.hWnd, width, height)

	def GetWidth(self):
		return wndMgr.GetWindowWidth(self.hWnd)

	def GetHeight(self):
		return wndMgr.GetWindowHeight(self.hWnd)

	def GetLocalPosition(self):
		return wndMgr.GetWindowLocalPosition(self.hWnd)

	def GetGlobalPosition(self):
		return wndMgr.GetWindowGlobalPosition(self.hWnd)

	def GetMouseLocalPosition(self):
		return wndMgr.GetMouseLocalPosition(self.hWnd)

	def GetLeft(self):
		x, y = self.GetLocalPosition()
		return x
    
	def GetGlobalLeft(self):
		x, y = self.GetGlobalPosition()
		return x
    
	def GetTop(self):
		x, y = self.GetLocalPosition()
		return y
    
	def GetGlobalTop(self):
		x, y = self.GetGlobalPosition()
		return y
    
	def GetRight(self):
		return self.GetLeft() + self.GetWidth()
    
	def GetBottom(self):
		return self.GetTop() + self.GetHeight()

	def GetRect(self):
		return wndMgr.GetWindowRect(self.hWnd)

	def SetPosition(self, x, y):
		wndMgr.SetWindowPosition(self.hWnd, x, y)

	def SetCenterPosition(self, x = 0, y = 0):
		self.SetPosition((wndMgr.GetScreenWidth() - self.GetWidth()) / 2 + x, (wndMgr.GetScreenHeight() - self.GetHeight()) / 2 + y)

	def IsFocus(self):
		return wndMgr.IsFocus(self.hWnd)

	def SetFocus(self):
		wndMgr.SetFocus(self.hWnd)

	def KillFocus(self):
		wndMgr.KillFocus(self.hWnd)

	def GetChildCount(self):
		return wndMgr.GetChildCount(self.hWnd)

	def IsIn(self):
		return wndMgr.IsIn(self.hWnd)

	def SetOnMouseLeftButtonUpEvent(self, event):
		self.onMouseLeftButtonUpEvent = event
		
	def OnMouseLeftButtonUp(self):
		if self.onMouseLeftButtonUpEvent:
			self.onMouseLeftButtonUpEvent()


class ExpandedButton(ExpandedImageBox):
	def __init__(self):
		ExpandedImageBox.__init__(self)

		self.images = {"UP": "", "OVER": "", "DOWN": ""}
		self.state = "NORMAL"

		self.xScale = 1.0
		self.yScale = 1.0

		self.eventDict = {}
		self.argsDict = {}

	def __del__(self):
		ExpandedImageBox.__del__(self)

		self.eventDict = {}
		self.argsDict = {}

	def SetScale(self, xScale, yScale):
		self.xScale = float(xScale)
		self.yScale = float(yScale)
		ExpandedImageBox.SetScale(self, xScale, yScale)

	def LoadImage(self, imgPath):
		ExpandedImageBox.LoadImage(self, imgPath)
		ExpandedImageBox.SetScale(self, self.xScale, self.yScale)

	def SetUpVisual(self, filename):
		self.images["UP"] = filename
		if self.state == "NORMAL":
			self.LoadImage(filename)

	def SetOverVisual(self, filename):
		self.images["OVER"] = filename
		if self.state == "OVER":
			self.LoadImage(filename)

	def SetDownVisual(self, filename):
		self.images["DOWN"] = filename
		if self.state == "DOWN":
			self.LoadImage(filename)

	def GetUpVisualFileName(self):
		return self.images["UP"]

	def GetOverVisualFileName(self):
		return self.images["OVER"]

	def GetDownVisualFileName(self):
		return self.images["DOWN"]

	def Enable(self):
		try:
			apply(self.eventDict["ENABLE"], self.argsDict["ENABLE"])
		except KeyError:
			pass
		wndMgr.Enable(self.hWnd)

	def SetEnableEvent(self, func, *args):
		self.eventDict["ENABLE"] = __mem_func__(func)
		self.argsDict["ENABLE"] = args

	def Disable(self):
		try:
			apply(self.eventDict["DISABLE"], self.argsDict["DISABLE"])
		except KeyError:
			pass
		wndMgr.Disable(self.hWnd)

	def SetDisableEvent(self, func, *args):
		self.eventDict["DISABLE"] = __mem_func__(func)
		self.argsDict["DISABLE"] = args

	def OnMouseOverIn(self):
		try:
			apply(self.eventDict["MOUSE_OVER_IN"], self.argsDict["MOUSE_OVER_IN"])
		except KeyError:
			pass
		if self.state == "DOWN":
			return
		self.state = "OVER"
		self.LoadImage(self.images["OVER"])

	def SetMouseOverInEvent(self, func, *args):
		self.eventDict["MOUSE_OVER_IN"] = __mem_func__(func)
		self.argsDict["MOUSE_OVER_IN"] = args

	def OnMouseOverOut(self):
		try:
			apply(self.eventDict["MOUSE_OVER_OUT"], self.argsDict["MOUSE_OVER_OUT"])
		except KeyError:
			pass
		if self.state == "DOWN":
			return
		self.state = "NORMAL"
		self.LoadImage(self.images["UP"])

	def SetMouseOverOutEvent(self, func, *args):
		self.eventDict["MOUSE_OVER_OUT"] = __mem_func__(func)
		self.argsDict["MOUSE_OVER_OUT"] = args

	def OnMouseLeftButtonUp(self):
		self.state = "NORMAL"
		if self.IsIn():
			self.LoadImage(self.images["OVER"])
			snd.PlaySound("sound/ui/click.wav")
			try:
				apply(self.eventDict["MOUSE_CLICK"], self.argsDict["MOUSE_CLICK"])
			except KeyError:
				pass
		else:
			self.LoadImage(self.images["UP"])

	def SAFE_SetEvent(self, func, *args):
		self.eventDict["MOUSE_CLICK"] = __mem_func__(func)
		self.argsDict["MOUSE_CLICK"] = args

	def SetEvent(self, func, *args):
		self.eventDict["MOUSE_CLICK"] = func
		self.argsDict["MOUSE_CLICK"] = args

	def GetEvent(self):
		return self.eventFunc, self.eventArgs

	def OnMouseLeftButtonDown(self):
		self.state = "DOWN"
		self.LoadImage(self.images["DOWN"])

	def SetMouseDoubleClickEvent(self, func, *args):
		self.eventDict["MOUSE_DOUBLE_CLICK"] = __mem_func__(func)
		self.argsDict["MOUSE_DOUBLE_CLICK"] = args

	def OnMouseLeftButtonDoubleClick(self):
		try:
			apply(self.eventDict["MOUSE_DOUBLE_CLICK"], self.argsDict["MOUSE_DOUBLE_CLICK"])
		except KeyError:
			pass