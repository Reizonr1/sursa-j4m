import ui, item, localeInfo, uiCommon, uiToolTip, net, constInfo
class ItemShopWindow(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.category = {}
		self.categoryItem = {}
		self.temp_item = {}
		self.isEditor = False
		self.editItem = False
		self.currentCategory = -1
		self.__LoadWindow()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def __LoadWindow(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/itemshopwindow.py")

		except:
			import exception
			exception.Abort("ItemShopWindow.__LoadScript.LoadObject")

		try:
			self.listBox = NewListBox()
			self.listBox.SetParent(self.GetChild("items_board"))
			self.listBox.SetSize(440, 395)
			self.listBox.SetPosition(5, 9)
			self.listBox.Show()

			self.scrollBar = ui.ScrollBar()
			self.scrollBar.SetParent(self.GetChild("items_board"))
			self.scrollBar.SetPosition(30, 0)
			self.scrollBar.SetScrollBarSize(self.GetChild("items_board").GetHeight() - 16)
			self.scrollBar.SetWindowHorizontalAlignRight()
			self.scrollBar.SetWindowVerticalAlignCenter()
			self.scrollBar.Hide()

			self.listBox.SetScrollBar(self.scrollBar)

			for i in xrange(13):
				self.category[i] = self.GetChild("category_button_%02d" % (i+1))
				self.category[i].SetText(eval("localeInfo.ITEMSHOP_CATEGORY_%02d" % (i+1)))
				self.category[i].SetEvent(lambda arg=i: self.__OnClickCategoryButton(arg))
				self.categoryItem[i] = []
			self.moneyText = self.GetChild("money_value")
			self.GetChild("Board").SetCloseEvent(self.OpenWindow)

		except:
			import exception
			exception.Abort("ItemShopWindow.__LoadScript.BindObject")

		self.SetCenterPosition()

	def Open(self):
		self.Show()
		self.__OnClickCategoryButton(0)

	def __OnClickCategoryButton(self, index):
		self.listBox.ClearItems()

		self.currentCategory = index

		for i in xrange(13):
			self.category[i].SetUp()

		self.category[index].Down()

		for item in self.categoryItem[index]:
			self.listBox.AppendItem(item)

		if not len(self.categoryItem[index]):
			self.scrollBar.Hide()

		if self.isEditor:
			if not self.editItem:
				self.editItem = ItemShopItemEdit()

			self.editItem.SetData("category", index)
			self.listBox.AppendItem(self.editItem)

		self.scrollBar.Show()
		
		for item in self.temp_item.values():
			item = None

	def SetEditorFlag(self, flag):
		self.isEditor = int(flag)
		
	def ClearItems(self):
		self.listBox.ClearItems()

		for category in self.categoryItem:
			self.categoryItem[category] = []

	def Destroy(self):
		self.ClearDictionary()

	def OnPressEscapeKey(self):
		self.Hide()
		return True

	def RequestOpen(self):
		if self.IsShow():
			self.Hide()
			return
		net.SendChatPacket("/itemshop open")

	def OpenWindow(self):
		if self.IsShow():
			self.Hide()
		else:
			self.Show()

	def SetCoins(self, coins):
		self.moneyText.SetText(localeInfo.ITEMSHOP_YOUR_COINS % localeInfo.NumberToMoneyString(int(coins))[:-5])

	def AddItem(self, args):
		args = args.split("|")
		vnum, count, price, category, id = (args[0], args[1], args[2], args[3], args[4],)
		id = int(id)
		self.temp_item[id] = ItemShopItem()
		self.temp_item[id].SetEditor(self.isEditor)
		self.temp_item[id].SetData("vnum", int(vnum))
		self.temp_item[id].SetData("count", long(count))
		self.temp_item[id].SetData("price",int( price))
		self.temp_item[id].SetData("id", int(id))
		self.temp_item[id].SetData("category", int(category))
		self.temp_item[id].SetPrice(int(price))
		item.SelectItem(int(vnum))
		self.temp_item[id].SetName("%dx %s" % (long(count), item.GetItemName()))
		self.temp_item[id].SetItem(int(vnum))		
		self.categoryItem[int(category)].append(self.temp_item[id])

	def DeleteItem(self, category, id):
		category = int(category)
		id = int(id)

		for item in self.categoryItem[category]:
			if item.data["id"] == id:
				self.categoryItem[category].remove(item)
				break

	def UpdateItem(self, vnum, count, price, category, id):
		category = int(category)
		id = int(id)

		for temp_item in self.categoryItem[category]:
			if temp_item.data["id"] == id:
				temp_item.SetEditor(self.isEditor)
				temp_item.SetData("vnum", int(vnum))
				temp_item.SetData("count", int(count))
				temp_item.SetData("price", int(price))
				temp_item.SetPrice(int(price))
				item.SelectItem(int(vnum))
				temp_item.SetName("%dx %s" % (int(count), item.GetItemName()))
				temp_item.SetItem(int(vnum))
				break

	def RefreshPage(self):
		scrollPos = self.listBox.GetScrollBarPosition()
		self.__OnClickCategoryButton(self.currentCategory)
		self.listBox.OnScroll(scrollPos)

import grp

class NewListBox(ui.Window):
	def __init__(self):
		ui.Window.__init__(self)

		self.items = []
		self.selected = None
		self.basePos = 0
		self.itemWidth = 100
		self.itemStep = 4
		self.scrollbar = None
		self.scrollBarPos = 0.0

		self.selectEvent = None

	def SetSize(self, w, h):
		ui.Window.SetSize(self, w, h + self.itemStep)
		self.SetItemWidth(w)

		self.UpdateList()

	def SetScrollBar(self, scrollbar):
		self.scrollbar = scrollbar
		self.scrollbar.SetScrollEvent(ui.__mem_func__(self.__OnScroll))
		self.scrollbar.SetScrollStep(0.10)
		self.UpdateList()

	def CalcTotalItemHeight(self):
		total_height = 0
		for item in self.items:
			total_height += item.GetHeight()
			total_height += self.itemStep

		return total_height

	def ConfigureScrollBar(self):
		if self.scrollbar:
			itemheight = self.CalcTotalItemHeight()
			myheight = self.GetHeight() - 2 * self.itemStep
			dif = 0.97
			if itemheight > myheight and itemheight != 0:
				dif = 1.0 * myheight / itemheight

			self.scrollbar.SetMiddleBarSize(dif)

	def __OnScroll(self, position = None):
		pos = self.scrollbar.GetPos() if position == None else position
		self.scrollBarPos = pos
		toscr = self.CalcTotalItemHeight() - self.GetHeight() + 2 * self.itemStep
		self.basePos = toscr * pos

		self.UpdateList()

	def GetScrollBarPosition(self):
		return self.scrollBarPos

	def OnScroll(self, pos):
		self.__OnScroll(pos)

	def SelectItem(self, item):
		self.selected = item

		if self.selectEvent:
			self.selectEvent(item)

	def AppendItem(self, item):
		item.SetParent(self)
		item.SetWidth(self.itemWidth)
		item.Show()
		self.items.append(item)

		self.UpdateList()

	def RemoveItem(self, item):
		item.Hide()

		self.items.remove(item)
		self.UpdateList()

	def ClearItems(self):
		map(lambda wnd: wnd.Hide(), self.items)
		del self.items[:]

		self.basePos = 0
		if self.scrollbar:
			self.scrollbar.SetPos(0)
		self.UpdateList()

	def UpdateList(self):
		self.ConfigureScrollBar()
		self.RecalcItemPositions()

	def IsEmpty(self):
		return len(self.itemList) == 0

	def SetItemWidth(self, w):
		self.itemWidth = w
		for item in self.items:
			item.SetWidth(w)

	def RecalcItemPositions(self):
		curbp = self.basePos

		itemheight = self.CalcTotalItemHeight()
		myheight = self.GetHeight() - 2 * self.itemStep

		if itemheight < myheight:
			curbp = 0

		fromPos = curbp
		curPos = 0
		toPos = curbp + self.GetHeight()
		for item in self.items:
			hw = item.GetHeight()
			if curPos + hw < fromPos:
				item.Hide()
			elif curPos < fromPos and curPos + hw > fromPos:
				item.SetRenderMin(fromPos - curPos)
				item.Show()
			elif curPos < toPos and curPos + hw > toPos:
				item.SetRenderMax(toPos - curPos)
				item.Show()
			elif curPos > toPos:
				item.Hide()
			else:
				item.SetRenderMin(0)
				item.Show()

			item.SetPosition(0, curPos - fromPos)
			curPos += hw + self.itemStep

class NewListBoxItem(ui.Window):
	def __init__(self):
		ui.Window.__init__(self)

		self.width = 0
		self.height = 0
		self.minh = 0
		self.maxh = 0

		self.components = []

	def __del__(self):
		ui.Window.__del__(self)

	def SetColor(self, color=0xff0099ff):
		self.color = color

	def SetParent(self, parent):
		ui.Window.SetParent(self, parent)

	def SetHeight(self, h):
		self.SetSize(self.width, h)

	def SetWidth(self, w):
		self.SetSize(w, self.height)

	def SetSize(self, w, h):
		self.width = w
		self.height = h
		self.maxh = h
		ui.Window.SetSize(self, w, h)

	def SetRenderMin(self, minh):
		self.minh = minh
		self.maxh = self.height
		self.RecalculateRenderedComponents()

	def SetRenderMax(self, maxh):
		self.maxh = maxh
		self.minh = 0
		self.RecalculateRenderedComponents()

	def RegisterComponent(self, component):
		mtype = type(component).__name__
		if mtype == "Bar":
			(x, y, w, h) = component.GetRect()
			(x, y) = component.GetLocalPosition()
			component.__list_data = [x, y, w, h]
		self.components.append(component)

	def UnregisterComponent(self, component):
		self.components.remove(component)
		#if component.__list_data:
		#	component.__list_data = None

	def RecalculateRenderedComponents(self):
		for component in self.components:
			(xl, yl) = component.GetLocalPosition()
			(x, y, w, h) = component.GetRect()
			mtype = type(component).__name__
			if mtype == "TextLine":
				(w, h) = component.GetTextSize()

			if yl + h < self.minh:
				component.Hide()
			elif yl > self.maxh:
				component.Hide()
			else:
				if mtype == "ExpandedImageBox" or mtype == "ExpandedButton":

					miny = 0
					if self.minh > 0 and yl < self.minh:
						miny = -float(self.minh - yl) / float(h)

					maxy = 0
					if h != 0:
						maxy = float(self.maxh - yl - h) / float(h)

					maxy = min(0, max(-1, maxy))

					component.SetRenderingRect(0.0, miny, 0.0, maxy)
					component.Show()

				else:
					if yl < self.minh or yl + h > self.maxh:
						component.Hide()
					else:
						component.Show()

	def OnRender(self):
		x, y = self.GetGlobalPosition()
		grp.SetColor(self.color)
		grp.RenderBar(x, y + self.minh, self.GetWidth(), self.maxh - self.minh)

import uiScriptLocale
class ItemShopItem(NewListBoxItem):
	def __init__(self):
		NewListBoxItem.__init__(self)

		self.data = {"category": 0, "id": 0, "price": 0, "vnum" :0, "count": 0,}
		self.slot = []
		self.itemBuyQuestionDialog = None
		self.tooltipItem = uiToolTip.ItemToolTip()
		self.tooltipItem.Hide()
		self.__LoadWindow()

		self.SetSize(128, 118)
		self.SetColor(0x70000000)

	def __del__(self):
		NewListBoxItem.__del__(self)

	def Destroy(self):
		pass

	def SetEditor(self, flag):
		if flag:

			self.selectItemWindow = SelectItem()
			self.selectItemWindow.SetCenterPosition()
			self.selectItemWindow.SetItemWindow(self)
			self.selectItemWindow.AddFlag('movable')
			self.selectItemWindow.AddFlag('float')
			self.selectItemWindow.Close()

			self.editButton = ui.ExpandedButton()
			self.editButton.SetParent(self)
			self.editButton.SetUpVisual("d:/ymir work/ui/itemshop/edit_button.tga")
			self.editButton.SetOverVisual("d:/ymir work/ui/itemshop/edit_button.tga")
			self.editButton.SetDownVisual("d:/ymir work/ui/itemshop/edit_button.tga")
			self.editButton.SetPosition(280, 34)
			self.editButton.SetEvent(ui.__mem_func__(self.selectItemWindow.Show))
			self.editButton.Show()

			self.RegisterComponent(self.editButton)

			self.deleteButton = ui.ExpandedButton()
			self.deleteButton.SetParent(self)
			self.deleteButton.SetUpVisual("d:/ymir work/ui/itemshop/delete_button.tga")
			self.deleteButton.SetOverVisual("d:/ymir work/ui/itemshop/delete_button.tga")
			self.deleteButton.SetDownVisual("d:/ymir work/ui/itemshop/delete_button.tga")
			self.deleteButton.SetPosition(280+32, 34)
			self.deleteButton.SetEvent(ui.__mem_func__(self.AskDeleteItem))
			self.deleteButton.Show()

			self.RegisterComponent(self.deleteButton)

		else:
			try:
				self.selectItemWindow.Close()
				del self.selectItemWindow

				self.editButton.Hide()
				del self.editButton

				self.deleteButton.Hide()
				del self.deleteButton

				self.UnregisterComponent(self.selectItemWindow)
				self.UnregisterComponent(self.editButton)
				self.UnregisterComponent(self.deleteButton)
			except:
				pass

	def AskEditItem(self, vnum, price, count):
		itemIndex = vnum
		itemPrice = price
		itemCount = count

		item.SelectItem(itemIndex)
		itemName = item.GetItemName()

		itemBuyQuestionDialog = uiCommon.QuestionDialog()
		itemBuyQuestionDialog.SetText(localeInfo.ITEMSHOP_DO_YOU_EDIT_ITEM % itemName)
		itemBuyQuestionDialog.SetAcceptEvent(lambda arg=True: self.AnswerEditItem(arg, vnum, price, count))
		itemBuyQuestionDialog.SetCancelEvent(lambda arg=False: self.AnswerEditItem(arg))
		itemBuyQuestionDialog.Open()
		self.itemBuyQuestionDialog = itemBuyQuestionDialog

	def AnswerEditItem(self, flag, vnum=0, count=0, price=0):

		if flag:
			net.SendChatPacket("/itemshop edit %d %d %d %d %d" % (vnum, count, price, self.data["category"], self.data["id"]))

		self.itemBuyQuestionDialog.Close()
		self.itemBuyQuestionDialog = None

	def AskDeleteItem(self):
		itemIndex = self.data["vnum"]

		item.SelectItem(itemIndex)
		itemName = item.GetItemName()

		itemBuyQuestionDialog = uiCommon.QuestionDialog()
		itemBuyQuestionDialog.SetText(localeInfo.ITEMSHOP_DO_YOU_DELETE_ITEM % itemName)
		itemBuyQuestionDialog.SetAcceptEvent(lambda arg=True: self.AnswerDeleteItem(arg))
		itemBuyQuestionDialog.SetCancelEvent(lambda arg=False: self.AnswerDeleteItem(arg))
		itemBuyQuestionDialog.Open()
		self.itemBuyQuestionDialog = itemBuyQuestionDialog

	def AnswerDeleteItem(self, flag, vnum=0, count=0, price=0):

		if flag:
			net.SendChatPacket("/itemshop delete %d %d" % (self.data["category"], self.data["id"]))

		self.itemBuyQuestionDialog.Close()
		self.itemBuyQuestionDialog = None

	def __LoadWindow(self):

		self.slotBar = ui.ExpandedImageBox()
		self.slotBar.SetParent(self)
		self.slotBar.SetPosition(0, 0)
		self.slotBar.LoadImage("d:/ymir work/ui/tab_menu_01.tga")
		self.slotBar.Show()

		self.RegisterComponent(self.slotBar)

		self.nameText = ui.TextLine()
		self.nameText.SetParent(self.slotBar)
		self.nameText.SetPosition(8, 4)
		self.nameText.Show()

		self.RegisterComponent(self.nameText)

		self.priceText = ui.TextLine()
		self.priceText.SetParent(self.slotBar)
		self.priceText.SetPosition(368, 4)
		self.priceText.SetOutline(True)
		self.priceText.Show()

		self.RegisterComponent(self.priceText)

		slotImageFileName = ["slot_32x32.tga", "slot_32x64.tga", "slot_32x96.tga"]
		for i in xrange(3):
			slot = ui.ExpandedImageBox()
			slot.SetParent(self)
			slot.SetPosition(16, 24)
			slot.LoadImage("d:/ymir work/ui/itemshop/%s" % (slotImageFileName[i]))
			slot.Show()
			slot.SAFE_SetStringEvent("MOUSE_OVER_IN", self.OverInItem)
			slot.SAFE_SetStringEvent("MOUSE_OVER_OUT",self.OverOutItem)
			slot.Show()

			self.RegisterComponent(slot)

			self.slot.append(slot)

		self.itemImage = ui.ExpandedImageBox()
		self.itemImage.SetParent(self)
		self.itemImage.SetPosition(16, 24)
		self.itemImage.Show()

		self.itemImage.SAFE_SetStringEvent("MOUSE_OVER_IN", self.OverInItem)
		self.itemImage.SAFE_SetStringEvent("MOUSE_OVER_OUT", self.OverOutItem)

		self.RegisterComponent(self.itemImage)

		self.itemInfoText = ui.TextLine()
		self.itemInfoText.SetParent(self.slotBar)
		self.itemInfoText.SetPosition(56, 20)
		self.itemInfoText.SetWindowVerticalAlignCenter()
		self.itemInfoText.SetText(uiScriptLocale.ITEMSHOP_ITEM_INFO)
		self.itemInfoText.Show()

		self.RegisterComponent(self.itemInfoText)

		self.buyButton = ui.ExpandedButton()
		self.buyButton.SetParent(self)
		self.buyButton.SetUpVisual("d:/ymir work/ui/itemshop/buy_button_0.tga")
		self.buyButton.SetOverVisual("d:/ymir work/ui/itemshop/buy_button_1.tga")
		self.buyButton.SetDownVisual("d:/ymir work/ui/itemshop/buy_button_2.tga")
		self.buyButton.SetPosition(337, 20)
		self.buyButton.SetEvent(ui.__mem_func__(self.AskBuyItem))
		self.buyButton.Show()

		self.RegisterComponent(self.buyButton)

	def SetName(self, name):
		self.nameText.SetText(name)

	def SetData(self, field, data):
		self.data[field] = data

	def SetPrice(self, price):
		self.priceText.SetText(localeInfo.ITEMSHOP_ITEM_PRICE % localeInfo.NumberToMoneyString(price)[:-5])

	def SetItem(self, vnum):
		for slot in self.slot:
			slot.Hide()
			try:
				self.UnregisterComponent(slot)
			except:
				pass

		item.SelectItem(vnum)
		width, height = item.GetItemSize()

		targetSlot = self.slot[height-1]
		targetSlot.Show()
		self.RegisterComponent(targetSlot)

		self.itemImage.LoadImage(item.GetIconImageFileName())
		self.SetSize(self.slotBar.GetWidth(), 60+32*(height-1))

		self.buyButton.SetPosition(self.buyButton.GetLeft(), self.GetHeight()-self.buyButton.GetHeight()-9)
		(w, h) = self.itemInfoText.GetTextSize()
		self.itemInfoText.SetPosition(self.itemInfoText.GetLeft(), self.GetHeight()-h-12-15)

	def AskBuyItem(self):
		itemIndex = self.data["vnum"]
		itemPrice = self.data["price"]
		itemCount = self.data["count"]

		item.SelectItem(itemIndex)
		itemName = item.GetItemName()

		itemBuyQuestionDialog = uiCommon.QuestionDialog()
		itemBuyQuestionDialog.SetText(localeInfo.DO_YOU_BUY_ITEM(itemName, itemCount, localeInfo.NumberToMoneyString(itemPrice)))
		itemBuyQuestionDialog.SetAcceptEvent(lambda arg=True: self.AnswerBuyItem(arg))
		itemBuyQuestionDialog.SetCancelEvent(lambda arg=False: self.AnswerBuyItem(arg))
		itemBuyQuestionDialog.Open()
		self.itemBuyQuestionDialog = itemBuyQuestionDialog

	def AnswerBuyItem(self, flag):

		if flag:
			net.SendChatPacket("/itemshop buy %d %d" % (self.data["category"], self.data["id"]))

		self.itemBuyQuestionDialog.Close()
		self.itemBuyQuestionDialog = None

	def OverInItem(self):
		if self.tooltipItem:
			self.tooltipItem.SetItemToolTip(self.data["vnum"])

	def OverOutItem(self):
		if self.tooltipItem:
			self.tooltipItem.HideToolTip()

class ItemShopItemEdit(NewListBoxItem):
	def __init__(self):
		NewListBoxItem.__init__(self)
		self.data = {"category": 0, "id": 0, "price": 0, "vnum": 0, "count": 0, }
		self.slot = []
		self.itemBuyQuestionDialog = None
		self.tooltipItem = uiToolTip.ItemToolTip()
		self.tooltipItem.Hide()
		self.selectItemWindow = None
		self.__LoadWindow()

		self.SetSize(128, 118)
		self.SetColor(0x70000000)

	def __del__(self):
		NewListBoxItem.__del__(self)

	def Destroy(self):
		pass

	def __LoadWindow(self):

		self.slotBar = ui.ExpandedImageBox()
		self.slotBar.SetParent(self)
		self.slotBar.SetPosition(0, 0)
		self.slotBar.LoadImage("d:/ymir work/ui/tab_menu_01.tga")
		self.slotBar.Show()

		self.RegisterComponent(self.slotBar)

		self.nameText = ui.TextLine()
		self.nameText.SetParent(self.slotBar)
		self.nameText.SetPosition(8, 4)
		self.nameText.Show()

		self.RegisterComponent(self.nameText)

		self.priceText = ui.TextLine()
		self.priceText.SetParent(self.slotBar)
		self.priceText.SetPosition(368, 4)
		self.priceText.SetOutline(True)
		self.priceText.Show()

		self.RegisterComponent(self.priceText)

		slotImageFileName = ["slot_32x32.tga", "slot_32x64.tga", "slot_32x96.tga"]
		for i in xrange(3):
			slot = ui.ExpandedImageBox()
			slot.SetParent(self)
			slot.SetPosition(16, 24)
			slot.LoadImage("d:/ymir work/ui/itemshop/%s" % (slotImageFileName[i]))
			slot.Show()
			slot.SAFE_SetStringEvent("MOUSE_OVER_IN", self.OverInItem)
			slot.SAFE_SetStringEvent("MOUSE_OVER_OUT", self.OverOutItem)
			slot.SetOnMouseLeftButtonUpEvent(self.OnClickSlot)
			slot.Show()

			self.RegisterComponent(slot)

			self.slot.append(slot)

		self.itemImage = ui.ExpandedImageBox()
		self.itemImage.SetParent(self)
		self.itemImage.SetPosition(16, 24)
		self.itemImage.Show()
		self.itemImage.SetOnMouseLeftButtonUpEvent(self.OnClickSlot)

		self.itemImage.SAFE_SetStringEvent("MOUSE_OVER_IN", self.OverInItem)
		self.itemImage.SAFE_SetStringEvent("MOUSE_OVER_OUT", self.OverOutItem)

		self.RegisterComponent(self.itemImage)

		self.itemInfoText = ui.TextLine()
		self.itemInfoText.SetParent(self.slotBar)
		self.itemInfoText.SetPosition(56, 20)
		self.itemInfoText.SetWindowVerticalAlignCenter()
		self.itemInfoText.SetText(uiScriptLocale.ITEMSHOP_EDIT_ITEM_INFO)
		self.itemInfoText.Show()

		self.RegisterComponent(self.itemInfoText)

		self.addButton = ui.ExpandedButton()
		self.addButton.SetParent(self)
		self.addButton.SetUpVisual("d:/ymir work/ui/itemshop/buy_button_0.tga")
		self.addButton.SetOverVisual("d:/ymir work/ui/itemshop/buy_button_1.tga")
		self.addButton.SetDownVisual("d:/ymir work/ui/itemshop/buy_button_2.tga")
		self.addButton.SetPosition(337, 20)
		self.addButton.SetEvent(ui.__mem_func__(self.AskEditItem))
		self.addButton.Show()

		self.RegisterComponent(self.addButton)

		self.selectItemWindow = SelectItem()
		self.selectItemWindow.SetCenterPosition()
		self.selectItemWindow.SetEditItemWindow(self)
		self.selectItemWindow.AddFlag('movable')
		self.selectItemWindow.AddFlag('float')
		self.selectItemWindow.Close()

	def SetName(self, name):
		self.nameText.SetText(name)

	def SetData(self, field, data):
		self.data[field] = data

	def SetPrice(self, price):
		self.priceText.SetText(localeInfo.ITEMSHOP_ITEM_PRICE % localeInfo.NumberToMoneyString(price)[:-5])

	def SetItem(self, vnum):
		for slot in self.slot:
			slot.Hide()
			try:
				self.UnregisterComponent(slot)
			except:
				pass

		item.SelectItem(vnum)
		width, height = item.GetItemSize()

		targetSlot = self.slot[height - 1]
		targetSlot.Show()
		self.RegisterComponent(targetSlot)

		self.itemImage.LoadImage(item.GetIconImageFileName())
		self.SetSize(self.slotBar.GetWidth(), 60 + 32 * (height - 1))

		self.addButton.SetPosition(self.addButton.GetLeft(), self.GetHeight() - self.addButton.GetHeight() - 9)
		(w, h) = self.itemInfoText.GetTextSize()
		self.itemInfoText.SetPosition(self.itemInfoText.GetLeft(), self.GetHeight() - h - 12 - 15)

	def AskEditItem(self):
		itemIndex = self.data["vnum"]
		itemPrice = self.data["price"]
		itemCount = self.data["count"]

		item.SelectItem(itemIndex)
		itemName = item.GetItemName()

		itemBuyQuestionDialog = uiCommon.QuestionDialog()
		itemBuyQuestionDialog.SetText(
			localeInfo.ITEMSHOP_DO_YOU_ADD_ITEM % itemName)
		itemBuyQuestionDialog.SetAcceptEvent(lambda arg=True: self.AnswerEditItem(arg))
		itemBuyQuestionDialog.SetCancelEvent(lambda arg=False: self.AnswerEditItem(arg))
		itemBuyQuestionDialog.Open()
		self.itemBuyQuestionDialog = itemBuyQuestionDialog

	def AnswerEditItem(self, flag):

		if flag:
			net.SendChatPacket("/itemshop add %d %d %d %d" % (self.data["vnum"], self.data["count"], self.data["price"], self.data["category"]))

		self.itemBuyQuestionDialog.Close()
		self.itemBuyQuestionDialog = None

	def OverInItem(self):
		if self.tooltipItem:
			self.tooltipItem.SetItemToolTip(self.data["vnum"])

	def OverOutItem(self):
		if self.tooltipItem:
			self.tooltipItem.HideToolTip()

	def OnClickSlot(self):
		self.selectItemWindow.Show()


import skill, grp, ime
SKILLS = [1, 2, 3, 4, 5, 16, 17, 18, 19, 20, 122, 123, 121, 124, 125, 129, 130, 131, 137, 138, 139, 140, 31, 32, 33, 34,
          35, 46, 47, 48, 49, 50, 61, 62, 63, 64, 65, 66, 76, 77, 78, 79, 80, 81, 91, 92, 93, 94, 95, 96, 106, 107, 108,
          109, 110, 111]
SKILL_BOOKS = []
ITEM_LIST = item.GetNames()
SKILL_BOOK_NAMES = {
	50300: localeInfo.TOOLTIP_SKILLBOOK_NAME,
	70037: localeInfo.TOOLTIP_SKILL_FORGET_BOOK_NAME,
	# 70055:localeInfo.TOOLTIP_SKILL_FORGET_BOOK_NAME,
}

for skillIndex in SKILLS:
	for vnum, bookName in SKILL_BOOK_NAMES.iteritems():
		skillName = skill.GetSkillName(skillIndex)
		if not skillName:
			continue
		SKILL_BOOKS.append({"vnum": vnum, "name": skillName + " " + bookName, "skill": skillIndex})


class SelectItem(ui.BoardWithTitleBar):

	def __init__(self):
		ui.BoardWithTitleBar.__init__(self)
		self.UI = {}
		self.search_vnum = 0
		self.search_book = 0
		self.last = 0
		self.pop = None
		self.editItemWindow = None
		self.itemWindow = None
		self.__Load()

	def __del__(self):
		ui.BoardWithTitleBar.__del__(self)

	def SetEditItemWindow(self, window):
		self.editItemWindow = window

	def SetItemWindow(self, window):
		self.itemWindow = window

	def __Load(self):
		class Edit2(ui.EditLine):
			def __init__(self, parent, text, x, y, width, height, number=FALSE, slot=2, max=12):
				ui.EditLine.__init__(self)
				self.imageSlot = ui.MakeImageBox(parent, "d:/ymir work/ui/public/Parameter_Slot_0" + str(slot) + ".sub",
				                                 x, y)
				self.SetText(text)
				self.main = text
				self.SetEscapeEvent(self.OnPressEscapeKey)
				self.SetMax(max)
				self.SetUserMax(max)
				self.SetParent(self.imageSlot)
				if number:
					self.SetNumberMode()

				self.SetSize(width, height)
				self.SetPosition(5, 2)
				self.Show()

			def GetText(self):
				res = ui.EditLine.GetText(self)
				if res == "":
					return ""
				else:
					return res

			def OnPressEscapeKey(self):
				pass

			def __del__(self):
				ui.EditLine.__del__(self)

		class DropDown(ui.Window):
			dropped = 0
			dropstat = 0
			width = 0
			height = 0
			maxh = 30
			OnChange = None

			class Item(ui.Window):
				TEMPORARY_PLACE = 0
				width = 0
				height = 0

				def __init__(self, parent, text, value=0, skill=0):
					ui.Window.__init__(self)
					self.textBox = ui.MakeTextLine(self)
					self.textBox.SetText(text)
					self.value = int(value)
					self.skill = int(skill)

				def __del__(self):
					ui.Window.__del__(self)

				def SetParent(self, parent):
					ui.Window.SetParent(self, parent)
					self.parent = parent

				def OnMouseLeftButtonDown(self):
					self.parent.SelectItem(self)

				def SetSize(self, w, h):
					ui.Window.SetSize(self, w, h)
					self.width = w
					self.height = h

				def OnUpdate(self):
					if self.IsIn():
						self.isOver = True
					else:
						self.isOver = False

				def OnRender(self):
					xRender, yRender = self.GetGlobalPosition()
					yRender -= self.TEMPORARY_PLACE
					widthRender = self.width
					heightRender = self.height + self.TEMPORARY_PLACE * 2
					grp.SetColor(ui.BACKGROUND_COLOR)
					grp.RenderBar(xRender, yRender, widthRender, heightRender)
					grp.SetColor(ui.DARK_COLOR)
					grp.RenderLine(xRender, yRender, widthRender, 0)
					grp.RenderLine(xRender, yRender, 0, heightRender)
					grp.SetColor(ui.BRIGHT_COLOR)
					grp.RenderLine(xRender, yRender + heightRender, widthRender, 0)
					grp.RenderLine(xRender + widthRender, yRender, 0, heightRender)

					if self.isOver:
						grp.SetColor(ui.HALF_WHITE_COLOR)
						grp.RenderBar(xRender + 2, yRender + 3, self.width - 3, heightRender - 5)

			def __init__(self, parent):
				ui.Window.__init__(self, "TOP_MOST")
				self.down = 1
				self.parent = parent

				self.DropList = ui.ListBoxEx()
				self.DropList.SetParent(self)
				self.DropList.itemHeight = 20
				self.DropList.itemWidth = 220
				self.DropList.itemStep = 18
				self.DropList.SetPosition(0, 0)
				self.DropList.SetSize(200, 2)
				self.DropList.SetSelectEvent(self.SetTitle)
				self.DropList.SetViewItemCount(0)
				self.DropList.Show()
				self.selected = self.DropList.GetSelectedItem()

				self.SetSize(220, 95)

			def __del__(self):
				ui.Window.__del__(self)

			def AppendItem(self, text, value=0, skill=0):
				self.DropList.AppendItem(self.Item(self, text, value, skill))

			def OnPressEscapeKey(self):
				self.Hide()
				self.Clear()

			def SetTitle(self, item):
				self.dropped = 0
				self.selected = item
				if self.OnChange:
					self.OnChange()
				self.Clear()

			def SetSize(self, w, h):
				ui.Window.SetSize(self, w, h + 10)
				self.width = w
				self.height = h
				self.DropList.SetSize(w, h)

			def Clear(self):
				for x in self.DropList.itemList:
					x.Hide()
				self.DropList.RemoveAllItems()

			def ExpandMe(self):
				if self.dropped == 1:
					self.dropped = 0
				else:
					self.dropped = 1

			def OnUpdate(self):
				(w, h) = self.parent.GetLocalPosition()
				self.maxh = self.DropList.itemStep * len(self.DropList.itemList)
				self.SetPosition(w + 15, h + 65)
				if self.dropped == 0 or not self.parent.IsShow() or len(self.DropList.itemList) == 0:
					self.SetSize(self.GetWidth(), 0)
					self.DropList.SetViewItemCount(0)
					self.Hide()
				elif self.dropped == 1:
					self.Show()
					self.SetTop()
					height = self.maxh + 5 if int(self.maxh / self.DropList.itemStep) < 2 else self.maxh
					self.SetSize(self.GetWidth(), height)
					self.DropList.SetViewItemCount(self.maxh / self.DropList.itemStep)

		self.SetSize(300, 120)
		self.SetTitleName(localeInfo.SELECT_ITEM_TITLE)
		self.SetCloseEvent(self.Close)

		self.UI["priceText"] = ui.MakeText(self, localeInfo.SELECT_ITEM_PRICE, 15, 25, None)
		self.UI["priceEdit"] = Edit2(self, "0", 45, 175, 30, 25, 1, 3, 16)
		self.UI["priceEdit"].OnIMEUpdate = ui.__mem_func__(self.__OnValueUpdateYang)

		self.UI["countText"] = ui.MakeText(self, localeInfo.SELECT_ITEM_COUNT, 15, 30+20, None)
		self.UI["countEdit"] = Edit2(self, "0", 45, 175+20, 30, 25, 1, 3, 16)
		self.UI["countEdit"].OnIMEUpdate = ui.__mem_func__(self.__OnValueUpdateCount)

		self.UI["clear_button"] = ui.MakeButton(self, 40, 30, "", "d:/ymir work/ui/public/", "middle_Button_01.sub",
		                                        "middle_Button_02.sub", "middle_Button_03.sub")
		self.UI["clear_button"].SetText(localeInfo.SELECT_ITEM_CLEAR)
		self.UI["clear_button"].SetEvent(lambda: self.ClearTarget())
		self.UI["clear_button"].Show()

		self.UI["search_button"] = ui.MakeButton(self, 105, 30, "", "d:/ymir work/ui/public/", "middle_Button_01.sub",
		                                         "middle_Button_02.sub", "middle_Button_03.sub")
		self.UI["search_button"].SetText(localeInfo.SELECT_ITEM_BUTTON)
		self.UI["search_button"].SetEvent(lambda: self.Search())
		self.UI["search_button"].Show()

		self.UI["list_names"] = DropDown(self)
		self.UI["list_names"].OnChange = self.OnChange
		self.UI["list_names"].SetPosition(15, 60)
		self.UI["list_names"].Hide()

		self.UI["nameText"] = ui.MakeText(self, localeInfo.SELECT_ITEM_ENTER_ITEM_NAME, 15, 30, None)

		self.UI["nameEdit"] = Edit2(self, "", 15, 45, 200, 25, FALSE, 6, 30)
		self.UI["nameEdit"].OnIMEUpdate = ui.__mem_func__(self.__OnValueUpdate)
		self.UI["nameEdit"].SetReturnEvent(ui.__mem_func__(self.__OnHideList))
		self.UI["nameEdit"].SetEscapeEvent(ui.__mem_func__(self.__OnHideList))

		self.AddFlag("movable")
		self.AddFlag("float")
		self.SetCenterPosition()
		self.UI["nameText"].SetWindowHorizontalAlignLeft()
		self.UI["search_button"].SetWindowVerticalAlignBottom()
		self.UI["search_button"].SetWindowHorizontalAlignCenter()
		self.UI["priceText"].SetWindowVerticalAlignBottom()
		self.UI["priceText"].SetWindowHorizontalAlignLeft()
		self.UI["countText"].SetWindowVerticalAlignBottom()
		self.UI["countText"].SetWindowHorizontalAlignLeft()
		self.UI["clear_button"].SetWindowVerticalAlignBottom()
		self.UI["clear_button"].SetWindowHorizontalAlignCenter()
		self.UI["priceEdit"].imageSlot.SetPosition(45, self.GetHeight() - 27)
		self.UI["countEdit"].imageSlot.SetPosition(45, self.GetHeight() - 27 - 24)
		self.Hide()

		self.UI["nameEdit"].SetTabEvent(ui.__mem_func__(self.UI["countEdit"].SetFocus))
		self.UI["countEdit"].SetTabEvent(ui.__mem_func__(self.UI["priceEdit"].SetFocus))
		self.UI["priceEdit"].SetTabEvent(ui.__mem_func__(self.SetFocusName))

	def SetFocusName(self):
		self.UI["nameEdit"].SetFocus()
		self.__OnHideList()

	def ClearTarget(self):
		self.search_book = 0
		self.search_vnum = 0
		self.UI["nameEdit"].SetText("")
		self.UI["priceEdit"].SetText("0")
		self.UI["countEdit"].SetText("0")
		self.__OnHideList()

	def Search(self):
		price = self.UI["priceEdit"].GetText()
		if len(price):
			price = int(filter(str.isdigit, price))
		else:
			self.PopupMessage(localeInfo.SELECT_ITEM_ENTER_PRICE)

		count = self.UI["countEdit"].GetText()
		if len(count):
			count = int(filter(str.isdigit, count))
		else:
			self.PopupMessage(localeInfo.SELECT_ITEM_ENTER_COUNT)

		if self.search_vnum == 0:
			self.PopupMessage(localeInfo.SELECT_ITEM_EMPTY_ITEM_NAME)
			return

		if self.editItemWindow:
			self.editItemWindow.SetData("vnum", self.search_vnum)
			self.editItemWindow.SetData("count", count)
			self.editItemWindow.SetData("price",price)
			self.editItemWindow.SetPrice(price)
			item.SelectItem(self.search_vnum)
			self.editItemWindow.SetName("%dx %s" % (count, item.GetItemName()))
			self.editItemWindow.SetItem(self.search_vnum)
		else:
			self.itemWindow.AskEditItem(self.search_vnum, count, price)

		self.Close()

	def PopupMessage(self, text):
		pop = uiCommon.PopupDialog()
		pop.SetText(text)
		pop.SetAcceptEvent(self.__OnClosePopupDialog)
		pop.Open()
		self.pop = pop
		self.pop.SetTop()

	def __OnClosePopupDialog(self):
		if self.pop != None:
			if self.pop.IsShow():
				self.pop.Hide()
		self.pop = None

	def OnChange(self):
		self.search_vnum = self.UI["list_names"].DropList.GetSelectedItem().value
		self.search_book = self.UI["list_names"].DropList.GetSelectedItem().skill
		name = ""
		if not self.search_book:
			for it in ITEM_LIST:
				if int(it["vnum"]) == self.search_vnum:
					name = it["name"]
					break
		else:
			for book in SKILL_BOOKS:
				if int(book["vnum"]) == self.search_vnum and int(book["skill"]) == self.search_book:
					name = book["name"]
					break

		self.UI["nameEdit"].SetText(str(name))
		self.UI["list_names"].Clear()
		self.UI["list_names"].Hide()
		ime.SetCursorPosition(len(name) + 1)

	def __OnValueUpdateYang(self):
		ui.EditLine.OnIMEUpdate(self.UI["priceEdit"])
		text = self.UI["priceEdit"].GetText()
		if len(text):
			self.UI["priceEdit"].SetText((int(filter(str.isdigit, text))))

	def __OnValueUpdateCount(self):
		ui.EditLine.OnIMEUpdate(self.UI["countEdit"])
		text = self.UI["countEdit"].GetText()
		if len(text):
			self.UI["countEdit"].SetText((int(filter(str.isdigit, text))))

	def __OnValueUpdate(self):
		ui.EditLine.OnIMEUpdate(self.UI["nameEdit"])
		val = self.UI["nameEdit"].GetText()
		if len(val) > 0:
			self.UI["list_names"].Clear()
			f = 0
			n = []
			for it in ITEM_LIST:
				vnum, name = it["vnum"], it["name"]
				if f == 10:
					break
				if vnum in SKILL_BOOK_NAMES.keys():
					continue
				if len(name) >= len(val) and name[:len(val)].lower() == val.lower():
					self.UI["list_names"].AppendItem(name, vnum)
					f += 1
			if f == 0:
				for book in SKILL_BOOKS:
					if f == 10:
						break
					vnum, name, skill = book["vnum"], book["name"], book["skill"]
					if len(name) >= len(val) and name[:len(val)].lower() == val.lower():
						self.UI["list_names"].AppendItem(name, vnum, skill)
						f += 1

			if f > 0:
				if self.UI["list_names"].dropped == 0:
					self.UI["list_names"].Clear()
					self.UI["list_names"].ExpandMe()
				self.UI["list_names"].Show()
				return
		self.__OnHideList()

	def __OnHideList(self):
		self.UI["list_names"].dropped = 0
		self.UI["list_names"].Clear()
		self.UI["list_names"].Hide()

	def OnPressEscapeKey(self):
		if self.UI["list_names"].dropped:
			self.UI["list_names"].dropped = 0
			self.UI["list_names"].Clear()
			self.UI["list_names"].Hide()
		else:
			self.Close()

	def Show(self):
		ui.BoardWithTitleBar.Show(self)
		self.SetCenterPosition()
		self.SetTop()

	def Close(self):
		self.search_book = 0
		self.search_vnum = 0
		self.__OnHideList()
		self.Hide()
		return TRUE
