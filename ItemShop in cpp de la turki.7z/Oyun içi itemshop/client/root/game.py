//search for:
		onPressKeyDict[app.DIK_F4]	= lambda : self.__PressQuickSlot(7)

//add below:
		onPressKeyDict[app.DIK_F5] = lambda: self.interface.wndItemShop.RequestOpen()

//search for:
			# PRIVATE_SHOP_PRICE_LIST
			"MyShopPriceList"			: self.__PrivateShop_PriceList,
			# END_OF_PRIVATE_SHOP_PRICE_LIST

//add below:
			"SetItemShopCoins"          : self.interface.wndItemShop.SetCoins,
			"OpenShopWindow"            : self.interface.wndItemShop.Open,
			"SetItemShopItems"          : self.interface.wndItemShop.AddItem,
			"UpdateItemShopItem"        : self.interface.wndItemShop.UpdateItem,
			"ClearItemShopItems"        : self.interface.wndItemShop.ClearItems,
			"RefreshItemShopPage"       : self.interface.wndItemShop.RefreshPage,
			"DeleteItemShopItem"        : self.interface.wndItemShop.DeleteItem,
			"ItemShopEditor"            : self.interface.wndItemShop.SetEditorFlag,