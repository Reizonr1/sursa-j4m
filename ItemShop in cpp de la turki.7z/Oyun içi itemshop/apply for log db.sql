/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50634
 Source Host           : localhost:3306
 Source Schema         : log

 Target Server Type    : MySQL
 Target Server Version : 50634
 File Encoding         : 65001

 Date: 27/08/2018 12:31:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for itemshop_log
-- ----------------------------
DROP TABLE IF EXISTS `itemshop_log`;
CREATE TABLE `itemshop_log`  (
  `item_vnum` int(12) NOT NULL,
  `count` int(12) NOT NULL,
  `id` int(12) NOT NULL,
  `category` int(12) NOT NULL,
  `account_id` int(12) NOT NULL,
  `price` int(12) NOT NULL,
  `channel` int(12) NOT NULL,
  `date` datetime(0) NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
